# YouTube Background Color Changer

This merged Chrome extension combines:

- YouTube color picker for the left side, top side, and middle side
- YouTube Shorts underneath-thumbnail hider

The color picker adds a palette button next to YouTube's microphone button. The panel has three area buttons and preset color slots, including a rainbow custom color slot.

Text and icons switch between black and white based on the selected background color. Subscribe button text remains white.

## Install

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Turn on `Developer mode`.
4. Click `Load unpacked`.
5. Select this folder:

   `C:\Users\ahmed\Documents\youtube background color changer`

6. Open or refresh YouTube.
