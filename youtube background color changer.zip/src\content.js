(() => {
  const STORAGE_KEY = "ytcp-colors";
  const DEFAULT_COLORS = {
    left: "#ffffff",
    top: "#ffffff",
    middle: "#ffffff"
  };
  const PRESETS = [
    "#ffffff",
    "#f1f3f4",
    "#e8eaed",
    "#fff7d6",
    "#ffe0b2",
    "#ffcdd2",
    "#f8bbd0",
    "#e1bee7",
    "#d1c4e9",
    "#bbdefb",
    "#b2ebf2",
    "#c8e6c9",
    "#dcedc8",
    "#ffecb3",
    "#d7ccc8",
    "#cfd8dc",
    "#90caf9",
    "#80cbc4",
    "#a5d6a7",
    "#ffab91",
    "#ce93d8",
    "#78909c",
    "#5f6368",
    "#3c4043",
    "#263238",
    "#202124",
    "#0f0f0f",
    "#000000",
    "#0d47a1",
    "#00695c",
    "#1b5e20",
    "#b71c1c"
  ];
  const AREAS = [
    ["left", "Left side"],
    ["top", "Top side"],
    ["middle", "Middle side"]
  ];

  let colors = { ...DEFAULT_COLORS };
  let activeArea = "left";
  let panel;
  let button;
  let customInput;
  const DARK_BUTTON_TEXT_SELECTOR = [
    ".ytSpecButtonShapeNextButtonTextContent",
    ".ytSpecButtonShapeNextButtonTextContent *",
    ".yt-spec-button-shape-next__button-text-content",
    ".yt-spec-button-shape-next__button-text-content *",
    ".yt-spec-button-shape-next__label-text",
    ".yt-spec-button-shape-next__label-text *",
    ".ytAttributedStringHost",
    ".ytAttributedStringHost *",
    ".yt-core-attributed-string",
    ".yt-core-attributed-string *",
    "yt-formatted-string",
    "yt-formatted-string *",
    "span[role='text']",
    "span[role='text'] *"
  ].join(", ");
  const DARK_BUTTON_SELECTOR = [
    "button",
    "a[role='button']",
    "tp-yt-paper-button",
    ".ytSpecButtonShapeNextHost",
    ".yt-spec-button-shape-next",
    ".ytwAdButtonGroupViewModelHostPrimaryButton",
    "ad-button-view-model",
    "[role='button'][aria-label]"
  ].join(", ");
  const THEME_TOGGLE_SELECTOR = [
    "ytd-toggle-theme-compact-link-renderer"
  ].join(", ");
  const SUBSCRIBE_BUTTON_SELECTOR = [
    "ytd-watch-flexy ytd-subscribe-button-renderer button",
    "ytd-watch-flexy ytd-subscribe-button-renderer",
    "ytd-watch-flexy yt-button-shape",
    "ytd-watch-flexy button[aria-label*='Subscribe']",
    "ytd-watch-flexy button[aria-label*='Subscribed']",
    "ytd-watch-flexy button[aria-label*='Unsubscribe']"
  ].join(", ");
  const CAPTION_COLOR_OPTIONS = {
    white: "#ffffff",
    yellow: "#ffff00",
    green: "#00ff00",
    cyan: "#00ffff",
    blue: "#0000ff",
    magenta: "#ff00ff",
    red: "#ff0000",
    black: "#000000"
  };

  const getSyncStorage = () => globalThis.chrome?.storage?.sync;

  const parseRgbColor = (value) => {
    const match = typeof value === "string"
      ? value.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+))?\s*\)/i)
      : null;
    if (!match) return null;

    const alpha = match[4] === undefined ? 1 : Number(match[4]);
    if (alpha === 0) return null;

    return {
      r: Number(match[1]),
      g: Number(match[2]),
      b: Number(match[3])
    };
  };

  const getLuminance = ({ r, g, b }) => (0.2126 * r) + (0.7152 * g) + (0.0722 * b);

  const getEffectiveBackgroundColor = (element) => {
    let current = element;

    while (current instanceof HTMLElement && current !== document.documentElement) {
      const color = parseRgbColor(getComputedStyle(current).backgroundColor);
      if (color) return color;
      current = current.parentElement;
    }

    return null;
  };

  const forceWhiteText = (element) => {
    if (!(element instanceof HTMLElement)) return;

    [
      "--yt-spec-text-primary",
      "--yt-spec-text-primary-inverse",
      "--yt-spec-filled-button-text",
      "--yt-spec-static-brand-white",
      "--yt-spec-call-to-action"
    ].forEach((property) => {
      element.style.setProperty(property, "#ffffff", "important");
    });

    element.style.setProperty("color", "#ffffff", "important");
    element.style.setProperty("-webkit-text-fill-color", "#ffffff", "important");
    element.style.setProperty("fill", "#ffffff", "important");
    element.style.setProperty("stroke", "#ffffff", "important");
    element.style.setProperty("text-shadow", "0 0 0 #ffffff", "important");
    element.style.setProperty("opacity", "1", "important");
    element.style.setProperty("visibility", "visible", "important");
    element.style.setProperty("mix-blend-mode", "normal", "important");
    element.style.setProperty("filter", "none", "important");
  };

  const isDarkButton = (element) => {
    if (!(element instanceof HTMLElement)) return false;

    const box = element.getBoundingClientRect();
    if (box.width < 16 || box.height < 16) return false;

    const color = getEffectiveBackgroundColor(element);
    return Boolean(color && getLuminance(color) <= 72);
  };

  const forceButtonTextWhite = (target) => {
    if (!(target instanceof HTMLElement)) return;

    target.setAttribute("data-ytcp-dark-button", "true");
    forceWhiteText(target);
    target.querySelectorAll(DARK_BUTTON_TEXT_SELECTOR).forEach(forceWhiteText);
  };

  const isVisibleElement = (element) => {
    if (!(element instanceof HTMLElement)) return false;

    const box = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return (
      box.width > 0 &&
      box.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      Number(style.opacity || 1) > 0.05
    );
  };

  const getButtonText = (element) => {
    if (!(element instanceof HTMLElement)) return "";

    return (
      element.getAttribute("aria-label") ||
      element.textContent ||
      ""
    ).replace(/\s+/g, " ").trim().toLowerCase();
  };

  const updateCaptionColorFromPlayerMenu = () => {
    const checkedItems = [
      ...document.querySelectorAll(".ytp-menuitem[aria-checked='true'], .ytp-menuitem[aria-selected='true']")
    ];

    const selectedColor = checkedItems
      .map((item) => item.textContent?.replace(/\s+/g, " ").trim().toLowerCase() || "")
      .find((text) => Object.hasOwn(CAPTION_COLOR_OPTIONS, text));

    if (!selectedColor) return;

    document.documentElement.style.setProperty(
      "--ytcp-caption-fg",
      CAPTION_COLOR_OPTIONS[selectedColor]
    );
  };

  const applyDarkButtonTextFix = () => {
    document.querySelectorAll(DARK_BUTTON_SELECTOR).forEach((target) => {
      if (isDarkButton(target)) {
        forceButtonTextWhite(target);
      }
    });
  };

  const removeThemeToggleButton = () => {
    document.querySelectorAll(THEME_TOGGLE_SELECTOR).forEach((item) => {
      if (!(item instanceof HTMLElement)) return;

      const popup = item.closest("ytd-popup-container, ytd-multi-page-menu-renderer");
      if (!popup) return;

      item.setAttribute("data-ytcp-hide-theme-toggle", "true");
      item.style.setProperty("display", "none", "important");
      item.style.setProperty("visibility", "hidden", "important");
      item.style.setProperty("height", "0", "important");
      item.style.setProperty("min-height", "0", "important");
      item.style.setProperty("padding", "0", "important");
      item.style.setProperty("margin", "0", "important");
      item.style.setProperty("overflow", "hidden", "important");
    });
  };

  const removeExtraSubscribedButton = () => {
    const buttons = [...document.querySelectorAll(SUBSCRIBE_BUTTON_SELECTOR)]
      .filter((item) => item instanceof HTMLElement && isVisibleElement(item));
    const subscribeButton = buttons.find((item) => {
      const text = getButtonText(item);
      return text.includes("subscribe") && !text.includes("subscribed") && !text.includes("unsubscribe");
    });

    if (!(subscribeButton instanceof HTMLElement)) return;

    const subscribeBox = subscribeButton.getBoundingClientRect();
    buttons.forEach((item) => {
      const text = getButtonText(item);
      if (!text.includes("subscribed") && !text.includes("unsubscribe")) return;

      const itemBox = item.getBoundingClientRect();
      if (itemBox.top <= subscribeBox.top + 20) return;

      const host = item.closest("ytd-subscribe-button-renderer") || item.closest("yt-button-shape") || item;
      if (!(host instanceof HTMLElement)) return;

      host.setAttribute("data-ytcp-hide-extra-subscribed", "true");
      host.style.setProperty("display", "none", "important");
      host.style.setProperty("visibility", "hidden", "important");
      host.style.setProperty("height", "0", "important");
      host.style.setProperty("min-height", "0", "important");
      host.style.setProperty("padding", "0", "important");
      host.style.setProperty("margin", "0", "important");
      host.style.setProperty("overflow", "hidden", "important");
    });
  };

  const getStorage = () => new Promise((resolve) => {
    const syncStorage = getSyncStorage();

    if (!syncStorage) {
      try {
        resolve(JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"));
      } catch {
        resolve({});
      }
      return;
    }

    syncStorage.get(STORAGE_KEY, (result) => resolve(result[STORAGE_KEY] || {}));
  });

  const setStorage = (value) => new Promise((resolve) => {
    const syncStorage = getSyncStorage();

    if (!syncStorage) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
      resolve();
      return;
    }

    syncStorage.set({ [STORAGE_KEY]: value }, resolve);
  });

  const hexToRgb = (hex) => {
    const clean = hex.replace("#", "");
    const value = Number.parseInt(clean, 16);
    return {
      r: (value >> 16) & 255,
      g: (value >> 8) & 255,
      b: value & 255
    };
  };

  const getContrastText = (hex) => {
    const { r, g, b } = hexToRgb(hex);
    const srgb = [r, g, b].map((channel) => {
      const normalized = channel / 255;
      return normalized <= 0.03928
        ? normalized / 12.92
        : ((normalized + 0.055) / 1.055) ** 2.4;
    });
    const luminance = 0.2126 * srgb[0] + 0.7152 * srgb[1] + 0.0722 * srgb[2];
    return luminance > 0.45 ? "#0f0f0f" : "#ffffff";
  };

  const applyColors = () => {
    const root = document.documentElement;
    root.classList.add("ytcp-enabled");

    Object.entries(colors).forEach(([area, color]) => {
      root.style.setProperty(`--ytcp-${area}-bg`, color);
      root.style.setProperty(`--ytcp-${area}-fg`, getContrastText(color));
    });

    root.style.setProperty(
      "--ytcp-player-bg",
      getContrastText(colors.middle) === "#ffffff" ? "#3a3a3a" : "#000000"
    );
    root.style.setProperty("--ytcp-panel-bg", colors.top);
    root.style.setProperty("--ytcp-panel-fg", getContrastText(colors.top));
  };

  const createPaletteIcon = () => {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    svg.innerHTML = [
      '<path fill="currentColor" d="M12 3a9 9 0 0 0 0 18h1.2c1.1 0 1.7-1.3 1-2.1-.7-.8-.1-1.9.9-1.9H17a4 4 0 0 0 4-4.2C20.8 7.4 16.8 3 12 3Zm-4.1 8.1a1.4 1.4 0 1 1 0-2.8 1.4 1.4 0 0 1 0 2.8Zm3.1-3.3a1.4 1.4 0 1 1 0-2.8 1.4 1.4 0 0 1 0 2.8Zm4.1 0a1.4 1.4 0 1 1 0-2.8 1.4 1.4 0 0 1 0 2.8Zm2.9 3.3a1.4 1.4 0 1 1 0-2.8 1.4 1.4 0 0 1 0 2.8Z"/>'
    ].join("");
    return svg;
  };

  const updatePanelState = () => {
    if (!panel) return;

    AREAS.forEach(([area]) => {
      const tab = panel.querySelector(`[data-tab="${area}"]`);
      const current = panel.querySelector(`[data-current="${area}"]`);

      if (tab) {
        tab.setAttribute("aria-pressed", String(area === activeArea));
        tab.style.setProperty("--ytcp-tab-color", colors[area]);
      }

      if (current) {
        current.style.background = colors[area];
        current.title = colors[area];
      }
    });

    const activeLabel = AREAS.find(([area]) => area === activeArea)?.[1] || "Left side";
    const gridLabel = panel.querySelector("[data-active-label]");
    if (gridLabel) {
      gridLabel.textContent = `${activeLabel} presets`;
    }

    panel.querySelectorAll("[data-color]").forEach((swatch) => {
      swatch.setAttribute("aria-pressed", String(swatch.dataset.color === colors[activeArea]));
      swatch.title = `${activeLabel}: ${swatch.dataset.color}`;
      swatch.setAttribute("aria-label", `${activeLabel} ${swatch.dataset.color}`);
    });

    const customSwatch = panel.querySelector(".ytcp-swatch-custom");
    const colorInput = panel.querySelector(".ytcp-color-input");
    const isPresetColor = PRESETS.slice(0, -1).includes(colors[activeArea]);

    if (customSwatch) {
      customSwatch.setAttribute("aria-pressed", String(!isPresetColor));
    }

    if (colorInput) {
      colorInput.value = colors[activeArea];
    }
  };

  const setActiveArea = (area) => {
    activeArea = area;
    updatePanelState();
  };

  const pickColor = async (color) => {
    colors = { ...colors, [activeArea]: color };
    applyColors();
    updatePanelState();
    await setStorage(colors);
  };

  const buildPanel = () => {
    panel = document.createElement("section");
    panel.className = "ytcp-panel";
    panel.dataset.open = "false";
    panel.setAttribute("aria-label", "YouTube color picker presets");

    const title = document.createElement("h2");
    title.className = "ytcp-panel-title";
    title.textContent = "YouTube colors";
    panel.append(title);

    const tabs = document.createElement("div");
    tabs.className = "ytcp-tabs";

    AREAS.forEach(([area, label]) => {
      const tab = document.createElement("button");
      tab.className = "ytcp-tab";
      tab.dataset.tab = area;
      tab.type = "button";
      tab.setAttribute("aria-pressed", "false");

      const tabText = document.createElement("span");
      tabText.textContent = label;

      const current = document.createElement("span");
      current.className = "ytcp-current";
      current.dataset.current = area;

      tab.append(tabText, current);
      tab.addEventListener("click", () => setActiveArea(area));
      tabs.append(tab);
    });

    const paletteHeader = document.createElement("div");
    paletteHeader.className = "ytcp-palette-header";
    paletteHeader.dataset.activeLabel = "true";

    const swatches = document.createElement("div");
    swatches.className = "ytcp-swatches";

    PRESETS.slice(0, -1).forEach((color) => {
      const swatch = document.createElement("button");
      swatch.className = "ytcp-swatch";
      swatch.dataset.color = color;
      swatch.style.background = color;
      swatch.style.color = getContrastText(color);
      swatch.type = "button";
      swatch.addEventListener("click", () => pickColor(color));
      swatches.append(swatch);
    });

    const customSwatch = document.createElement("label");
    customSwatch.className = "ytcp-swatch ytcp-swatch-custom";
    customSwatch.role = "button";
    customSwatch.tabIndex = 0;
    customSwatch.title = "Choose custom color";
    customSwatch.setAttribute("aria-label", "Choose custom color");

    customInput = document.createElement("input");
    customInput.className = "ytcp-color-input";
    customInput.type = "color";
    customInput.value = colors[activeArea];
    customInput.setAttribute("aria-hidden", "true");
    customInput.tabIndex = -1;

    customSwatch.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      customInput.value = colors[activeArea];
      if (typeof customInput.showPicker === "function") {
        customInput.showPicker();
      } else {
        customInput.click();
      }
    });
    customInput.addEventListener("input", () => pickColor(customInput.value));
    customInput.addEventListener("change", () => pickColor(customInput.value));

    customSwatch.append(customInput);
    swatches.append(customSwatch);

    panel.append(tabs, paletteHeader, swatches);

    const actions = document.createElement("div");
    actions.className = "ytcp-actions";

    const reset = document.createElement("button");
    reset.className = "ytcp-reset";
    reset.type = "button";
    reset.textContent = "Reset";
    reset.addEventListener("click", async () => {
      colors = { ...DEFAULT_COLORS };
      applyColors();
      updatePanelState();
      await setStorage(colors);
    });

    actions.append(reset);
    panel.append(actions);
    document.body.append(panel);
    updatePanelState();
  };

  const togglePanel = () => {
    if (!panel) buildPanel();
    const isOpen = panel.dataset.open === "true";
    panel.dataset.open = String(!isOpen);
    button?.setAttribute("aria-expanded", String(!isOpen));
  };

  const closePanel = (event) => {
    if (!panel || panel.dataset.open !== "true") return;
    if (panel.contains(event.target) || button?.contains(event.target)) return;
    panel.dataset.open = "false";
    button?.setAttribute("aria-expanded", "false");
  };

  const createButton = () => {
    const nextToMic = document.querySelector("#voice-search-button");
    const endContainer = document.querySelector("#end.ytd-masthead");
    const host = nextToMic?.parentElement || endContainer;

    if (!host || document.querySelector(".ytcp-button")) return false;

    button = document.createElement("button");
    button.className = "ytcp-button";
    button.type = "button";
    button.title = "Pick YouTube colors";
    button.setAttribute("aria-label", "Pick YouTube colors");
    button.setAttribute("aria-haspopup", "dialog");
    button.setAttribute("aria-expanded", "false");
    button.append(createPaletteIcon());
    button.addEventListener("click", togglePanel);

    if (nextToMic) {
      nextToMic.insertAdjacentElement("afterend", button);
    } else {
      host.prepend(button);
    }

    return true;
  };

  const ensureButton = () => {
    if (document.querySelector(".ytcp-button")) return;
    createButton();
  };

  const init = async () => {
    const saved = await getStorage();
    colors = { ...DEFAULT_COLORS, ...saved };
    applyColors();
    createButton();

    applyDarkButtonTextFix();
    removeThemeToggleButton();
    removeExtraSubscribedButton();
    updateCaptionColorFromPlayerMenu();

    const observer = new MutationObserver(() => {
      ensureButton();
      applyDarkButtonTextFix();
      removeThemeToggleButton();
      removeExtraSubscribedButton();
      updateCaptionColorFromPlayerMenu();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });

    document.addEventListener("click", closePanel, true);
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && panel) {
        panel.dataset.open = "false";
        button?.setAttribute("aria-expanded", "false");
      }
    });
  };

  init();
})();
