(() => {
  const HIDDEN_CLASS = "yt-underneath-thumbnail-hider";
  const TARGET_SELECTORS = [
    ".reel-video-in-sequence-thumbnail",
    ".reel-video-in-sequence-container",
    "ytd-reel-non-video-content-renderer",
    "#nvc-container"
  ];

  let observer;

  const isShortsRoute = () => location.pathname.startsWith("/shorts/");

  const hideUnderneathThumbnail = (element) => {
    if (element && !element.classList.contains(HIDDEN_CLASS)) {
      element.classList.add(HIDDEN_CLASS);
    }
  };

  const hideExistingThumbnails = () => {
    if (!isShortsRoute()) return;

    TARGET_SELECTORS.forEach((selector) => {
      document.querySelectorAll(selector).forEach(hideUnderneathThumbnail);
    });
  };

  const observeForNewThumbnails = () => {
    if (observer) return;

    observer = new MutationObserver((mutations) => {
      if (!isShortsRoute()) return;

      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType !== Node.ELEMENT_NODE) return;

          TARGET_SELECTORS.forEach((selector) => {
            if (node.matches?.(selector)) {
              hideUnderneathThumbnail(node);
            }

            node.querySelectorAll?.(selector).forEach(hideUnderneathThumbnail);
          });
        });
      });
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  };

  const initialize = () => {
    hideExistingThumbnails();
    observeForNewThumbnails();
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
  } else {
    initialize();
  }

  window.addEventListener("yt-navigate-finish", hideExistingThumbnails);
})();
