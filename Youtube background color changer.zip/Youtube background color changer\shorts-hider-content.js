(() => {
  const HIDDEN_CLASS = "yt-underneath-thumbnail-hider";
  
  // Selectors for the underneath thumbnail and related elements
  const TARGET_SELECTORS = [
    ".reel-video-in-sequence-thumbnail",
    ".reel-video-in-sequence-container",
    "ytd-reel-non-video-content-renderer",
    "#nvc-container"
  ];
  
  function isShortsRoute() {
    return location.pathname.startsWith("/shorts/");
  }
  
  // Hide the underneath thumbnail by adding the CSS class
  function hideUnderneathThumbnail(element) {
    if (element && !element.classList.contains(HIDDEN_CLASS)) {
      element.classList.add(HIDDEN_CLASS);
    }
  }
  
  // Observe for new elements being added to the DOM
  function observeForNewThumbnails() {
    const mutationObserver = new MutationObserver((mutations) => {
      if (!isShortsRoute()) return;
      
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType !== Node.ELEMENT_NODE) continue;
          
          // Check if the added node matches any target selector
          for (const selector of TARGET_SELECTORS) {
            if (node.matches?.(selector)) {
              hideUnderneathThumbnail(node);
            }
            // Also check children of the added node
            const children = node.querySelectorAll?.(selector);
            if (children) {
              for (const child of children) {
                hideUnderneathThumbnail(child);
              }
            }
          }
        }
      }
    });
    
    mutationObserver.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  
  // Initial setup when script runs
  function initialize() {
    if (!isShortsRoute()) return;
    
    // Hide any existing thumbnails
    for (const selector of TARGET_SELECTORS) {
      const elements = document.querySelectorAll(selector);
      for (const element of elements) {
        hideUnderneathThumbnail(element);
      }
    }
    
    // Observe for new thumbnails
    observeForNewThumbnails();
  }
  
  // Run when the page loads
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
  } else {
    initialize();
  }
})();
