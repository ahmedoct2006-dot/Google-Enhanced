﻿# YouTube Background Color Changer

1. Open Chrome and go to `chrome://extensions`.
2. Turn on Developer mode.
3. Click Load unpacked.
4. Select this folder.
5. Open YouTube and use the `C` button near the microphone.
