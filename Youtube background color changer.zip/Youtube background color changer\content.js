﻿const STORAGE_KEY = "ytColorPickerButtonSettings";
const DEFAULT_SETTINGS = {
  activeRegion: "middle",
  colors: {
    left: "#ffffff",
    top: "#ffffff",
    middle: "#ffffff"
  }
};

const REGIONS = ["left", "top", "middle"];
const PALETTE_COLORS = [
  "#ffffff", "#fff36b", "#ffcf5a", "#ff9e57", "#ff6b6b", "#ff5fa2",
  "#c084fc", "#7c8cff", "#5aa9ff", "#57d6ff", "#4fe0b5", "#8eea58",
  "#d9ff72", "#fde68a", "#fdba74", "#fca5a5", "#f472b6", "#a78bfa",
  "#93c5fd", "#67e8f9", "#86efac", "#a3e635", "#94a3b8", "#64748b",
  "#334155", "#1e293b", "#0f172a", "#1f2937", "#374151", "#4b5563",
  "#57534e", "#78350f", "#7c2d12", "#7f1d1d", "#831843", "#581c87",
  "#312e81", "#1d4ed8", "#155e75", "#166534", "#365314", "#111827"
];
const BRANDED_LINKS = [
  {
    name: "premium",
    matcher: (href) => href.includes("/premium"),
    icon: "assets/youtube-premium-icon.svg"
  },
  {
    name: "music",
    matcher: (href) => href.includes("music.youtube.com"),
    icon: "assets/youtube-music-icon.svg"
  },
  {
    name: "kids",
    matcher: (href) => href.includes("/kids") || href.includes("youtubekids.com"),
    icon: "assets/youtube-kids-icon.svg"
  }
];

const state = {
  settings: cloneSettings(DEFAULT_SETTINGS),
  slot: null,
  button: null,
  panel: null,
  input: null,
  hexValue: null,
  segmentButtons: {},
  paletteButtons: [],
  observer: null,
  rafId: 0
};

function normalizeHex(value) {
  const hex = typeof value === "string" ? value.trim() : "";
  return /^#[0-9a-fA-F]{6}$/.test(hex) ? hex.toLowerCase() : "#ffffff";
}

function cloneSettings(value) {
  const activeRegion = REGIONS.includes(value?.activeRegion)
    ? value.activeRegion
    : DEFAULT_SETTINGS.activeRegion;

  return {
    activeRegion,
    colors: {
      left: normalizeHex(value?.colors?.left ?? DEFAULT_SETTINGS.colors.left),
      top: normalizeHex(value?.colors?.top ?? DEFAULT_SETTINGS.colors.top),
      middle: normalizeHex(value?.colors?.middle ?? DEFAULT_SETTINGS.colors.middle)
    }
  };
}

function hexToRgb(hex) {
  const value = normalizeHex(hex).slice(1);
  return {
    r: parseInt(value.slice(0, 2), 16),
    g: parseInt(value.slice(2, 4), 16),
    b: parseInt(value.slice(4, 6), 16)
  };
}

function rgbToHex({ r, g, b }) {
  const toHex = (channel) => Math.round(Math.min(255, Math.max(0, channel)))
    .toString(16)
    .padStart(2, "0");

  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function mixHex(primaryHex, secondaryHex, primaryWeight) {
  const weight = Math.min(1, Math.max(0, primaryWeight));
  const secondaryWeight = 1 - weight;
  const primary = hexToRgb(primaryHex);
  const secondary = hexToRgb(secondaryHex);

  return rgbToHex({
    r: primary.r * weight + secondary.r * secondaryWeight,
    g: primary.g * weight + secondary.g * secondaryWeight,
    b: primary.b * weight + secondary.b * secondaryWeight
  });
}

function getLinearChannel(channel) {
  const normalized = channel / 255;
  return normalized <= 0.04045
    ? normalized / 12.92
    : ((normalized + 0.055) / 1.055) ** 2.4;
}

function getLuminance(hex) {
  const { r, g, b } = hexToRgb(hex);
  return (
    0.2126 * getLinearChannel(r) +
    0.7152 * getLinearChannel(g) +
    0.0722 * getLinearChannel(b)
  );
}

function getContrastRatio(firstHex, secondHex) {
  const first = getLuminance(firstHex);
  const second = getLuminance(secondHex);
  const lighter = Math.max(first, second);
  const darker = Math.min(first, second);
  return (lighter + 0.05) / (darker + 0.05);
}

function getReadableForeground(color) {
  const dark = "#0f172a";
  const light = "#f8fafc";
  return getContrastRatio(color, dark) >= getContrastRatio(color, light) ? dark : light;
}

function getMutedForeground(color) {
  return getReadableForeground(color) === "#f8fafc"
    ? "rgba(248, 250, 252, 0.78)"
    : "rgba(15, 23, 42, 0.72)";
}

function getVisibleRect(element) {
  if (!(element instanceof HTMLElement)) {
    return null;
  }

  const rect = element.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) {
    return null;
  }

  if (rect.bottom <= 0 || rect.right <= 0) {
    return null;
  }

  if (rect.top >= window.innerHeight || rect.left >= window.innerWidth) {
    return null;
  }

  return rect;
}

function updateLeftFillWidth() {
  const root = document.documentElement;
  const expandedGuideCandidates = [
    document.querySelector("ytd-guide-renderer"),
    document.querySelector("tp-yt-app-drawer[opened] #guide-content"),
    document.querySelector("tp-yt-app-drawer[opened] #guide-inner-content"),
    document.querySelector("tp-yt-app-drawer[opened] #contentContainer")
  ];

  for (const candidate of expandedGuideCandidates) {
    const rect = getVisibleRect(candidate);
    if (rect && rect.right > 120) {
      root.style.setProperty("--ytcc-left-fill-width", `${Math.round(rect.right)}px`);
      root.classList.remove("ytcc-compact-left");
      return;
    }
  }

  const miniGuide = document.querySelector("ytd-mini-guide-renderer");
  const miniGuideRect = getVisibleRect(miniGuide);

  if (miniGuideRect) {
    root.style.setProperty("--ytcc-left-fill-width", `${Math.round(miniGuideRect.right)}px`);
    root.classList.add("ytcc-compact-left");
    return;
  }

  const guideButton = document.querySelector("ytd-masthead #guide-button, #guide-button");
  const guideButtonRect = getVisibleRect(guideButton);

  if (guideButtonRect) {
    root.style.setProperty("--ytcc-left-fill-width", `${Math.round(guideButtonRect.right)}px`);
    root.classList.add("ytcc-compact-left");
    return;
  }

  root.style.setProperty("--ytcc-left-fill-width", "72px");
  root.classList.add("ytcc-compact-left");
}

function isHomeLikePage() {
  return window.location.pathname === "/" || window.location.pathname === "/feed/subscriptions";
}

function getRegionSurface(region) {
  const color = state.settings.colors[region];
  const mixTarget = getReadableForeground(color) === "#f8fafc" ? "#020617" : "#ffffff";

  if (region === "top") {
    return mixHex(color, mixTarget, 0.96);
  }

  if (region === "left") {
    return mixHex(color, mixTarget, 0.92);
  }

  return mixHex(color, mixTarget, 0.88);
}

function getRegionCard(region) {
  const surface = getRegionSurface(region);
  const mixTarget = getReadableForeground(state.settings.colors[region]) === "#f8fafc" ? "#020617" : "#ffffff";
  return mixHex(surface, mixTarget, 0.94);
}

function setThemeVariables() {
  const root = document.documentElement;
  const leftColor = state.settings.colors.left;
  const topColor = state.settings.colors.top;
  const middleColor = state.settings.colors.middle;
  const activeColor = state.settings.colors[state.settings.activeRegion];
  const leftForeground = getReadableForeground(leftColor);
  const topForeground = getReadableForeground(topColor);
  const middleForeground = getReadableForeground(middleColor);

  root.style.setProperty("--ytcc-left-color", getRegionSurface("left"));
  root.style.setProperty("--ytcc-top-color", getRegionSurface("top"));
  root.style.setProperty("--ytcc-middle-color", getRegionSurface("middle"));
  root.style.setProperty("--ytcc-left-card-color", getRegionCard("left"));
  root.style.setProperty("--ytcc-top-card-color", getRegionCard("top"));
  root.style.setProperty("--ytcc-middle-card-color", getRegionCard("middle"));
  root.style.setProperty("--ytcc-left-border-color", mixHex(leftColor, leftForeground === "#f8fafc" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcc-top-border-color", mixHex(topColor, topForeground === "#f8fafc" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcc-middle-border-color", mixHex(middleColor, middleForeground === "#f8fafc" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcc-left-foreground", leftForeground);
  root.style.setProperty("--ytcc-top-foreground", topForeground);
  root.style.setProperty("--ytcc-middle-foreground", middleForeground);
  root.style.setProperty("--ytcc-left-muted", getMutedForeground(leftColor));
  root.style.setProperty("--ytcc-top-muted", getMutedForeground(topColor));
  root.style.setProperty("--ytcc-middle-muted", getMutedForeground(middleColor));
  root.classList.add("ytcc-enabled");
  root.classList.toggle("ytcc-home-layout", isHomeLikePage());
  root.classList.toggle("ytcc-left-dark", leftForeground === "#f8fafc");
  root.classList.toggle("ytcc-top-dark", topForeground === "#f8fafc");
  root.classList.toggle("ytcc-middle-dark", middleForeground === "#f8fafc");
  updateLeftFillWidth();

  if (state.button) {
    state.button.style.setProperty("--ytcc-button-swatch", activeColor);
    state.button.setAttribute(
      "aria-label",
      `Pick YouTube color for ${state.settings.activeRegion} side. Current color ${activeColor.toUpperCase()}`
    );
    state.button.title = `${capitalize(state.settings.activeRegion)} side color (${activeColor.toUpperCase()})`;
  }

  if (state.input) {
    state.input.value = activeColor;
  }

  if (state.hexValue) {
    state.hexValue.textContent = activeColor.toUpperCase();
  }

  if (state.panel) {
    const selectedSwatch = state.panel.querySelector(".ytcc-selected-swatch");
    if (selectedSwatch instanceof HTMLElement) {
      selectedSwatch.style.setProperty("--ytcc-selected-color", activeColor);
    }
  }

  state.paletteButtons.forEach((button) => {
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }

    button.dataset.selected = String(button.dataset.slotColor === activeColor);
  });

  REGIONS.forEach((region) => {
    const segment = state.segmentButtons[region];
    if (!segment) {
      return;
    }

    segment.dataset.active = String(region === state.settings.activeRegion);
    segment.style.setProperty("--ytcc-segment-swatch", state.settings.colors[region]);
  });
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function storageGet(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => resolve(result));
  });
}

function storageSet(value) {
  return new Promise((resolve) => {
    chrome.storage.local.set(value, () => resolve());
  });
}

async function persistSettings() {
  await storageSet({
    [STORAGE_KEY]: state.settings
  });
}

async function handleColorChange(value) {
  state.settings.colors[state.settings.activeRegion] = normalizeHex(value);
  setThemeVariables();
  await persistSettings();
}

async function setActiveRegion(region) {
  if (!REGIONS.includes(region)) {
    return;
  }

  state.settings.activeRegion = region;
  setThemeVariables();
  await persistSettings();
}

async function resetColors() {
  state.settings = cloneSettings(DEFAULT_SETTINGS);
  setThemeVariables();
  await persistSettings();
}

function closePanel() {
  if (!state.panel || !state.button) {
    return;
  }

  state.panel.hidden = true;
  state.button.setAttribute("aria-expanded", "false");
  state.button.dataset.open = "false";
}

function openPanel() {
  if (!state.panel || !state.button) {
    return;
  }

  const rect = state.button.getBoundingClientRect();
  const panelWidth = Math.min(520, window.innerWidth - 24);
  const left = Math.max(12, Math.min(window.innerWidth - panelWidth - 12, rect.right - panelWidth));

  state.panel.hidden = false;
  state.panel.style.top = `${Math.max(72, rect.bottom + 10)}px`;
  state.panel.style.left = `${left}px`;
  state.button.setAttribute("aria-expanded", "true");
  state.button.dataset.open = "true";
}

function togglePanel() {
  if (!state.panel) {
    return;
  }

  if (state.panel.hidden) {
    openPanel();
  } else {
    closePanel();
  }
}

function createSegmentMarkup(region, label) {
  return `
    <button class="ytcc-segment-button" type="button" data-region="${region}" data-active="false">
      <span class="ytcc-segment-swatch" aria-hidden="true"></span>
      <span>${label}</span>
    </button>
  `;
}

function createPaletteSlotMarkup(color) {
  const isLight = getReadableForeground(color) !== "#f8fafc";
  const iconClass = isLight ? "ytcc-slot-icon-dark" : "ytcc-slot-icon-light";

  return `
    <button class="ytcc-palette-slot" type="button" data-slot-color="${color}" data-selected="false" aria-label="Use color ${color.toUpperCase()}">
      <span class="ytcc-palette-fill" style="--ytcc-slot-color: ${color};"></span>
      <span class="ytcc-palette-icon ${iconClass}" aria-hidden="true">
        <svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
          <path d="M21 7.5a3.5 3.5 0 0 0-3.5-3.5h-11A3.5 3.5 0 0 0 3 7.5v9A3.5 3.5 0 0 0 6.5 20h11a3.5 3.5 0 0 0 3.5-3.5v-9Zm-9.8 1.95 4.7 2.55-4.7 2.55v-5.1Z"></path>
        </svg>
      </span>
    </button>
  `;
}

function createCustomPaletteSlotMarkup() {
  return `
    <button class="ytcc-palette-slot ytcc-palette-slot-custom" type="button" data-slot-custom="true" data-selected="false" aria-label="Open custom color wheel">
      <span class="ytcc-palette-fill ytcc-palette-fill-rainbow"></span>
      <span class="ytcc-palette-icon ytcc-slot-icon-dark" aria-hidden="true">
        <svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
          <path d="M21 7.5a3.5 3.5 0 0 0-3.5-3.5h-11A3.5 3.5 0 0 0 3 7.5v9A3.5 3.5 0 0 0 6.5 20h11a3.5 3.5 0 0 0 3.5-3.5v-9Zm-9.8 1.95 4.7 2.55-4.7 2.55v-5.1Z"></path>
        </svg>
      </span>

    </button>
  `;
}

function createPanel() {
  if (state.panel) {
    return state.panel;
  }

  const panel = document.createElement("section");
  panel.id = "ytcc-panel";
  panel.hidden = true;
  panel.innerHTML = `
    <div class="ytcc-panel-header">
      <div class="ytcc-panel-brand">
        <span class="ytcc-panel-brand-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
            <path d="M21 7.5a3.5 3.5 0 0 0-3.5-3.5h-11A3.5 3.5 0 0 0 3 7.5v9A3.5 3.5 0 0 0 6.5 20h11a3.5 3.5 0 0 0 3.5-3.5v-9Zm-9.8 1.95 4.7 2.55-4.7 2.55v-5.1Z"></path>
          </svg>
        </span>
        <div>
          <h2 class="ytcc-panel-title">Color Changer for YouTube</h2>
          <p class="ytcc-panel-subtitle">Choose a side first, then pick a slot.</p>
        </div>
      </div>
      <button class="ytcc-close-button" type="button" aria-label="Close color picker">Ã—</button>
    </div>
    <div class="ytcc-segments" role="tablist" aria-label="Pick YouTube area">
      ${createSegmentMarkup("left", "Left side")}
      ${createSegmentMarkup("top", "Top side")}
      ${createSegmentMarkup("middle", "Middle side")}
    </div>
    <div class="ytcc-palette-frame">
      <span class="ytcc-field-title">Color slots</span>
      <span class="ytcc-field-hint">Light colors are at the top, darker colors are lower down. The rainbow slot opens the color wheel.</span>
      <div class="ytcc-palette-grid" role="list" aria-label="Choose a color slot">
        ${PALETTE_COLORS.map((color) => createPaletteSlotMarkup(color)).join("")}
        ${createCustomPaletteSlotMarkup()}
      </div>
      <input id="ytcc-color-input" class="ytcc-color-input" type="color" />
    </div>
    <div class="ytcc-panel-actions">
      <button class="ytcc-reset-button" type="button">Reset all</button>
    </div>
  `;

  panel.querySelector(".ytcc-close-button")?.addEventListener("click", closePanel);
  panel.querySelector(".ytcc-reset-button")?.addEventListener("click", () => {
    resetColors();
  });

  const input = panel.querySelector(".ytcc-color-input");
  const hexValue = panel.querySelector(".ytcc-color-value");

  input?.addEventListener("input", (event) => {
    handleColorChange(event.target.value);
  });

  panel.querySelectorAll(".ytcc-palette-slot").forEach((button) => {
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }

    state.paletteButtons.push(button);

    button.addEventListener("click", () => {
      if (button.dataset.slotCustom === "true") {
        if (state.input) {
          if (typeof state.input.showPicker === "function") {
            state.input.showPicker();
          } else {
            state.input.click();
          }
        }
        return;
      }

      const value = button.dataset.slotColor;
      if (value) {
        handleColorChange(value);
      }
    });
  });

  panel.querySelectorAll(".ytcc-segment-button").forEach((button) => {
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }

    const region = button.dataset.region;
    if (!REGIONS.includes(region)) {
      return;
    }

    state.segmentButtons[region] = button;
    button.addEventListener("click", () => {
      setActiveRegion(region);
    });
  });

  document.body.appendChild(panel);
  state.panel = panel;
  state.input = input;
  state.hexValue = hexValue;
  setThemeVariables();
  return panel;
}

function createToolbarButton() {
  if (state.slot) {
    return state.slot;
  }

  const slot = document.createElement("div");
  slot.id = "ytcc-toolbar-slot";

  const button = document.createElement("button");
  button.id = "ytcc-toolbar-button";
  button.type = "button";
  button.setAttribute("aria-haspopup", "dialog");
  button.setAttribute("aria-expanded", "false");
  button.dataset.open = "false";
  button.innerHTML = `
    <span class="ytcc-toolbar-swatch" aria-hidden="true"></span>
    <span class="ytcc-toolbar-label">Color</span>
  `;

  button.addEventListener("click", () => {
    togglePanel();
  });

  button.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    resetColors();
  });

  slot.appendChild(button);
  state.slot = slot;
  state.button = button;
  setThemeVariables();
  return slot;
}

function getToolbarAnchor() {
  return (
    document.querySelector("ytd-masthead #voice-search-button") ||
    document.querySelector("#voice-search-button") ||
    document.querySelector("ytd-masthead ytd-voice-search-button-renderer") ||
    document.querySelector("ytd-voice-search-button-renderer")
  );
}

function getToolbarFallbackHost() {
  return (
    document.querySelector("ytd-masthead #end") ||
    document.querySelector("#end") ||
    document.querySelector("ytd-masthead #buttons") ||
    document.querySelector("ytd-masthead #center") ||
    document.querySelector("ytd-masthead")
  );
}

function mountToolbarButton() {
  const anchor = getToolbarAnchor();
  const slot = createToolbarButton();
  createPanel();
  updateLeftFillWidth();

  if (getVisibleRect(anchor)) {
    if (anchor.nextElementSibling !== slot) {
      anchor.insertAdjacentElement("afterend", slot);
    }
    return;
  }

  const fallbackHost = getToolbarFallbackHost();
  if (fallbackHost instanceof Element && !fallbackHost.contains(slot)) {
    fallbackHost.appendChild(slot);
    return;
  }

  if (anchor instanceof Element && anchor.nextElementSibling !== slot) {
    anchor.insertAdjacentElement("afterend", slot);
  }
}

function getBrandedLinkConfig(href) {
  const normalizedHref = String(href || "").toLowerCase();
  return BRANDED_LINKS.find((entry) => entry.matcher(normalizedHref)) || null;
}

function applyBrandedSidebarIcons() {
  const links = document.querySelectorAll("ytd-guide-entry-renderer a[href], ytd-guide-collapsible-section-entry-renderer a[href]");

  links.forEach((link) => {
    if (!(link instanceof HTMLAnchorElement)) {
      return;
    }

    const config = getBrandedLinkConfig(link.href);
    if (!config) {
      return;
    }

    link.classList.add("ytcc-branded-link", `ytcc-brand-${config.name}`);

    const iconHost = link.querySelector("yt-icon");
    if (iconHost instanceof HTMLElement) {
      iconHost.classList.add("ytcc-brand-icon-host");

      if (!iconHost.querySelector(".ytcc-brand-icon-image")) {
        const badge = document.createElement("span");
        badge.className = "ytcc-brand-icon-image";
        badge.style.backgroundImage = `url("${chrome.runtime.getURL(config.icon)}")`;
        badge.setAttribute("aria-hidden", "true");
        iconHost.appendChild(badge);
      }
    }
  });
}

function applyHomeLogoBranding() {
  const logoLinks = document.querySelectorAll("ytd-topbar-logo-renderer a#logo, #masthead ytd-topbar-logo-renderer a#logo");

  logoLinks.forEach((link) => {
    if (!(link instanceof HTMLAnchorElement)) {
      return;
    }

    link.classList.add("ytcc-home-logo-link");

    if (!link.querySelector(".ytcc-home-logo-combo")) {
      const combo = document.createElement("span");
      combo.className = "ytcc-home-logo-combo";

      const icon = document.createElement("span");
      icon.className = "ytcc-home-logo-image";
      icon.setAttribute("aria-hidden", "true");

      const label = document.createElement("span");
      label.className = "ytcc-home-logo-text";
      label.textContent = "YouTube";

      combo.appendChild(icon);
      combo.appendChild(label);
      link.prepend(combo);
    }

    const injectedIcon = link.querySelector(".ytcc-home-logo-image");
    if (injectedIcon instanceof HTMLElement) {
      injectedIcon.style.backgroundImage = `url("${chrome.runtime.getURL("assets/ytcc-home-logo.svg")}")`;
    }

    const defaultIcon = link.querySelector("#logo-icon, #logo-icon-container, yt-icon");
    if (defaultIcon instanceof HTMLElement) {
      defaultIcon.classList.add("ytcc-home-logo-default-icon");
    }

    const defaultText = link.querySelector("#text");
    if (defaultText instanceof HTMLElement) {
      defaultText.classList.add("ytcc-home-logo-default-text");
    }
  });
}

function scheduleRefresh() {
  if (state.rafId) {
    cancelAnimationFrame(state.rafId);
  }

  state.rafId = requestAnimationFrame(() => {
    state.rafId = 0;
    mountToolbarButton();
    applyBrandedSidebarIcons();
    applyHomeLogoBranding();
    if (state.panel && !state.panel.hidden) {
      openPanel();
    }
  });
}

function setupObservers() {
  document.addEventListener("click", (event) => {
    if (!state.panel || state.panel.hidden) {
      return;
    }

    const target = event.target;
    if (state.panel.contains(target) || state.button?.contains(target)) {
      return;
    }

    closePanel();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closePanel();
    }
  });

  window.addEventListener("resize", scheduleRefresh, { passive: true });
  window.addEventListener("scroll", scheduleRefresh, { passive: true });
  window.addEventListener("yt-navigate-finish", () => {
    setThemeVariables();
    scheduleRefresh();
  }, { passive: true });

  const observer = new MutationObserver(() => {
    scheduleRefresh();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  state.observer = observer;
}

async function initialize() {
  if (!document.body) {
    window.addEventListener("DOMContentLoaded", initialize, { once: true });
    return;
  }

  state.settings = cloneSettings(DEFAULT_SETTINGS);
  await persistSettings();
  setThemeVariables();
  createToolbarButton();
  createPanel();
  setupObservers();
  scheduleRefresh();
}

initialize();

