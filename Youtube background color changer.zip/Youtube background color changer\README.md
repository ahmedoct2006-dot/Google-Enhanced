﻿# Youtube Background Color Changer

This Chrome extension combines:
- the YouTube three-side color picker
- the YouTube Shorts underneath thumbnail hider

## Install

1. Open `chrome://extensions`
2. Turn on `Developer mode`
3. Click `Load unpacked`
4. Select the `Youtube background color changer` folder

## Notes

- This is a separate combined extension folder.
- It keeps the existing source folders unchanged.
- Colors are saved with `chrome.storage.local`.
- Right-click the `Color` button to reset all three colors.
