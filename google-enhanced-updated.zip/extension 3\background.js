const GOOGLE_RETURN_FLAG = "ge_extension_return";

function getExtensionHomeUrl() {
  return chrome.runtime.getURL("newtab.html");
}

function shouldRedirectToExtensionHome(tabUrl) {
  if (!tabUrl) {
    return false;
  }

  try {
    const url = new URL(tabUrl);
    const hostname = url.hostname.toLowerCase();
    const isGoogleHost = hostname === "google.com" ||
      hostname === "www.google.com" ||
      hostname === "google.co.uk" ||
      hostname === "www.google.co.uk";

    return isGoogleHost && url.searchParams.get(GOOGLE_RETURN_FLAG) === "1";
  } catch {
    return false;
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const nextUrl = changeInfo.url || tab.url;

  if (!shouldRedirectToExtensionHome(nextUrl)) {
    return;
  }

  chrome.tabs.update(tabId, { url: getExtensionHomeUrl() });
});
