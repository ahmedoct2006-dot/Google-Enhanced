const STORAGE_KEY = "ytBackgroundColorSettings";
const FOREGROUND_SWITCH_COLOR = "#851919";
const DARK_FOREGROUND = "#0f172a";
const LIGHT_FOREGROUND = "#f8fafc";
const MIN_CHIP_TEXT_CONTRAST = 4.5;
const CHIP_SURFACE_START_WEIGHT = 0.88;
const CHIP_SURFACE_MIN_WEIGHT = 0.28;
const CHIP_SURFACE_STEP = 0.08;
const CTA_SYNC_DELAYS = [0, 80, 240, 600, 1200, 2400, 5000, 9000];
const CTA_RESYNC_INTERVAL_MS = 1000;
const CTA_DEBUG_LOG_LIMIT = 6;
const LEFT_PANEL_HOME_TOUCH_THRESHOLD = 120;
const CHIP_SYNC_DELAYS = [0, 60, 180, 420, 900];
const LARGE_AD_CTA_LABELS = [
  "watch",
  "learn more",
  "shop now",
  "install",
  "download",
  "book now",
  "sign up",
  "play now",
  "visit site",
  "visit now",
  "get offer"
];
const MAX_INLINE_AD_MEDIA_WIDTH = 320;
const MAX_INLINE_AD_MEDIA_HEIGHT = 190;
const MIN_LARGE_AD_CARD_WIDTH = 500;
const MIN_LARGE_AD_CARD_HEIGHT = 260;
const MIN_WIDE_AD_CARD_WIDTH = 700;
const MAX_WIDE_AD_CARD_HEIGHT = 340;
const MIN_WIDE_AD_ASPECT_RATIO = 2.2;
const SPONSORED_RENDERER_SELECTOR = [
  "ytd-ad-slot-renderer",
  "ytd-display-ad-renderer",
  "ytd-in-feed-ad-layout-renderer",
  "ytd-compact-promoted-video-renderer",
  "ytd-promoted-sparkles-web-renderer"
].join(", ");
const SPONSORED_CTA_SELECTOR = [
  "button",
  "a",
  "[role='button']",
  "yt-button-shape button",
  ".yt-spec-button-shape-next"
].join(", ");
const DEFAULT_SETTINGS = {
  enabled: false,
  colors: {
    left: "#ffffff",
    top: "#ffffff",
    right: "#ffffff"
  }
};

const state = {
  settings: cloneSettings(DEFAULT_SETTINGS),
  toolbarSlot: null,
  fallbackMicButton: null,
  button: null,
  buttonLabel: null,
  panel: null,
  inputs: {},
  values: {},
  rafId: 0,
  observer: null,
  chipSyncTimers: [],
  ctaSyncIntervalId: 0,
  ctaDebugLogCount: 0
};

function cloneSettings(settings) {
  return {
    enabled: Boolean(settings?.enabled),
    colors: {
      left: normalizeHex(settings?.colors?.left ?? DEFAULT_SETTINGS.colors.left),
      top: normalizeHex(settings?.colors?.top ?? DEFAULT_SETTINGS.colors.top),
      right: normalizeHex(settings?.colors?.right ?? DEFAULT_SETTINGS.colors.right)
    }
  };
}

function normalizeHex(value) {
  const hex = typeof value === "string" ? value.trim() : "";
  return /^#[0-9a-fA-F]{6}$/.test(hex) ? hex.toLowerCase() : "#ffffff";
}

function hexToRgb(hex) {
  const normalized = normalizeHex(hex).slice(1);
  return {
    r: parseInt(normalized.slice(0, 2), 16),
    g: parseInt(normalized.slice(2, 4), 16),
    b: parseInt(normalized.slice(4, 6), 16)
  };
}

function getLinearChannel(channel) {
  const normalized = channel / 255;
  return normalized <= 0.04045
    ? normalized / 12.92
    : ((normalized + 0.055) / 1.055) ** 2.4;
}

function getRelativeLuminance(hex) {
  const { r, g, b } = hexToRgb(hex);
  return (
    0.2126 * getLinearChannel(r) +
    0.7152 * getLinearChannel(g) +
    0.0722 * getLinearChannel(b)
  );
}

function getContrastRatio(colorA, colorB) {
  const luminanceA = getRelativeLuminance(colorA);
  const luminanceB = getRelativeLuminance(colorB);
  const lighter = Math.max(luminanceA, luminanceB);
  const darker = Math.min(luminanceA, luminanceB);
  return (lighter + 0.05) / (darker + 0.05);
}

function getReadableForeground(color) {
  return getContrastRatio(color, DARK_FOREGROUND) >= getContrastRatio(color, LIGHT_FOREGROUND)
    ? DARK_FOREGROUND
    : LIGHT_FOREGROUND;
}

function getReadableMutedColor(foreground) {
  return foreground === LIGHT_FOREGROUND
    ? "rgba(248, 250, 252, 0.78)"
    : "rgba(15, 23, 42, 0.76)";
}

function setRegionToneData(root, region, foreground) {
  const tone = foreground === LIGHT_FOREGROUND ? "light" : "dark";

  if (region === "left") {
    root.dataset.ytbcLeftTone = tone;
    return;
  }

  if (region === "top") {
    root.dataset.ytbcTopTone = tone;
    return;
  }

  if (region === "right") {
    root.dataset.ytbcRightTone = tone;
  }
}

function setRegionContrastVariables(root, region, color) {
  const foreground = getReadableForeground(color);
  const muted = getReadableMutedColor(foreground);
  root.style.setProperty(`--ytbc-${region}-foreground`, foreground);
  root.style.setProperty(`--ytbc-${region}-muted`, muted);
  setRegionToneData(root, region, foreground);
}

function mixHexColors(primaryHex, secondaryHex, primaryWeight) {
  const safePrimaryWeight = Math.min(1, Math.max(0, primaryWeight));
  const secondaryWeight = 1 - safePrimaryWeight;
  const primary = hexToRgb(primaryHex);
  const secondary = hexToRgb(secondaryHex);

  const toHex = (value) => Math.round(value).toString(16).padStart(2, "0");

  return `#${
    toHex(primary.r * safePrimaryWeight + secondary.r * secondaryWeight)
  }${
    toHex(primary.g * safePrimaryWeight + secondary.g * secondaryWeight)
  }${
    toHex(primary.b * safePrimaryWeight + secondary.b * secondaryWeight)
  }`;
}

// Shift chip surfaces away from the label color so custom top colors do not wash out the text.
function getChipSurfaceColor(topColor, foreground) {
  const mixTarget = foreground === LIGHT_FOREGROUND
    ? DARK_FOREGROUND
    : LIGHT_FOREGROUND;
  let bestColor = topColor;
  let bestContrast = getContrastRatio(topColor, foreground);

  for (
    let topWeight = CHIP_SURFACE_START_WEIGHT;
    topWeight >= CHIP_SURFACE_MIN_WEIGHT;
    topWeight -= CHIP_SURFACE_STEP
  ) {
    const candidate = mixHexColors(topColor, mixTarget, topWeight);
    const contrast = getContrastRatio(candidate, foreground);

    if (contrast > bestContrast) {
      bestColor = candidate;
      bestContrast = contrast;
    }

    if (contrast >= MIN_CHIP_TEXT_CONTRAST) {
      return candidate;
    }
  }

  return bestColor;
}

function setImportantStyle(element, property, value) {
  if (!element) {
    return;
  }

  element.style.setProperty(property, value, "important");
}

function clearChipSyncTimers() {
  state.chipSyncTimers.forEach((timerId) => {
    clearTimeout(timerId);
  });

  state.chipSyncTimers = [];
}

function applySponsoredCtaStyles(root) {
  if (!(root instanceof HTMLElement)) {
    return;
  }

  const ctaTextColor = "#fff";
  const nodes = [root, ...root.querySelectorAll("*")];
  const textNodeSelectors = [
    ".yt-spec-button-shape-next__button-text-content",
    ".yt-spec-button-shape-next__label-text",
    ".ytAttributedStringHost",
    ".ytAttributedStringHost[role='text']",
    "span[role='text']",
    "yt-formatted-string",
    ".yt-core-attributed-string"
  ];

  nodes.forEach((node) => {
    if (!(node instanceof HTMLElement)) {
      return;
    }

    setImportantStyle(node, "--yt-spec-call-to-action", ctaTextColor);
    setImportantStyle(node, "--yt-spec-filled-button-text", ctaTextColor);
    setImportantStyle(node, "--yt-spec-static-brand-white", ctaTextColor);
    setImportantStyle(node, "--yt-spec-text-primary-inverse", ctaTextColor);
    setImportantStyle(node, "--yt-spec-text-primary", ctaTextColor);
    setImportantStyle(node, "--yt-spec-text-secondary", ctaTextColor);
    setImportantStyle(node, "color", ctaTextColor);
    setImportantStyle(node, "-webkit-text-fill-color", ctaTextColor);
    setImportantStyle(node, "fill", ctaTextColor);
    setImportantStyle(node, "stroke", ctaTextColor);
    setImportantStyle(node, "text-shadow", "0 0 0 #fff");
    setImportantStyle(node, "opacity", "1");
    setImportantStyle(node, "visibility", "visible");
    setImportantStyle(node, "mix-blend-mode", "normal");
    setImportantStyle(node, "filter", "none");
  });

  root.querySelectorAll(textNodeSelectors.join(", ")).forEach((node) => {
    if (!(node instanceof HTMLElement)) {
      return;
    }

    setImportantStyle(node, "color", ctaTextColor);
    setImportantStyle(node, "-webkit-text-fill-color", ctaTextColor);
    setImportantStyle(node, "--yt-spec-call-to-action", ctaTextColor);
    setImportantStyle(node, "--yt-spec-filled-button-text", ctaTextColor);
    setImportantStyle(node, "--yt-spec-text-primary", ctaTextColor);
    setImportantStyle(node, "--yt-spec-text-primary-inverse", ctaTextColor);
    setImportantStyle(node, "text-shadow", "0 0 0 #fff");
    setImportantStyle(node, "opacity", "1");
    setImportantStyle(node, "visibility", "visible");
    setImportantStyle(node, "mix-blend-mode", "normal");
    setImportantStyle(node, "filter", "none");
  });
}

function scheduleSponsoredCtaSync(root) {
  if (!(root instanceof HTMLElement)) {
    return;
  }

  CTA_SYNC_DELAYS.forEach((delay) => {
    setTimeout(() => {
      if (root.isConnected) {
        applySponsoredCtaStyles(root);
      }
    }, delay);
  });
}

function logCtaDiagnostics(node) {
  if (!(node instanceof HTMLElement) || state.ctaDebugLogCount >= CTA_DEBUG_LOG_LIMIT) {
    return;
  }

  const text = getNormalizedText(node);
  const ariaLabel = getNormalizedText(node.getAttribute("aria-label"));
  if (!(text.includes("visit site") || ariaLabel.includes("visit site"))) {
    return;
  }

  const computed = window.getComputedStyle(node);
  const parent = node.parentElement;
  const parentComputed = parent ? window.getComputedStyle(parent) : null;

  console.log("[YTBC CTA DEBUG]", {
    tag: node.tagName,
    className: node.className,
    text: node.textContent?.trim(),
    ariaLabel: node.getAttribute("aria-label"),
    color: computed.color,
    webkitTextFillColor: computed.webkitTextFillColor,
    opacity: computed.opacity,
    mixBlendMode: computed.mixBlendMode,
    textShadow: computed.textShadow,
    filter: computed.filter,
    transition: computed.transition,
    parentTag: parent?.tagName,
    parentClassName: parent?.className,
    parentColor: parentComputed?.color,
    parentWebkitTextFillColor: parentComputed?.webkitTextFillColor
  });

  state.ctaDebugLogCount += 1;
}

function ensureDirectCtaOverlay(button) {
  if (!(button instanceof HTMLElement)) {
    return;
  }

  const labelText = button.getAttribute("aria-label")?.trim() || button.textContent?.trim() || "Visit site";
  if (!labelText) {
    return;
  }

  const host = button.closest(".ytwAdButtonGroupViewModelHostPrimaryButton") || button;
  if (!(host instanceof HTMLElement)) {
    return;
  }

  host.setAttribute("data-ytbc-replacement-label", labelText);
  setImportantStyle(host, "position", "relative");
  setImportantStyle(host, "isolation", "isolate");
  setImportantStyle(host, "overflow", "hidden");

  let overlay = host.querySelector(":scope > .ytbc-cta-overlay");
  if (!(overlay instanceof HTMLSpanElement)) {
    overlay = document.createElement("span");
    overlay.className = "ytbc-cta-overlay";
    overlay.setAttribute("aria-hidden", "true");
    host.appendChild(overlay);
  }

  overlay.textContent = labelText;
  setImportantStyle(overlay, "position", "absolute");
  setImportantStyle(overlay, "inset", "0");
  setImportantStyle(overlay, "display", "flex");
  setImportantStyle(overlay, "align-items", "center");
  setImportantStyle(overlay, "justify-content", "center");
  setImportantStyle(overlay, "pointer-events", "none");
  setImportantStyle(overlay, "z-index", "9999");
  setImportantStyle(overlay, "color", "#fff");
  setImportantStyle(overlay, "-webkit-text-fill-color", "#fff");
  setImportantStyle(overlay, "text-shadow", "0 0 0 #fff");
  setImportantStyle(overlay, "font", "inherit");
  setImportantStyle(overlay, "font-size", "inherit");
  setImportantStyle(overlay, "font-weight", "inherit");
  setImportantStyle(overlay, "letter-spacing", "inherit");
  setImportantStyle(overlay, "line-height", "inherit");
  setImportantStyle(overlay, "white-space", "nowrap");
  setImportantStyle(overlay, "mix-blend-mode", "normal");
  setImportantStyle(overlay, "filter", "none");
  setImportantStyle(overlay, "opacity", "1");
  setImportantStyle(overlay, "visibility", "visible");
}

function ensureProxyCtaButton(button) {
  if (!(button instanceof HTMLAnchorElement)) {
    return;
  }

  const labelText = button.getAttribute("aria-label")?.trim() || button.textContent?.trim() || "Visit site";
  const host = button.closest(".ytwAdButtonGroupViewModelHostPrimaryButton") || button.parentElement;
  if (!(host instanceof HTMLElement) || !labelText) {
    return;
  }

  host.setAttribute("data-ytbc-proxy-host", "true");
  setImportantStyle(host, "position", "relative");

  button.setAttribute("data-ytbc-original-cta", "true");
  setImportantStyle(button, "opacity", "0");
  setImportantStyle(button, "visibility", "hidden");
  setImportantStyle(button, "pointer-events", "none");

  let proxy = host.querySelector(":scope > .ytbc-cta-proxy");
  if (!(proxy instanceof HTMLAnchorElement)) {
    proxy = document.createElement("a");
    proxy.className = "ytbc-cta-proxy";
    proxy.setAttribute("aria-hidden", "true");
    proxy.href = button.href || "#";
    proxy.target = button.target || "_blank";
    proxy.rel = button.rel || "nofollow";
    proxy.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      button.click();
    });
    host.appendChild(proxy);
  }

  proxy.textContent = labelText;
  proxy.href = button.href || "#";
  proxy.target = button.target || "_blank";
  proxy.rel = button.rel || "nofollow";
}

function normalizeDirectAdCtas() {
  const directCtaSelectors = [
    "a[aria-label='Visit site']",
    "a[aria-label='Sign up']",
    ".ytwAdButtonGroupViewModelHostPrimaryButton a",
    "ad-button-view-model a"
  ];

  document.querySelectorAll(directCtaSelectors.join(", ")).forEach((node) => {
    if (!(node instanceof HTMLElement)) {
      return;
    }

    if (!isSponsoredCtaNode(node)) {
      return;
    }

    node.setAttribute("data-ytbc-ad-cta", "true");
    applySponsoredCtaStyles(node);
    scheduleSponsoredCtaSync(node);
    setImportantStyle(node, "transition", "none");
    ensureDirectCtaOverlay(node);
    ensureProxyCtaButton(node);
    logCtaDiagnostics(node);

    const styledAncestors = [
      node.closest(".ytwAdButtonGroupViewModelHostPrimaryButton"),
      node.closest("ad-button-view-model"),
      node.closest("yt-button-shape, button, a, [role='button']")
    ];

    styledAncestors.forEach((ancestor) => {
      if (ancestor instanceof HTMLElement) {
        ancestor.setAttribute("data-ytbc-ad-cta", "true");
        applySponsoredCtaStyles(ancestor);
        scheduleSponsoredCtaSync(ancestor);
        setImportantStyle(ancestor, "transition", "none");
        if (ancestor.matches("a, button, [role='button']")) {
          ensureDirectCtaOverlay(ancestor);
        }
        logCtaDiagnostics(ancestor);
      }
    });

    node.querySelectorAll(
      ".yt-spec-button-shape-next__button-text-content, .yt-spec-button-shape-next__label-text, .ytAttributedStringHost, .ytAttributedStringHost[role='text'], span[role='text'], yt-formatted-string, .yt-core-attributed-string"
    ).forEach((textNode) => {
      if (textNode instanceof HTMLElement) {
        textNode.setAttribute("data-ytbc-ad-cta", "true");
        applySponsoredCtaStyles(textNode);
        scheduleSponsoredCtaSync(textNode);
        setImportantStyle(textNode, "color", "transparent");
        setImportantStyle(textNode, "-webkit-text-fill-color", "transparent");
        setImportantStyle(textNode, "text-shadow", "none");
      }
    });
  });
}

function ensureCtaSyncLoop() {
  if (state.ctaSyncIntervalId) {
    clearInterval(state.ctaSyncIntervalId);
  }

  state.ctaSyncIntervalId = window.setInterval(() => {
    if (!state.settings.enabled) {
      return;
    }

    normalizeDirectAdCtas();
  }, CTA_RESYNC_INTERVAL_MS);
}

function getTopChipPalette() {
  const topColor = normalizeHex(state.settings.colors.top);
  const foreground = getReadableForeground(topColor);
  const surface = getChipSurfaceColor(topColor, foreground);

  return {
    surface,
    selectedSurface: foreground,
    foreground,
    selectedForeground: topColor
  };
}

function getChipElements() {
  return Array.from(document.querySelectorAll(
    "ytd-feed-filter-chip-bar-renderer yt-chip-cloud-chip-renderer, #chips-wrapper yt-chip-cloud-chip-renderer"
  ));
}

function getChipSurface(chip) {
  return (
    chip.querySelector("chip-shape .ytChipShapeChip") ||
    chip.querySelector("#chip-container") ||
    chip.querySelector(".yt-spec-button-shape-next")
  );
}

function getChipLabel(chip, chipSurface) {
  const textSelectors = [
    ".yt-spec-button-shape-next__button-text-content",
    ".yt-spec-button-shape-next__label-text",
    "yt-formatted-string",
    ".yt-core-attributed-string"
  ];

  for (const selector of textSelectors) {
    const match = chip.querySelector(selector) || chipSurface?.querySelector(selector);
    if (match?.textContent?.replace(/\s+/g, " ").trim()) {
      return match;
    }
  }

  const surfaceChildren = Array.from(chipSurface?.children || []);
  return surfaceChildren.find((child) => {
    if (!(child instanceof HTMLElement)) {
      return false;
    }

    if (child.classList.contains("yt-spec-touch-feedback-shape")) {
      return false;
    }

    return Boolean(child.textContent?.replace(/\s+/g, " ").trim());
  }) || null;
}

function clearChipFallbackLabel(chipSurface) {
  chipSurface?.querySelectorAll(".ytbc-chip-label-fallback").forEach((label) => {
    label.remove();
  });
}

function isSelectedChip(chip, button, chipSurface) {
  return (
    chip.hasAttribute("selected") ||
    chip.hasAttribute("is-selected") ||
    chip.classList.contains("iron-selected") ||
    button?.getAttribute("aria-selected") === "true" ||
    chipSurface?.classList.contains("ytChipShapeActive")
  );
}

function applyChipRowStyles() {
  if (!state.settings.enabled) {
    return;
  }

  const chips = getChipElements();
  if (!chips.length) {
    return;
  }

  const palette = getTopChipPalette();

  chips.forEach((chip) => {
    const button = chip.querySelector("chip-shape button, button");
    const chipSurface = getChipSurface(chip);
    const label = getChipLabel(chip, chipSurface);
    const feedback = chipSurface?.querySelector(".yt-spec-touch-feedback-shape");
    const feedbackFill = chipSurface?.querySelector(".yt-spec-touch-feedback-shape__fill");
    const feedbackStroke = chipSurface?.querySelector(".yt-spec-touch-feedback-shape__stroke");
    const isSelected = isSelectedChip(chip, button, chipSurface);
    const backgroundColor = isSelected ? palette.selectedSurface : palette.surface;
    const textColor = isSelected ? palette.selectedForeground : palette.foreground;
    const contentNodes = [chip, ...chip.querySelectorAll("*")];

    setImportantStyle(chip, "color", textColor);
    setImportantStyle(chip, "--yt-spec-text-primary", textColor);
    setImportantStyle(chip, "--yt-spec-text-secondary", textColor);
    setImportantStyle(chip, "--yt-spec-call-to-action", textColor);

    setImportantStyle(button, "background", "transparent");
    setImportantStyle(button, "background-color", "transparent");
    setImportantStyle(button, "color", textColor);
    setImportantStyle(button, "-webkit-text-fill-color", textColor);
    setImportantStyle(button, "--yt-spec-text-primary", textColor);
    setImportantStyle(button, "--yt-spec-text-secondary", textColor);
    setImportantStyle(button, "--yt-spec-call-to-action", textColor);

    setImportantStyle(chipSurface, "position", "relative");
    setImportantStyle(chipSurface, "isolation", "isolate");
    setImportantStyle(chipSurface, "background", backgroundColor);
    setImportantStyle(chipSurface, "background-color", backgroundColor);
    setImportantStyle(chipSurface, "border-radius", "999px");
    setImportantStyle(chipSurface, "box-shadow", "none");
    setImportantStyle(chipSurface, "color", textColor);
    setImportantStyle(chipSurface, "-webkit-text-fill-color", textColor);
    setImportantStyle(chipSurface, "--yt-spec-text-primary", textColor);
    setImportantStyle(chipSurface, "--yt-spec-text-secondary", textColor);
    setImportantStyle(chipSurface, "--yt-spec-call-to-action", textColor);

    setImportantStyle(feedback, "z-index", "0");
    setImportantStyle(feedbackFill, "z-index", "0");
    setImportantStyle(feedbackStroke, "border-color", "transparent");
    clearChipFallbackLabel(chipSurface);

    contentNodes.forEach((node) => {
      if (
        node.classList?.contains("yt-spec-touch-feedback-shape") ||
        node.classList?.contains("yt-spec-touch-feedback-shape__fill") ||
        node.classList?.contains("yt-spec-touch-feedback-shape__stroke")
      ) {
        return;
      }

      setImportantStyle(node, "color", textColor);
      setImportantStyle(node, "-webkit-text-fill-color", textColor);
      setImportantStyle(node, "fill", textColor);
      setImportantStyle(node, "opacity", "1");
      setImportantStyle(node, "visibility", "visible");
      setImportantStyle(node, "--yt-spec-text-primary", textColor);
      setImportantStyle(node, "--yt-spec-text-secondary", textColor);
      setImportantStyle(node, "--yt-spec-call-to-action", textColor);
    });

    if (!label) {
      return;
    }

    const labelNodes = [label, ...label.querySelectorAll("*")];
    labelNodes.forEach((node) => {
      setImportantStyle(node, "color", textColor);
      setImportantStyle(node, "-webkit-text-fill-color", textColor);
      setImportantStyle(node, "fill", textColor);
      setImportantStyle(node, "opacity", "1");
      setImportantStyle(node, "visibility", "visible");
    });

    setImportantStyle(label, "display", "block");
    setImportantStyle(label, "position", "relative");
    setImportantStyle(label, "z-index", "1");
    setImportantStyle(label, "font-size", "14px");
    setImportantStyle(label, "line-height", "20px");
    setImportantStyle(label, "font-weight", "500");
    setImportantStyle(label, "text-shadow", "0 0 0 currentColor");
    setImportantStyle(label, "mix-blend-mode", "normal");
  });
}

function scheduleChipRowSync() {
  clearChipSyncTimers();
  applyChipRowStyles();

  CHIP_SYNC_DELAYS.forEach((delay) => {
    const timerId = setTimeout(() => {
      applyChipRowStyles();
    }, delay);

    state.chipSyncTimers.push(timerId);
  });
}

function storageGet(key) {
  return new Promise((resolve) => {
    if (!chrome?.storage?.local) {
      resolve({});
      return;
    }

    chrome.storage.local.get(key, (result) => {
      resolve(result || {});
    });
  });
}

function storageSet(payload) {
  return new Promise((resolve) => {
    if (!chrome?.storage?.local) {
      resolve();
      return;
    }

    chrome.storage.local.set(payload, () => resolve());
  });
}

function setRootVariables() {
  const root = document.documentElement;
  const chipPalette = getTopChipPalette();
  root.style.setProperty("--ytbc-left-color", state.settings.colors.left);
  root.style.setProperty("--ytbc-top-color", state.settings.colors.top);
  root.style.setProperty("--ytbc-right-color", state.settings.colors.right);
  root.style.setProperty("--ytbc-chip-bg", chipPalette.surface);
  root.style.setProperty("--ytbc-chip-text", chipPalette.foreground);
  root.style.setProperty("--ytbc-chip-active-bg", chipPalette.selectedSurface);
  root.style.setProperty("--ytbc-chip-active-text", chipPalette.selectedForeground);
  setRegionContrastVariables(root, "left", state.settings.colors.left);
  setRegionContrastVariables(root, "top", state.settings.colors.top);
  setRegionContrastVariables(root, "right", state.settings.colors.right);
  root.classList.toggle("ytbc-enabled", state.settings.enabled);
  root.classList.toggle("ytbc-watch-page", isWatchPage());
  scheduleChipRowSync();
}

function updatePreviewValues() {
  ["left", "top", "right"].forEach((region) => {
    if (state.inputs[region]) {
      state.inputs[region].value = state.settings.colors[region];
    }

    if (state.values[region]) {
      state.values[region].textContent = state.settings.colors[region].toUpperCase();
    }
  });

  if (state.buttonLabel) {
    state.buttonLabel.textContent = state.settings.enabled ? "Colors On" : "Colors";
  }
}

async function persistSettings() {
  await storageSet({
    [STORAGE_KEY]: state.settings
  });
}

function getVisibleRect(element) {
  if (!element) {
    return null;
  }

  const rect = element.getBoundingClientRect();
  if (rect.width <= 0 && rect.height <= 0) {
    return null;
  }

  if (rect.right <= 0 || rect.bottom <= 0) {
    return null;
  }

  if (rect.left >= window.innerWidth || rect.top >= window.innerHeight) {
    return null;
  }

  return rect;
}

function getMaxWidth(selectors) {
  return selectors.reduce((maxWidth, selector) => {
    const rect = getVisibleRect(document.querySelector(selector));
    return rect ? Math.max(maxWidth, rect.width) : maxWidth;
  }, 0);
}

function getMaxRight(selectors) {
  return selectors.reduce((maxRight, selector) => {
    const rect = getVisibleRect(document.querySelector(selector));
    return rect ? Math.max(maxRight, rect.right) : maxRight;
  }, 0);
}

function getExpandedLeftWidth() {
  const expandedRight = getMaxRight([
    "ytd-guide-renderer",
    "tp-yt-app-drawer[opened] #guide-content",
    "tp-yt-app-drawer[opened] #guide-inner-content",
    "tp-yt-app-drawer[opened] #contentContainer"
  ]);

  return expandedRight > 0 ? expandedRight : 0;
}

function getCompactLeftWidth() {
  const miniGuideRight = getMaxRight([
    "ytd-mini-guide-renderer"
  ]);

  if (miniGuideRight > 0) {
    return miniGuideRight;
  }

  const guideButton = document.querySelector("ytd-masthead #guide-button");
  const guideRect = getVisibleRect(guideButton);

  if (!guideRect) {
    return 0;
  }

  return guideRect.right;
}

function getMastheadReference() {
  return (
    document.querySelector("ytd-masthead") ||
    document.querySelector("#masthead")
  );
}

function isWatchPage() {
  return window.location.pathname === "/watch";
}

function updateLeftTopFill() {
  const root = document.documentElement;
  const watchPage = isWatchPage();
  root.classList.toggle("ytbc-watch-page", watchPage);

  const masthead = getMastheadReference();
  const expandedWidth = getExpandedLeftWidth();
  const compactWidth = getCompactLeftWidth();
  const useExpandedWidth =
    state.settings.enabled &&
    !watchPage &&
    expandedWidth >= LEFT_PANEL_HOME_TOUCH_THRESHOLD;
  const width = useExpandedWidth ? expandedWidth : compactWidth;
  const leftPanelMode =
    useExpandedWidth
      ? "expanded"
      : "compact";

  root.dataset.ytbcLeftPanel = leftPanelMode;

  if (!state.settings.enabled || watchPage || !masthead || width <= 0) {
    root.style.setProperty("--ytbc-left-fill-width", "0px");
    return;
  }

  root.style.setProperty("--ytbc-left-fill-width", `${Math.round(width)}px`);
}

function removeUnwantedYoodleHomeButtons() {
  document.querySelectorAll("ytd-masthead ytd-yoodle-renderer, ytd-yoodle-renderer").forEach((el) => {
    if (el instanceof HTMLElement) {
      el.remove();
    }
  });

  document.querySelectorAll('ytd-masthead img.style-scope.ytd-yoodle-renderer, img.style-scope.ytd-yoodle-renderer').forEach((el) => {
    if (el instanceof HTMLElement) {
      el.remove();
    }
  });
}

function scheduleLayoutRefresh() {
  if (state.rafId) {
    cancelAnimationFrame(state.rafId);
  }

  state.rafId = requestAnimationFrame(() => {
    state.rafId = 0;
    removeUnwantedYoodleHomeButtons();
    mountToolbarButton();
    fixUnwantedOutlinedElements();
    normalizeSponsoredFeedAds();
    normalizeDirectAdCtas();
    updateLeftTopFill();
    scheduleChipRowSync();
  });
}

function getNormalizedText(node) {
  return node?.textContent?.replace(/\s+/g, " ").trim().toLowerCase() || "";
}

function hasSponsoredLabel(card) {
  const text = getNormalizedText(card);
  return text.includes("sponsored");
}

function matchesLargeAdCtaLabel(text) {
  return LARGE_AD_CTA_LABELS.includes(text);
}

function getNormalizedAttributeText(element, attributeName) {
  if (!(element instanceof Element)) {
    return "";
  }

  return element.getAttribute(attributeName)?.replace(/\s+/g, " ").trim().toLowerCase() || "";
}

function isSponsoredCtaNode(node, scopedRoot = null) {
  if (!(node instanceof HTMLElement)) {
    return false;
  }

  const text = getNormalizedText(node);
  const ariaLabel = getNormalizedAttributeText(node, "aria-label");
  const title = getNormalizedAttributeText(node, "title");
  if (
    matchesLargeAdCtaLabel(text) ||
    matchesLargeAdCtaLabel(ariaLabel) ||
    matchesLargeAdCtaLabel(title)
  ) {
    return true;
  }

  const scope = scopedRoot instanceof HTMLElement ? scopedRoot : document.body;
  const structuralMatches = [
    ".ytwAdButtonGroupViewModelHostPrimaryButton",
    "ad-button-view-model",
    ".yt-spec-button-shape-next--filled",
    ".yt-spec-button-shape-next--mono",
    "[class*='AdButton']",
    "[data-ytbc-sponsored-card='true']"
  ];

  return structuralMatches.some((selector) => {
    const closest = node.closest(selector);
    return closest instanceof HTMLElement && scope.contains(closest);
  });
}

function markSponsoredCardCtas(card) {
  if (!(card instanceof HTMLElement)) {
    return;
  }

  card.querySelectorAll("[data-ytbc-ad-cta='true']").forEach((node) => {
    if (node instanceof HTMLElement) {
      node.removeAttribute("data-ytbc-ad-cta");
    }
  });

  card.querySelectorAll(SPONSORED_CTA_SELECTOR).forEach((node) => {
    if (!(node instanceof HTMLElement)) {
      return;
    }

    if (!isSponsoredCtaNode(node, card)) {
      return;
    }

    node.setAttribute("data-ytbc-ad-cta", "true");
    applySponsoredCtaStyles(node);
    scheduleSponsoredCtaSync(node);

    const styledAncestor = node.closest("yt-button-shape, button, a, [role='button']");
    if (styledAncestor instanceof HTMLElement) {
      styledAncestor.setAttribute("data-ytbc-ad-cta", "true");
      applySponsoredCtaStyles(styledAncestor);
      scheduleSponsoredCtaSync(styledAncestor);
    }
  });
}

function normalizeSponsoredFeedAds() {
  const cards = document.querySelectorAll(
    "ytd-rich-item-renderer, ytd-rich-section-renderer, ytd-video-renderer, ytd-compact-promoted-video-renderer"
  );

  cards.forEach((card) => {
    if (!(card instanceof HTMLElement)) {
      return;
    }

    if (hasSponsoredLabel(card)) {
      card.setAttribute("data-ytbc-sponsored-card", "true");
      card.style.removeProperty("display");
      card.removeAttribute("data-ytbc-hidden-large-ad");

      card.querySelectorAll(SPONSORED_RENDERER_SELECTOR)
        .forEach((renderer) => {
          if (renderer instanceof HTMLElement) {
            renderer.setAttribute("data-ytbc-ad-renderer", "true");
          }
        });

      markSponsoredCardCtas(card);
      return;
    }

    card.removeAttribute("data-ytbc-sponsored-card");
    card.style.removeProperty("display");
    card.removeAttribute("data-ytbc-hidden-large-ad");

    card.querySelectorAll("[data-ytbc-ad-renderer='true']")
      .forEach((renderer) => {
        if (renderer instanceof HTMLElement) {
          renderer.removeAttribute("data-ytbc-ad-renderer");
        }
      });

    card.querySelectorAll("[data-ytbc-ad-cta='true']")
      .forEach((node) => {
        if (node instanceof HTMLElement) {
          node.removeAttribute("data-ytbc-ad-cta");
        }
      });
  });
}

function clearOutlineStyles(element) {
  if (!(element instanceof HTMLElement)) {
    return;
  }

  element.style.setProperty("border", "none", "important");
  element.style.setProperty("outline", "none", "important");
  element.style.setProperty("box-shadow", "none", "important");
}

function clearOutlineStylesDeep(root) {
  if (!(root instanceof HTMLElement)) {
    return;
  }

  clearOutlineStyles(root);

  root.querySelectorAll("*").forEach((node) => {
    if (node instanceof HTMLElement) {
      clearOutlineStyles(node);
    }
  });
}

function findElementByExactText(text) {
  const trimmedText = text.trim();
  const candidates = Array.from(document.querySelectorAll("body *"));

  return candidates.find((node) => (
    node instanceof HTMLElement &&
    node.children.length === 0 &&
    node.textContent?.trim() === trimmedText
  )) ?? null;
}

function fixUnwantedOutlinedElements() {
  const signinPromo = document.querySelector("ytd-guide-signin-promo-renderer, #signin-promo");
  if (signinPromo instanceof HTMLElement) {
    clearOutlineStylesDeep(signinPromo);
    [signinPromo.parentElement, signinPromo.closest("ytd-guide-section-renderer"), signinPromo.closest("tp-yt-paper-item")]
      .forEach((element) => {
        if (element instanceof HTMLElement) {
          clearOutlineStyles(element);
        }
      });
  }

  const addShortcutLabel = findElementByExactText("Add shortcut");
  if (addShortcutLabel instanceof HTMLElement) {
    const shortcutRoot = addShortcutLabel.closest("[aria-label], [title], button, a, div") || addShortcutLabel;
    clearOutlineStylesDeep(shortcutRoot);
    [shortcutRoot.parentElement, shortcutRoot.closest("ytd-button-renderer"), shortcutRoot.closest("yt-button-view-model")]
      .forEach((element) => {
        if (element instanceof HTMLElement) {
          clearOutlineStyles(element);
        }
      });
  }
}

function closePanel() {
  if (!state.panel || !state.button) {
    return;
  }

  state.panel.hidden = true;
  state.button.dataset.open = "false";
  state.button.setAttribute("aria-expanded", "false");
}

function openPanel() {
  if (!state.panel || !state.button) {
    return;
  }

  const rect = state.button.getBoundingClientRect();
  const panelWidth = Math.min(320, window.innerWidth - 24);
  const left = Math.max(12, Math.min(window.innerWidth - panelWidth - 12, rect.right - panelWidth));

  state.panel.hidden = false;
  state.panel.style.top = `${Math.max(76, rect.bottom + 12)}px`;
  state.panel.style.left = `${left}px`;
  state.panel.style.right = "auto";
  state.button.dataset.open = "true";
  state.button.setAttribute("aria-expanded", "true");
}

function togglePanel() {
  if (!state.panel) {
    return;
  }

  if (state.panel.hidden) {
    openPanel();
  } else {
    closePanel();
  }
}

async function handleColorChange(region, value) {
  state.settings.colors[region] = normalizeHex(value);
  state.settings.enabled = true;
  setRootVariables();
  updatePreviewValues();
  updateLeftTopFill();
  await persistSettings();
}

async function resetSettings() {
  state.settings = cloneSettings({
    ...DEFAULT_SETTINGS,
    enabled: state.settings.enabled
  });
  setRootVariables();
  updatePreviewValues();
  updateLeftTopFill();
  await persistSettings();
}

function createPanel() {
  if (state.panel) {
    return;
  }

  const panel = document.createElement("section");
  panel.id = "ytbc-panel";
  panel.hidden = true;
  panel.innerHTML = `
    <div class="ytbc-panel-header">
      <div>
        <h2 class="ytbc-panel-title">YouTube frame colors</h2>
        <p class="ytbc-panel-subtitle">Pick a color for the left rail, top bar, and main video area.</p>
      </div>
      <button class="ytbc-close-button" type="button" aria-label="Close color panel">x</button>
    </div>
    <div class="ytbc-preview" aria-hidden="true">
      <div class="ytbc-preview-left"></div>
      <div class="ytbc-preview-top"></div>
      <div class="ytbc-preview-right"></div>
      <div class="ytbc-preview-center"></div>
      <span class="ytbc-preview-mic" title="Voice search preview">
        <span class="ytbc-preview-mic-icon"></span>
      </span>
      <span class="ytbc-preview-line" data-line="left"></span>
      <span class="ytbc-preview-line" data-line="top"></span>
    </div>
    <div class="ytbc-fields">
      ${createFieldMarkup("left", "Left panel", "Sidebar area")}
      ${createFieldMarkup("top", "Top side", "Header and chips")}
      ${createFieldMarkup("right", "Middle area", "Main videos and thumbnails")}
    </div>
    <div class="ytbc-panel-footer">
      <p class="ytbc-footer-note">Changes save automatically and stay on YouTube after refresh.</p>
      <button class="ytbc-reset-button" type="button">Reset</button>
    </div>
  `;

  panel.querySelector(".ytbc-close-button")?.addEventListener("click", closePanel);
  panel.querySelector(".ytbc-reset-button")?.addEventListener("click", () => {
    resetSettings();
  });

  ["left", "top", "right"].forEach((region) => {
    const input = panel.querySelector(`.ytbc-color-input[data-region='${region}']`);
    const value = panel.querySelector(`.ytbc-color-value[data-region='${region}']`);
    state.inputs[region] = input;
    state.values[region] = value;

    input?.addEventListener("input", (event) => {
      handleColorChange(region, event.target.value);
    });
  });

  document.body.appendChild(panel);
  state.panel = panel;
  updatePreviewValues();
}

function createFieldMarkup(region, title, hint) {
  return `
    <label class="ytbc-field">
      <span class="ytbc-field-label">
        <span class="ytbc-field-title">${title}</span>
        <span class="ytbc-field-hint">${hint}</span>
      </span>
      <input class="ytbc-color-input" data-region="${region}" type="color" value="${state.settings.colors[region]}" />
      <span class="ytbc-color-value" data-region="${region}">${state.settings.colors[region].toUpperCase()}</span>
    </label>
  `;
}

function createToolbarButton() {
  if (state.toolbarSlot) {
    return state.toolbarSlot;
  }

  const slot = document.createElement("div");
  slot.id = "ytbc-toolbar-slot";

  const button = document.createElement("button");
  button.id = "ytbc-toolbar-button";
  button.type = "button";
  button.dataset.open = "false";
  button.setAttribute("aria-haspopup", "dialog");
  button.setAttribute("aria-expanded", "false");
  button.innerHTML = `
    <span class="ytbc-toolbar-icon" aria-hidden="true"></span>
    <span class="ytbc-toolbar-text">Colors</span>
  `;

  button.addEventListener("click", () => {
    togglePanel();
  });

  slot.appendChild(button);
  state.toolbarSlot = slot;
  state.button = button;
  state.buttonLabel = button.querySelector(".ytbc-toolbar-text");
  updatePreviewValues();
  return slot;
}

function createFallbackMicButton() {
  if (state.fallbackMicButton) {
    return state.fallbackMicButton;
  }

  const button = document.createElement("button");
  button.className = "yt-spec-button-shape-next yt-spec-button-shape-next--text yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-only-default yt-spec-button-shape-next--enable-backdrop-filter-experiment";
  button.type = "button";
  button.setAttribute("aria-label", "Search with your voice");
  button.setAttribute("title", "");
  button.setAttribute("aria-disabled", "false");
  button.dataset.ytbccMicButton = "true";
  button.innerHTML = `<span id="ytbcc-mic-icon" aria-hidden="true"></span>`;

  button.addEventListener("click", () => {
    const searchInput = document.querySelector(
      "ytd-searchbox input#search, ytd-searchbox #search input, input[name='search_query']"
    );

    if (searchInput instanceof HTMLElement) {
      searchInput.focus();
      searchInput.click();
    }
  });

  state.fallbackMicButton = button;
  return button;
}

function getMastheadStart() {
  return (
    document.querySelector("ytd-masthead #start") ||
    document.querySelector("#start")
  );
}

function getGuideButtonAnchor() {
  const start = getMastheadStart();
  return start?.querySelector("#guide-button") || null;
}

function getToolbarAnchor() {
  return (
    document.querySelector("ytd-masthead #voice-search-button") ||
    document.querySelector("#voice-search-button")
  );
}

function hasVisibleNativeMicButton() {
  const nativeButton = document.querySelector(
    "ytd-masthead #voice-search-button, #voice-search-button"
  );
  return Boolean(getVisibleRect(nativeButton));
}

function mountToolbarButton() {
  const slot = createToolbarButton();
  const anchor = getToolbarAnchor();
  if (!anchor || !hasVisibleNativeMicButton()) {
    slot.remove();
    return;
  }

  if (anchor.nextElementSibling !== slot) {
    anchor.insertAdjacentElement("afterend", slot);
  }
}

function setupGlobalEvents() {
  document.addEventListener("click", (event) => {
    if (!state.panel || state.panel.hidden) {
      return;
    }

    const target = event.target;
    if (state.panel.contains(target) || state.button?.contains(target)) {
      return;
    }

    closePanel();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closePanel();
    }
  });

  window.addEventListener("resize", scheduleLayoutRefresh, { passive: true });
  window.addEventListener("yt-navigate-finish", scheduleLayoutRefresh, { passive: true });

  const observer = new MutationObserver(() => {
    scheduleLayoutRefresh();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  state.observer = observer;
}

async function initialize() {
  const stored = await storageGet(STORAGE_KEY);
  state.settings = cloneSettings(stored?.[STORAGE_KEY] ?? DEFAULT_SETTINGS);
  createPanel();
  setRootVariables();
  updatePreviewValues();
  setupGlobalEvents();
  ensureCtaSyncLoop();
  scheduleLayoutRefresh();
}

initialize();
