const GOOGLE_SERVICE_ICON_PATHS = {
  account: "app-icons/account.svg",
  search: "app-icons/search.png",
  maps: "app-icons/maps.png",
  news: "app-icons/news.png",
  gmail: "app-icons/gmail.png",
  meet: "app-icons/meet.png",
  chat: "app-icons/chat.png",
  contacts: "app-icons/contacts.png",
  drive: "app-icons/drive.png",
  calendar: "app-icons/calendar.png",
  play: "app-icons/play.png",
  translate: "app-icons/translate.png",
  photos: "app-icons/photos.png",
  shopping: "app-icons/shopping.png",
  finance: "app-icons/finance.png",
  docs: "app-icons/docs.png",
  sheets: "app-icons/sheets.png",
  slides: "app-icons/slides.png",
  books: "app-icons/books.png",
  blogger: "app-icons/blogger.png",
  keep: "app-icons/keep.png",
  earth: "app-icons/earth.png",
  saved: "app-icons/saved.svg",
  "arts-culture": "app-icons/arts-culture.svg",
  ads: "app-icons/ads.png",
  "merchant-center": "app-icons/merchant-center.png",
  travel: "app-icons/travel.png",
  forms: "app-icons/forms.png",
  store: "app-icons/store.png",
  analytics: "app-icons/analytics.png",
  "chrome-web-store": "app-icons/chrome-web-store.png",
  youtube: "app-icons/youtube.svg",
  "youtube-music": "app-icons/youtube-music.svg"
};

const GOOGLE_APPS = [
  { name: "Account", url: "https://myaccount.google.com/", iconKey: "account" },
  { name: "Search", url: "https://www.google.com/", iconKey: "search" },
  { name: "Maps", url: "https://maps.google.com/", iconKey: "maps" },
  { name: "YouTube", url: "https://www.youtube.com/", iconKey: "youtube" },
  { name: "News", url: "https://news.google.com/", iconKey: "news" },
  { name: "Gmail", url: "https://mail.google.com/mail/", iconKey: "gmail" },
  { name: "Meet", url: "https://meet.google.com/?hs=197", iconKey: "meet" },
  { name: "Chat", url: "https://chat.google.com/", iconKey: "chat" },
  { name: "Contacts", url: "https://contacts.google.com/", iconKey: "contacts" },
  { name: "Drive", url: "https://drive.google.com/", iconKey: "drive" },
  { name: "Calendar", url: "https://calendar.google.com/calendar/", iconKey: "calendar" },
  { name: "Play", url: "https://play.google.com/", iconKey: "play" },
  { name: "Translate", url: "https://translate.google.com/", iconKey: "translate" },
  { name: "Photos", url: "https://photos.google.com/", iconKey: "photos" },
  { name: "Shopping", url: "https://www.google.com/shopping?source=og", iconKey: "shopping" },
  { name: "Finance", url: "https://www.google.com/finance/", iconKey: "finance" },
  { name: "Docs", url: "https://docs.google.com/document/?usp=docs_alc", iconKey: "docs" },
  { name: "Sheets", url: "https://docs.google.com/spreadsheets/?usp=sheets_alc", iconKey: "sheets" },
  { name: "Slides", url: "https://docs.google.com/presentation/?usp=slides_alc", iconKey: "slides" },
  { name: "Books", url: "https://books.google.com/", iconKey: "books" },
  { name: "Blogger", url: "https://www.blogger.com/", iconKey: "blogger" },
  { name: "Keep", url: "https://keep.google.com/", iconKey: "keep" },
  { name: "Earth", url: "https://earth.google.com/web/", iconKey: "earth" },
  { name: "Saved", url: "https://www.google.com/save", iconKey: "saved" },
  { name: "Arts and Culture", url: "https://artsandculture.google.com/", iconKey: "arts-culture" },
  { name: "Google Ads", url: "https://ads.google.com/", iconKey: "ads" },
  { name: "Merchant Center", url: "https://merchants.google.com/", iconKey: "merchant-center" },
  { name: "Travel", url: "https://www.google.com/travel/", iconKey: "travel" },
  { name: "Forms", url: "https://docs.google.com/forms/", iconKey: "forms" },
  { name: "Store", url: "https://store.google.com/", iconKey: "store" },
  { name: "Chrome Web Store", url: "https://chrome.google.com/webstore?utm_source=app-launcher", iconKey: "chrome-web-store" },
  { name: "Google Analytics", url: "https://analytics.google.com/analytics/web?utm_source=OGB&utm_medium=app", iconKey: "analytics" },
  { name: "YouTube Music", url: "https://music.youtube.com?utm_source=app_launcher", iconKey: "youtube-music" }
];
const GOOGLE_ENHANCED_BUILD_LABEL = `Google Enhanced - ${GOOGLE_APPS.length} apps`;

const shortcutsGrid = document.getElementById("shortcuts-grid");
const searchForm = document.getElementById("search-form");
const searchInput = document.getElementById("search-input");
const googleSignInLink = document.getElementById("google-sign-in");

const GOOGLE_SIGN_IN_BASE_URL = "https://accounts.google.com/ServiceLogin";
const GOOGLE_SIGN_IN_CONTINUE_URL = "https://www.google.com/?ge_extension_return=1";
const GOOGLE_ACCOUNT_HOME_URL = "https://myaccount.google.com/";
const GOOGLE_ACCOUNT_UI_STATE_KEY = "googleAccountUiState";
const GOOGLE_COOKIE_CHECK_URLS = [
  "https://www.google.com/",
  "https://accounts.google.com/",
  "https://myaccount.google.com/",
  "https://docs.google.com/",
  "https://slides.google.com/",
  "https://mail.google.com/",
  "https://drive.google.com/",
  "https://www.google.co.uk/"
];
const GOOGLE_SIGNED_IN_COOKIE_NAMES = new Set([
  "SID",
  "__Secure-1PSID",
  "SAPISID",
  "SSID",
  "HSID",
  "APISID",
  "LSID"
]);

function hasChromeStorage() {
  return typeof chrome !== "undefined" && !!chrome.storage?.local;
}

function storageGetMany(keys) {
  return new Promise((resolve) => {
    if (!hasChromeStorage()) {
      resolve({});
      return;
    }

    chrome.storage.local.get(keys, (result) => {
      if (chrome.runtime?.lastError) {
        resolve({});
        return;
      }

      resolve(result);
    });
  });
}

function storageRemove(keys) {
  return new Promise((resolve) => {
    if (!hasChromeStorage()) {
      resolve();
      return;
    }

    chrome.storage.local.remove(keys, () => resolve());
  });
}

function normalizeUrl(value) {
  const trimmed = value.trim();

  if (!trimmed) {
    return null;
  }

  const withProtocol = /^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(trimmed)
    ? trimmed
    : `https://${trimmed}`;

  try {
    return new URL(withProtocol).toString();
  } catch {
    return null;
  }
}

function isLikelyUrl(query) {
  return /^[^\s]+\.[^\s]+/.test(query) || /^https?:\/\//i.test(query);
}

function getExtensionAssetUrl(path) {
  if (typeof chrome !== "undefined" && chrome.runtime?.getURL && !/^https?:\/\//i.test(path)) {
    return chrome.runtime.getURL(path);
  }

  return path;
}

function getIconFallbackText(app) {
  return app.name.trim().charAt(0).toUpperCase() || "?";
}

function setTextIconFallback(wrapper, fallbackText) {
  wrapper.className = "shortcut-icon";
  wrapper.replaceChildren(document.createTextNode(fallbackText));
}

function createImageIcon(source, fallbackText) {
  const wrapper = document.createElement("span");
  wrapper.className = "shortcut-icon shortcut-icon--brand";

  const icon = document.createElement("img");
  icon.alt = "";
  icon.decoding = "async";
  icon.referrerPolicy = "no-referrer";
  icon.src = source;
  icon.addEventListener("error", () => {
    setTextIconFallback(wrapper, fallbackText);
  }, { once: true });

  wrapper.appendChild(icon);
  return wrapper;
}

function createAppCard(app) {
  const link = document.createElement("a");
  link.className = "shortcut-card shortcut-tile add-card";
  link.href = app.url;
  link.draggable = false;
  link.target = "_top";
  link.rel = "noreferrer";
  link.title = app.name;
  link.setAttribute("aria-label", app.name);
  link.innerHTML = `
    <span class="add-shortcut-background" aria-hidden="true"></span>
    <span class="add-shortcut-content">
      <span class="tile-icon tile-icon-container"></span>
      <span class="tile-title">
        <span class="shortcut-label"></span>
      </span>
    </span>
    <span class="add-shortcut-hover" aria-hidden="true"></span>
  `;

  const iconFrame = link.querySelector(".tile-icon");
  const label = link.querySelector(".shortcut-label");
  const fallbackText = getIconFallbackText(app);
  const iconPath = GOOGLE_SERVICE_ICON_PATHS[app.iconKey];

  if (iconPath) {
    iconFrame.appendChild(createImageIcon(getExtensionAssetUrl(iconPath), fallbackText));
  } else {
    setTextIconFallback(iconFrame, fallbackText);
  }

  label.textContent = app.name;
  return link;
}

function renderGoogleApps() {
  if (!shortcutsGrid) {
    return;
  }

  const fragment = document.createDocumentFragment();
  GOOGLE_APPS.forEach((app) => {
    fragment.appendChild(createAppCard(app));
  });
  shortcutsGrid.dataset.appCount = String(GOOGLE_APPS.length);
  shortcutsGrid.setAttribute("aria-label", GOOGLE_ENHANCED_BUILD_LABEL);
  shortcutsGrid.replaceChildren(fragment);
  document.title = GOOGLE_ENHANCED_BUILD_LABEL;
}

function submitSearch(event) {
  event.preventDefault();
  const query = searchInput.value.trim();

  if (!query) {
    return;
  }

  if (isLikelyUrl(query)) {
    const url = normalizeUrl(query);
    if (url) {
      window.location.href = url;
      return;
    }
  }

  const searchUrl = new URL("https://www.google.com/search");
  searchUrl.searchParams.set("q", query);
  window.location.href = searchUrl.toString();
}

function getGoogleSignInUrl() {
  const signInUrl = new URL(GOOGLE_SIGN_IN_BASE_URL);
  signInUrl.searchParams.set("continue", GOOGLE_SIGN_IN_CONTINUE_URL);
  signInUrl.searchParams.set("hl", navigator.language || "en");
  return signInUrl.toString();
}

function hasChromeCookies() {
  return typeof chrome !== "undefined" && !!chrome.cookies?.getAll;
}

function getGoogleAccountUiState() {
  return storageGetMany([GOOGLE_ACCOUNT_UI_STATE_KEY]).then((result) => {
    const state = result?.[GOOGLE_ACCOUNT_UI_STATE_KEY];
    return state && typeof state === "object" ? state : null;
  });
}

function getAllGoogleCookies() {
  return Promise.all(GOOGLE_COOKIE_CHECK_URLS.map((url) => (
    new Promise((resolve) => {
      if (!hasChromeCookies()) {
        resolve([]);
        return;
      }

      chrome.cookies.getAll({ url }, (cookies) => {
        if (chrome.runtime?.lastError || !Array.isArray(cookies)) {
          resolve([]);
          return;
        }

        resolve(cookies);
      });
    })
  ))).then((cookieGroups) => {
    const seen = new Set();
    const mergedCookies = [];

    cookieGroups.flat().forEach((cookie) => {
      const key = `${cookie.domain}|${cookie.path}|${cookie.name}`;

      if (seen.has(key)) {
        return;
      }

      seen.add(key);
      mergedCookies.push(cookie);
    });

    return mergedCookies;
  });
}

function hasGoogleSignInCookies(cookies) {
  return cookies.some((cookie) => GOOGLE_SIGNED_IN_COOKIE_NAMES.has(cookie.name));
}

async function getGoogleAccountState() {
  const [cachedUiState, cookies] = await Promise.all([
    getGoogleAccountUiState(),
    getAllGoogleCookies()
  ]);
  const signedIn = hasGoogleSignInCookies(cookies);

  if (!signedIn) {
    if (cachedUiState) {
      await storageRemove([GOOGLE_ACCOUNT_UI_STATE_KEY]);
    }

    return {
      signedIn: false,
      avatarUrl: "",
      label: "Sign in",
      profileUrl: ""
    };
  }

  return {
    signedIn: true,
    avatarUrl: typeof cachedUiState?.avatarUrl === "string" ? cachedUiState.avatarUrl : "",
    label: typeof cachedUiState?.label === "string" && cachedUiState.label.trim()
      ? cachedUiState.label
      : "Google Account",
    profileUrl: typeof cachedUiState?.profileUrl === "string" && cachedUiState.profileUrl.trim()
      ? cachedUiState.profileUrl
      : GOOGLE_ACCOUNT_HOME_URL
  };
}

function renderGoogleAccountLink(state) {
  if (!googleSignInLink) {
    return;
  }

  googleSignInLink.classList.remove("top-action-button--pending", "top-action-button--avatar");

  if (state.signedIn) {
    googleSignInLink.href = state.profileUrl || GOOGLE_ACCOUNT_HOME_URL;
    googleSignInLink.classList.add("top-action-button--avatar");
    googleSignInLink.setAttribute("aria-label", state.label || "Google Account");
    googleSignInLink.title = state.label || "Google Account";
    googleSignInLink.textContent = "";

    const avatar = document.createElement("img");
    avatar.className = state.avatarUrl
      ? "google-account-avatar"
      : "google-account-avatar google-account-avatar--fallback";
    avatar.alt = "";
    avatar.decoding = "async";
    avatar.referrerPolicy = "no-referrer";
    avatar.src = state.avatarUrl || getExtensionAssetUrl(GOOGLE_SERVICE_ICON_PATHS.account);
    googleSignInLink.appendChild(avatar);
    return;
  }

  googleSignInLink.href = getGoogleSignInUrl();
  googleSignInLink.setAttribute("aria-label", "Sign in");
  googleSignInLink.title = "Sign in";
  googleSignInLink.textContent = "Sign in";
}

async function synchronizeGoogleAccountLink() {
  if (!googleSignInLink) {
    return;
  }

  googleSignInLink.classList.add("top-action-button--pending");
  const state = await getGoogleAccountState();
  renderGoogleAccountLink(state);
}

function initializeGoogleAccountSyncListeners() {
  if (typeof chrome === "undefined") {
    return;
  }

  chrome.storage?.onChanged?.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes[GOOGLE_ACCOUNT_UI_STATE_KEY]) {
      return;
    }

    synchronizeGoogleAccountLink();
  });

  chrome.cookies?.onChanged?.addListener((changeInfo) => {
    if (!GOOGLE_SIGNED_IN_COOKIE_NAMES.has(changeInfo?.cookie?.name)) {
      return;
    }

    synchronizeGoogleAccountLink();
  });
}

function initializeGoogleSignInLink() {
  if (!googleSignInLink) {
    return;
  }

  googleSignInLink.href = getGoogleSignInUrl();
  googleSignInLink.addEventListener("click", handleGoogleSignInClick);
}

function handleGoogleSignInClick(event) {
  if (googleSignInLink?.classList.contains("top-action-button--avatar")) {
    return;
  }

  event.preventDefault();
  window.location.href = getGoogleSignInUrl();
}

searchForm.addEventListener("submit", submitSearch);

initializeGoogleSignInLink();
initializeGoogleAccountSyncListeners();
synchronizeGoogleAccountLink();
renderGoogleApps();
