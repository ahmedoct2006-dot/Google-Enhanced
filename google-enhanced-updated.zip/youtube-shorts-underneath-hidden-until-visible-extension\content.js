(() => {
  const ALWAYS_HIDE_SELECTORS = [".reel-video-in-sequence-thumbnail"];

  const TARGET_SELECTOR = [
    ".reel-video-in-sequence-thumbnail",
    ".reel-video-in-sequence-container",
    ".reel-video-in-sequence-new",
    "ytd-reel-non-video-content-renderer",
    "#nvc-container"
  ].join(", ");

  const HIDDEN_CLASS = "yt-underneath-hidden-until-visible";
  // Keep the "underneath" (next) preview hidden until it is mostly in view.
  // This prevents the next thumbnail from peeking out under the current Short.
  const REVEAL_RATIO = 0.6;

  let intersectionObserver = null;
  const observed = new WeakSet();

  function isShortsRoute() {
    return location.pathname.startsWith("/shorts/");
  }

  function ensureIntersectionObserver() {
    if (intersectionObserver) return intersectionObserver;

    intersectionObserver = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!isShortsRoute()) {
            entry.target.classList.remove(HIDDEN_CLASS);
            continue;
          }
          if (entry.target.matches?.(ALWAYS_HIDE_SELECTORS.join(", "))) {
            entry.target.classList.add(HIDDEN_CLASS);
            continue;
          }
          const ratio = typeof entry.intersectionRatio === "number" ? entry.intersectionRatio : 0;
          if (ratio >= REVEAL_RATIO) entry.target.classList.remove(HIDDEN_CLASS);
          else entry.target.classList.add(HIDDEN_CLASS);
        }
      },
      { root: null, threshold: [0, REVEAL_RATIO] }
    );

    return intersectionObserver;
  }

  function observeTargets(rootNode) {
    if (!isShortsRoute()) return;
    const root =
      rootNode && rootNode.nodeType === Node.ELEMENT_NODE ? rootNode : document;

    const targets = root.querySelectorAll?.(TARGET_SELECTOR);
    if (!targets || !targets.length) return;

    const io = ensureIntersectionObserver();
    for (const element of targets) {
      if (observed.has(element)) continue;
      observed.add(element);
      element.classList.add(HIDDEN_CLASS); // hidden by default until in view
      io.observe(element);
    }
  }

  function unhideAll() {
    const targets = document.querySelectorAll(TARGET_SELECTOR);
    for (const element of targets) element.classList.remove(HIDDEN_CLASS);
  }

  function onRouteChange() {
    if (isShortsRoute()) observeTargets(document);
    else unhideAll();
  }

  const mutationObserver = new MutationObserver((mutations) => {
    if (!isShortsRoute()) return;
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        observeTargets(node);
      }
    }
  });

  mutationObserver.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  // YouTube is a SPA; watch for route changes.
  let lastPathname = location.pathname;
  setInterval(() => {
    if (location.pathname === lastPathname) return;
    lastPathname = location.pathname;
    onRouteChange();
  }, 500);

  onRouteChange();
})();
