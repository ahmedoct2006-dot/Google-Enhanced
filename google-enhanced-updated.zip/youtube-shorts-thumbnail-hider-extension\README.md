# YouTube Shorts Thumbnail Hider

This Chrome extension hides the underneath thumbnail preview strip/overlay while you are on YouTube Shorts pages.

## Load it in Chrome

1. Open `chrome://extensions`
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Select the `youtube-shorts-thumbnail-hider-extension` folder

## What it hides

- `.reel-video-in-sequence-thumbnail`
- `.reel-video-in-sequence-container`
- `.reel-video-in-sequence-new`

The script only enables the hiding when the URL matches `/shorts/...`.
