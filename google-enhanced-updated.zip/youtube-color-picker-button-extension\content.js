const STORAGE_KEY = "ytColorPickerButtonSettings";
const DEFAULT_SETTINGS = {
  activeRegion: "middle",
  colors: {
    left: "#d6e4ff",
    top: "#dfe7ff",
    middle: "#eef4ff"
  }
};

const REGIONS = ["left", "top", "middle"];

const state = {
  settings: cloneSettings(DEFAULT_SETTINGS),
  slot: null,
  button: null,
  panel: null,
  input: null,
  hexValue: null,
  segmentButtons: {},
  observer: null,
  rafId: 0
};

function normalizeHex(value) {
  const hex = typeof value === "string" ? value.trim() : "";
  return /^#[0-9a-fA-F]{6}$/.test(hex) ? hex.toLowerCase() : "#ffffff";
}

function cloneSettings(value) {
  const activeRegion = REGIONS.includes(value?.activeRegion)
    ? value.activeRegion
    : DEFAULT_SETTINGS.activeRegion;

  return {
    activeRegion,
    colors: {
      left: normalizeHex(value?.colors?.left ?? DEFAULT_SETTINGS.colors.left),
      top: normalizeHex(value?.colors?.top ?? DEFAULT_SETTINGS.colors.top),
      middle: normalizeHex(value?.colors?.middle ?? DEFAULT_SETTINGS.colors.middle)
    }
  };
}

function hexToRgb(hex) {
  const value = normalizeHex(hex).slice(1);
  return {
    r: parseInt(value.slice(0, 2), 16),
    g: parseInt(value.slice(2, 4), 16),
    b: parseInt(value.slice(4, 6), 16)
  };
}

function rgbToHex({ r, g, b }) {
  const toHex = (channel) => Math.round(Math.min(255, Math.max(0, channel)))
    .toString(16)
    .padStart(2, "0");

  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function mixHex(primaryHex, secondaryHex, primaryWeight) {
  const weight = Math.min(1, Math.max(0, primaryWeight));
  const secondaryWeight = 1 - weight;
  const primary = hexToRgb(primaryHex);
  const secondary = hexToRgb(secondaryHex);

  return rgbToHex({
    r: primary.r * weight + secondary.r * secondaryWeight,
    g: primary.g * weight + secondary.g * secondaryWeight,
    b: primary.b * weight + secondary.b * secondaryWeight
  });
}

function getLinearChannel(channel) {
  const normalized = channel / 255;
  return normalized <= 0.04045
    ? normalized / 12.92
    : ((normalized + 0.055) / 1.055) ** 2.4;
}

function getLuminance(hex) {
  const { r, g, b } = hexToRgb(hex);
  return (
    0.2126 * getLinearChannel(r) +
    0.7152 * getLinearChannel(g) +
    0.0722 * getLinearChannel(b)
  );
}

function getContrastRatio(firstHex, secondHex) {
  const first = getLuminance(firstHex);
  const second = getLuminance(secondHex);
  const lighter = Math.max(first, second);
  const darker = Math.min(first, second);
  return (lighter + 0.05) / (darker + 0.05);
}

function getReadableForeground(color) {
  const dark = "#0f172a";
  const light = "#f8fafc";
  return getContrastRatio(color, dark) >= getContrastRatio(color, light) ? dark : light;
}

function getMutedForeground(color) {
  return getReadableForeground(color) === "#f8fafc"
    ? "rgba(248, 250, 252, 0.78)"
    : "rgba(15, 23, 42, 0.72)";
}

function getVisibleRect(element) {
  if (!(element instanceof HTMLElement)) {
    return null;
  }

  const rect = element.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) {
    return null;
  }

  if (rect.bottom <= 0 || rect.right <= 0) {
    return null;
  }

  if (rect.top >= window.innerHeight || rect.left >= window.innerWidth) {
    return null;
  }

  return rect;
}

function updateLeftFillWidth() {
  const root = document.documentElement;
  const expandedGuideCandidates = [
    document.querySelector("ytd-guide-renderer"),
    document.querySelector("tp-yt-app-drawer[opened] #guide-content"),
    document.querySelector("tp-yt-app-drawer[opened] #guide-inner-content"),
    document.querySelector("tp-yt-app-drawer[opened] #contentContainer")
  ];

  for (const candidate of expandedGuideCandidates) {
    const rect = getVisibleRect(candidate);
    if (rect && rect.right > 120) {
      root.style.setProperty("--ytcc-left-fill-width", `${Math.round(rect.right)}px`);
      root.classList.remove("ytcc-compact-left");
      return;
    }
  }

  const miniGuide = document.querySelector("ytd-mini-guide-renderer");
  const miniGuideRect = getVisibleRect(miniGuide);

  if (miniGuideRect) {
    root.style.setProperty("--ytcc-left-fill-width", `${Math.round(miniGuideRect.right)}px`);
    root.classList.add("ytcc-compact-left");
    return;
  }

  const guideButton = document.querySelector("ytd-masthead #guide-button, #guide-button");
  const guideButtonRect = getVisibleRect(guideButton);

  if (guideButtonRect) {
    root.style.setProperty("--ytcc-left-fill-width", `${Math.round(guideButtonRect.right)}px`);
    root.classList.add("ytcc-compact-left");
    return;
  }

  root.style.setProperty("--ytcc-left-fill-width", "72px");
  root.classList.add("ytcc-compact-left");
}

function isHomeLikePage() {
  return window.location.pathname === "/" || window.location.pathname === "/feed/subscriptions";
}

function getRegionSurface(region) {
  const color = state.settings.colors[region];
  const mixTarget = getReadableForeground(color) === "#f8fafc" ? "#020617" : "#ffffff";

  if (region === "top") {
    return mixHex(color, mixTarget, 0.96);
  }

  if (region === "left") {
    return mixHex(color, mixTarget, 0.92);
  }

  return mixHex(color, mixTarget, 0.88);
}

function getRegionCard(region) {
  const surface = getRegionSurface(region);
  const mixTarget = getReadableForeground(state.settings.colors[region]) === "#f8fafc" ? "#020617" : "#ffffff";
  return mixHex(surface, mixTarget, 0.94);
}

function setThemeVariables() {
  const root = document.documentElement;
  const leftColor = state.settings.colors.left;
  const topColor = state.settings.colors.top;
  const middleColor = state.settings.colors.middle;
  const activeColor = state.settings.colors[state.settings.activeRegion];
  const leftForeground = getReadableForeground(leftColor);
  const topForeground = getReadableForeground(topColor);
  const middleForeground = getReadableForeground(middleColor);

  root.style.setProperty("--ytcc-left-color", getRegionSurface("left"));
  root.style.setProperty("--ytcc-top-color", getRegionSurface("top"));
  root.style.setProperty("--ytcc-middle-color", getRegionSurface("middle"));
  root.style.setProperty("--ytcc-left-card-color", getRegionCard("left"));
  root.style.setProperty("--ytcc-top-card-color", getRegionCard("top"));
  root.style.setProperty("--ytcc-middle-card-color", getRegionCard("middle"));
  root.style.setProperty("--ytcc-left-border-color", mixHex(leftColor, leftForeground === "#f8fafc" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcc-top-border-color", mixHex(topColor, topForeground === "#f8fafc" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcc-middle-border-color", mixHex(middleColor, middleForeground === "#f8fafc" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcc-left-foreground", leftForeground);
  root.style.setProperty("--ytcc-top-foreground", topForeground);
  root.style.setProperty("--ytcc-middle-foreground", middleForeground);
  root.style.setProperty("--ytcc-left-muted", getMutedForeground(leftColor));
  root.style.setProperty("--ytcc-top-muted", getMutedForeground(topColor));
  root.style.setProperty("--ytcc-middle-muted", getMutedForeground(middleColor));
  root.classList.add("ytcc-enabled");
  root.classList.toggle("ytcc-home-layout", isHomeLikePage());
  root.classList.toggle("ytcc-top-dark", topForeground === "#f8fafc");
  root.classList.toggle("ytcc-middle-dark", middleForeground === "#f8fafc");
  updateLeftFillWidth();

  if (state.button) {
    state.button.style.setProperty("--ytcc-button-swatch", activeColor);
    state.button.setAttribute(
      "aria-label",
      `Pick YouTube color for ${state.settings.activeRegion} side. Current color ${activeColor.toUpperCase()}`
    );
    state.button.title = `${capitalize(state.settings.activeRegion)} side color (${activeColor.toUpperCase()})`;
  }

  if (state.input) {
    state.input.value = activeColor;
  }

  if (state.hexValue) {
    state.hexValue.textContent = activeColor.toUpperCase();
  }

  REGIONS.forEach((region) => {
    const segment = state.segmentButtons[region];
    if (!segment) {
      return;
    }

    segment.dataset.active = String(region === state.settings.activeRegion);
    segment.style.setProperty("--ytcc-segment-swatch", state.settings.colors[region]);
  });
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function storageGet(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => resolve(result));
  });
}

function storageSet(value) {
  return new Promise((resolve) => {
    chrome.storage.local.set(value, () => resolve());
  });
}

async function persistSettings() {
  await storageSet({
    [STORAGE_KEY]: state.settings
  });
}

async function handleColorChange(value) {
  state.settings.colors[state.settings.activeRegion] = normalizeHex(value);
  setThemeVariables();
  await persistSettings();
}

async function setActiveRegion(region) {
  if (!REGIONS.includes(region)) {
    return;
  }

  state.settings.activeRegion = region;
  setThemeVariables();
  await persistSettings();
}

async function resetColors() {
  state.settings = cloneSettings(DEFAULT_SETTINGS);
  setThemeVariables();
  await persistSettings();
}

function closePanel() {
  if (!state.panel || !state.button) {
    return;
  }

  state.panel.hidden = true;
  state.button.setAttribute("aria-expanded", "false");
  state.button.dataset.open = "false";
}

function openPanel() {
  if (!state.panel || !state.button) {
    return;
  }

  const rect = state.button.getBoundingClientRect();
  const panelWidth = Math.min(520, window.innerWidth - 24);
  const left = Math.max(12, Math.min(window.innerWidth - panelWidth - 12, rect.right - panelWidth));

  state.panel.hidden = false;
  state.panel.style.top = `${Math.max(72, rect.bottom + 10)}px`;
  state.panel.style.left = `${left}px`;
  state.button.setAttribute("aria-expanded", "true");
  state.button.dataset.open = "true";
}

function togglePanel() {
  if (!state.panel) {
    return;
  }

  if (state.panel.hidden) {
    openPanel();
  } else {
    closePanel();
  }
}

function createSegmentMarkup(region, label) {
  return `
    <button class="ytcc-segment-button" type="button" data-region="${region}" data-active="false">
      <span class="ytcc-segment-swatch" aria-hidden="true"></span>
      <span>${label}</span>
    </button>
  `;
}

function createPanel() {
  if (state.panel) {
    return state.panel;
  }

  const panel = document.createElement("section");
  panel.id = "ytcc-panel";
  panel.hidden = true;
  panel.innerHTML = `
    <div class="ytcc-panel-header">
      <div>
        <h2 class="ytcc-panel-title">YouTube Color Picker</h2>
        <p class="ytcc-panel-subtitle">Pick separate colors for the left side, top side, and middle side.</p>
      </div>
      <button class="ytcc-close-button" type="button" aria-label="Close color picker">x</button>
    </div>
    <div class="ytcc-segments" role="tablist" aria-label="Pick YouTube area">
      ${createSegmentMarkup("left", "Left side")}
      ${createSegmentMarkup("top", "Top side")}
      ${createSegmentMarkup("middle", "Middle side")}
    </div>
    <div class="ytcc-preview" aria-hidden="true">
      <div class="ytcc-preview-top"></div>
      <div class="ytcc-preview-side"></div>
      <div class="ytcc-preview-main"></div>
      <div class="ytcc-preview-card ytcc-preview-card-a"></div>
      <div class="ytcc-preview-card ytcc-preview-card-b"></div>
      <div class="ytcc-preview-line ytcc-preview-line-vertical"></div>
      <div class="ytcc-preview-line ytcc-preview-line-horizontal"></div>
      <span class="ytcc-preview-dot"></span>
    </div>
    <label class="ytcc-field">
      <span class="ytcc-field-copy">
        <span class="ytcc-field-title">Selected area color</span>
        <span class="ytcc-field-hint">Choose the area first, then set its color.</span>
      </span>
      <input id="ytcc-color-input" class="ytcc-color-input" type="color" />
      <span class="ytcc-color-value">#EEF4FF</span>
    </label>
    <div class="ytcc-panel-actions">
      <button class="ytcc-reset-button" type="button">Reset all</button>
    </div>
  `;

  panel.querySelector(".ytcc-close-button")?.addEventListener("click", closePanel);
  panel.querySelector(".ytcc-reset-button")?.addEventListener("click", () => {
    resetColors();
  });

  const input = panel.querySelector(".ytcc-color-input");
  const hexValue = panel.querySelector(".ytcc-color-value");

  input?.addEventListener("input", (event) => {
    handleColorChange(event.target.value);
  });

  panel.querySelectorAll(".ytcc-segment-button").forEach((button) => {
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }

    const region = button.dataset.region;
    if (!REGIONS.includes(region)) {
      return;
    }

    state.segmentButtons[region] = button;
    button.addEventListener("click", () => {
      setActiveRegion(region);
    });
  });

  document.body.appendChild(panel);
  state.panel = panel;
  state.input = input;
  state.hexValue = hexValue;
  setThemeVariables();
  return panel;
}

function createToolbarButton() {
  if (state.slot) {
    return state.slot;
  }

  const slot = document.createElement("div");
  slot.id = "ytcc-toolbar-slot";

  const button = document.createElement("button");
  button.id = "ytcc-toolbar-button";
  button.type = "button";
  button.setAttribute("aria-haspopup", "dialog");
  button.setAttribute("aria-expanded", "false");
  button.dataset.open = "false";
  button.innerHTML = `
    <span class="ytcc-toolbar-swatch" aria-hidden="true"></span>
    <span class="ytcc-toolbar-label">Color</span>
  `;

  button.addEventListener("click", () => {
    togglePanel();
  });

  button.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    resetColors();
  });

  slot.appendChild(button);
  state.slot = slot;
  state.button = button;
  setThemeVariables();
  return slot;
}

function getToolbarAnchor() {
  return (
    document.querySelector("ytd-masthead #voice-search-button") ||
    document.querySelector("#voice-search-button") ||
    document.querySelector("ytd-masthead ytd-voice-search-button-renderer") ||
    document.querySelector("ytd-voice-search-button-renderer")
  );
}

function getToolbarFallbackHost() {
  return (
    document.querySelector("ytd-masthead #end") ||
    document.querySelector("#end") ||
    document.querySelector("ytd-masthead #buttons") ||
    document.querySelector("ytd-masthead #center") ||
    document.querySelector("ytd-masthead")
  );
}

function mountToolbarButton() {
  const anchor = getToolbarAnchor();
  const slot = createToolbarButton();
  createPanel();
  updateLeftFillWidth();

  if (getVisibleRect(anchor)) {
    if (anchor.nextElementSibling !== slot) {
      anchor.insertAdjacentElement("afterend", slot);
    }
    return;
  }

  const fallbackHost = getToolbarFallbackHost();
  if (fallbackHost instanceof Element && !fallbackHost.contains(slot)) {
    fallbackHost.appendChild(slot);
    return;
  }

  if (anchor instanceof Element && anchor.nextElementSibling !== slot) {
    anchor.insertAdjacentElement("afterend", slot);
  }
}

function removeUnwantedYoodleHomeButtons() {
  document.querySelectorAll("ytd-masthead ytd-yoodle-renderer, ytd-yoodle-renderer").forEach((el) => {
    if (el instanceof HTMLElement) {
      el.remove();
    }
  });

  document.querySelectorAll('ytd-masthead img.style-scope.ytd-yoodle-renderer, img.style-scope.ytd-yoodle-renderer').forEach((el) => {
    if (el instanceof HTMLElement) {
      el.remove();
    }
  });
}

function scheduleRefresh() {
  if (state.rafId) {
    cancelAnimationFrame(state.rafId);
  }

  state.rafId = requestAnimationFrame(() => {
    state.rafId = 0;
    removeUnwantedYoodleHomeButtons();
    mountToolbarButton();
    if (state.panel && !state.panel.hidden) {
      openPanel();
    }
  });
}

function setupObservers() {
  document.addEventListener("click", (event) => {
    if (!state.panel || state.panel.hidden) {
      return;
    }

    const target = event.target;
    if (state.panel.contains(target) || state.button?.contains(target)) {
      return;
    }

    closePanel();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closePanel();
    }
  });

  window.addEventListener("resize", scheduleRefresh, { passive: true });
  window.addEventListener("scroll", scheduleRefresh, { passive: true });
  window.addEventListener("yt-navigate-finish", () => {
    setThemeVariables();
    scheduleRefresh();
  }, { passive: true });

  const observer = new MutationObserver(() => {
    scheduleRefresh();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  state.observer = observer;
}

async function initialize() {
  if (!document.body) {
    window.addEventListener("DOMContentLoaded", initialize, { once: true });
    return;
  }

  const stored = await storageGet(STORAGE_KEY);
  state.settings = cloneSettings(stored?.[STORAGE_KEY]);
  setThemeVariables();
  createToolbarButton();
  createPanel();
  setupObservers();
  scheduleRefresh();
}

initialize();
