# YouTube Background Color Changer

This is a standalone Chrome extension that adds a `Colors` button next to YouTube's mic button.

When you click it, a panel opens so you can choose separate colors for:

- left side
- top side
- right side

## Install

1. Open `chrome://extensions`
2. Turn on `Developer mode`
3. Click `Load unpacked`
4. Select the `youtube-background-color-extension` folder

## Notes

- Your Google Enhanced extension files were not changed.
- Colors are saved with `chrome.storage.local`.
- The button reinserts itself when YouTube changes pages without a full reload.
