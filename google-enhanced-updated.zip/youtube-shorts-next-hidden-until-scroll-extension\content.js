// Hide next video thumbnail until scroll
(function() {
  const NEXT_PREVIEW_SELECTOR = [
    '.reel-video-in-sequence-thumbnail',
    '.reel-video-in-sequence-container',
    '.reel-video-in-sequence-new',
    'ytd-reel-non-video-content-renderer',
    '#nvc-container'
  ].join(', ');
  let isScrolling = false;
  let scrollTimeoutId = null;

  // Hide the whole underneath preview stack, not just the image thumbnail.
  function hideNextVideoThumbnails() {
    const thumbnails = document.querySelectorAll(NEXT_PREVIEW_SELECTOR);
    thumbnails.forEach(thumbnail => {
      thumbnail.classList.add('hidden-thumbnail');
    });
  }

  // Show the underneath preview again while the user is actively scrolling.
  function showNextVideoThumbnails() {
    const thumbnails = document.querySelectorAll(NEXT_PREVIEW_SELECTOR);
    thumbnails.forEach(thumbnail => {
      thumbnail.classList.remove('hidden-thumbnail');
    });
  }

  // Listen for scroll events
  window.addEventListener('scroll', function() {
    isScrolling = true;
    showNextVideoThumbnails();

    // Clear previous timeout
    if (scrollTimeoutId) {
      clearTimeout(scrollTimeoutId);
    }

    // After scrolling stops for 500ms, start hiding again
    scrollTimeoutId = setTimeout(function() {
      isScrolling = false;
      // Only hide if we're on YouTube Shorts
      if (window.location.href.includes('/shorts/')) {
        hideNextVideoThumbnails();
      }
    }, 500);
  }, false);

  // Initial hide when page loads
  window.addEventListener('load', function() {
    setTimeout(hideNextVideoThumbnails, 1000);
  });

  // Also hide for dynamically loaded content using MutationObserver
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      // Check if new elements were added
      if (mutation.addedNodes.length) {
        mutation.addedNodes.forEach(function(node) {
          if (node.nodeType === 1) { // Element node
            const thumbnails = node.querySelectorAll?.(NEXT_PREVIEW_SELECTOR);
            if (thumbnails) {
              thumbnails.forEach(thumbnail => {
                thumbnail.classList.add('hidden-thumbnail');
              });
            }
          }
        });
      }
    });
  });

  // Start observing when page is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      hideNextVideoThumbnails();
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    });
  } else {
    hideNextVideoThumbnails();
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
})();
