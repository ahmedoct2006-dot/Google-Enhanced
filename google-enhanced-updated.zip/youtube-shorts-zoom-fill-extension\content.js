const ROOT_CLASS = "yt-shorts-seam-fix";
const ACTIVE_RENDERER_CLASS = "yt-shorts-seam-fix--active";
const SHORTS_PATH_PREFIX = "/shorts/";
const FILL_SCALE = "2";
const VERTICAL_OFFSET = "12vh";
const STYLE_MARK_KEY = "ytShortsSeamFixApplied";
const CONTAINER_SELECTOR = [
  "#shorts-player",
  "#player-container",
  ".player-wrapper",
  ".html5-video-container",
  ".html5-video-player",
  "#video-container",
  "#viewport",
  ".reel-player-wrapper",
  ".reel-player-container"
].join(", ");
const VIDEO_SELECTOR = [
  "video",
  "#video",
  ".html5-main-video",
  ".video-stream.html5-main-video"
].join(", ");
const RENDERER_STYLE_MAP = [
  ["position", "relative"],
  ["overflow", "hidden"],
  ["background", "transparent"]
];
const CONTAINER_STYLE_MAP = [
  ["position", "relative"],
  ["overflow", "hidden"],
  ["background", "transparent"]
];
const VIDEO_STYLE_MAP = [
  ["position", "absolute"],
  ["left", "50%"],
  ["top", `calc(50% + ${VERTICAL_OFFSET})`],
  ["right", "auto"],
  ["bottom", "auto"],
  ["width", "100%"],
  ["height", "100%"],
  ["min-width", "100%"],
  ["min-height", "100%"],
  ["max-width", "none"],
  ["max-height", "none"],
  ["margin", "0"],
  ["background", "transparent"],
  ["object-fit", "cover"],
  ["object-position", "center center"],
  ["transform-origin", "center center"],
  ["transform", `translate(-50%, -50%) scale(${FILL_SCALE})`]
];
let syncFrame = 0;

function isShortsPage() {
  return window.location.pathname.startsWith(SHORTS_PATH_PREFIX);
}

function getVisibleArea(element) {
  if (!(element instanceof HTMLElement)) {
    return 0;
  }

  const rect = element.getBoundingClientRect();
  const visibleLeft = Math.max(0, rect.left);
  const visibleTop = Math.max(0, rect.top);
  const visibleRight = Math.min(window.innerWidth, rect.right);
  const visibleBottom = Math.min(window.innerHeight, rect.bottom);
  const visibleWidth = Math.max(0, visibleRight - visibleLeft);
  const visibleHeight = Math.max(0, visibleBottom - visibleTop);

  return visibleWidth * visibleHeight;
}

function applyStyleMap(element, styleMap, markValue) {
  if (!(element instanceof HTMLElement)) {
    return;
  }

  for (const [property, value] of styleMap) {
    element.style.setProperty(property, value, "important");
  }

  element.dataset[STYLE_MARK_KEY] = markValue;
}

function clearStyleMap(element, styleMap) {
  if (!(element instanceof HTMLElement)) {
    return;
  }

  for (const [property] of styleMap) {
    element.style.removeProperty(property);
  }

  delete element.dataset[STYLE_MARK_KEY];
}

function clearRendererStyles(renderer) {
  if (!(renderer instanceof HTMLElement)) {
    return;
  }

  renderer.classList.remove(ACTIVE_RENDERER_CLASS);

  if (renderer.dataset[STYLE_MARK_KEY] === "renderer") {
    clearStyleMap(renderer, RENDERER_STYLE_MAP);
  }

  renderer.querySelectorAll(CONTAINER_SELECTOR).forEach((element) => {
    if (!(element instanceof HTMLElement)) {
      return;
    }

    if (element.dataset[STYLE_MARK_KEY] === "container") {
      clearStyleMap(element, CONTAINER_STYLE_MAP);
    }
  });

  renderer.querySelectorAll(VIDEO_SELECTOR).forEach((element) => {
    if (!(element instanceof HTMLElement)) {
      return;
    }

    if (element.dataset[STYLE_MARK_KEY] === "video") {
      clearStyleMap(element, VIDEO_STYLE_MAP);
    }
  });
}

function applyRendererStyles(renderer) {
  if (!(renderer instanceof HTMLElement)) {
    return;
  }

  renderer.classList.add(ACTIVE_RENDERER_CLASS);
  applyStyleMap(renderer, RENDERER_STYLE_MAP, "renderer");

  renderer.querySelectorAll(CONTAINER_SELECTOR).forEach((element) => {
    applyStyleMap(element, CONTAINER_STYLE_MAP, "container");
  });

  renderer.querySelectorAll(VIDEO_SELECTOR).forEach((element) => {
    applyStyleMap(element, VIDEO_STYLE_MAP, "video");
  });
}

function getActiveRenderer() {
  let bestRenderer = null;
  let bestArea = 0;

  document.querySelectorAll("ytd-reel-video-renderer").forEach((renderer) => {
    const visibleArea = getVisibleArea(renderer);

    if (visibleArea > bestArea) {
      bestArea = visibleArea;
      bestRenderer = renderer;
    }
  });

  return bestRenderer;
}

function syncFixState() {
  const shortsPage = isShortsPage();
  document.documentElement.classList.toggle(ROOT_CLASS, shortsPage);

  const activeRenderer = shortsPage ? getActiveRenderer() : null;

  document.querySelectorAll("ytd-reel-video-renderer").forEach((renderer) => {
    if (!(renderer instanceof HTMLElement)) {
      return;
    }

    if (renderer === activeRenderer) {
      applyRendererStyles(renderer);
      return;
    }

    clearRendererStyles(renderer);
  });
}

function scheduleSync() {
  if (syncFrame) {
    cancelAnimationFrame(syncFrame);
  }

  syncFrame = requestAnimationFrame(() => {
    syncFrame = 0;
    syncFixState();
  });
}

function initialize() {
  syncFixState();

  window.addEventListener("yt-navigate-finish", scheduleSync, { passive: true });
  window.addEventListener("popstate", scheduleSync, { passive: true });
  window.addEventListener("resize", scheduleSync, { passive: true });
  window.addEventListener("focus", scheduleSync, { passive: true });
  window.addEventListener("scroll", scheduleSync, { passive: true });
  document.addEventListener("visibilitychange", scheduleSync, { passive: true });

  const observer = new MutationObserver(() => {
    scheduleSync();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "style", "is-active"]
  });
}

initialize();
