# YouTube 3-Zone Color Picker (Chrome/Edge extension)

Adds a small palette button next to the mic button on YouTube. Clicking it opens an in-page picker for:

- **Left** (navigation / guide)
- **Top** (masthead bar)
- **Middle** (main content)

## Install (unpacked)

1. Open Chrome/Edge.
2. Go to `chrome://extensions` (Edge: `edge://extensions`).
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select this folder: `C:\\Users\\ahmed\\Documents\\YouTubeColorPickerExtension`.

Open YouTube and use the palette button next to the mic icon.

## Reset

Use the **Reset** button in the in-page picker.

