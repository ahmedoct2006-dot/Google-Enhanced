const STORAGE_KEY = "youtubeThreePanelColors";
const DEFAULT_COLORS = {
  leftColor: "#111111",
  topColor: "#1f1f1f",
  middleColor: "#202020"
};

const leftColorInput = document.getElementById("leftColor");
const topColorInput = document.getElementById("topColor");
const middleColorInput = document.getElementById("middleColor");
const saveButton = document.getElementById("saveButton");
const resetButton = document.getElementById("resetButton");
const status = document.getElementById("status");

function setStatus(message) {
  status.textContent = message;
  window.clearTimeout(setStatus.timeoutId);
  setStatus.timeoutId = window.setTimeout(() => {
    status.textContent = "";
  }, 1800);
}

function applyColorsToForm(colors) {
  leftColorInput.value = colors.leftColor;
  topColorInput.value = colors.topColor;
  middleColorInput.value = colors.middleColor;
}

function readColorsFromForm() {
  return {
    leftColor: leftColorInput.value,
    topColor: topColorInput.value,
    middleColor: middleColorInput.value
  };
}

async function loadSavedColors() {
  const stored = await chrome.storage.sync.get(STORAGE_KEY);
  const colors = {
    ...DEFAULT_COLORS,
    ...(stored[STORAGE_KEY] || {})
  };

  applyColorsToForm(colors);
}

async function saveColors() {
  const colors = readColorsFromForm();
  await chrome.storage.sync.set({ [STORAGE_KEY]: colors });
  setStatus("Colors saved.");
}

async function resetColors() {
  await chrome.storage.sync.set({ [STORAGE_KEY]: DEFAULT_COLORS });
  applyColorsToForm(DEFAULT_COLORS);
  setStatus("Colors reset.");
}

saveButton.addEventListener("click", saveColors);
resetButton.addEventListener("click", resetColors);

loadSavedColors();
