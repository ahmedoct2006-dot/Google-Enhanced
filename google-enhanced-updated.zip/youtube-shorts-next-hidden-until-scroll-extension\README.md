# YouTube Shorts - Next Video Hidden Until Scroll

This Chrome extension hides the next video thumbnail that appears underneath YouTube Shorts videos until you scroll down.

## Features

- **Automatic Hiding**: Hides the next video thumbnail preview (`reel-video-in-sequence-thumbnail`) by default
- **Scroll Detection**: Shows the thumbnail when you scroll down to view it
- **Auto-Hide After Scroll**: Hides the thumbnail again after scrolling stops (500ms inactivity)
- **Dynamic Content Support**: Handles dynamically loaded content on the YouTube Shorts page using MutationObserver

## How It Works

1. When you're viewing YouTube Shorts, the next video's thumbnail is automatically hidden below the current video
2. When you scroll down, the thumbnail temporarily appears
3. After you stop scrolling for 500ms, the thumbnail hides again
4. This creates a more focused viewing experience without spoilers of upcoming videos

## Installation

1. Clone or download this extension folder
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top right)
4. Click "Load unpacked"
5. Select this extension folder
6. The extension is now active on YouTube Shorts!

## Files

- `manifest.json` - Extension configuration
- `content.js` - Main script that handles hiding/showing logic
- `styles.css` - Styling for hidden thumbnails
- `README.md` - This file

## Technical Details

- Uses MutationObserver to detect dynamically loaded content
- Scroll events trigger visibility changes
- Works specifically on `https://www.youtube.com` Shorts pages
- No data collection or external connections

## Compatibility

- Chrome/Chromium-based browsers
- YouTube.com only
