const STYLE_ID = "yt-shorts-thumbnail-hider-style";
let rafId = 0;

function isShortsPage() {
  return window.location.pathname.startsWith("/shorts/");
}

function ensureStyleElement() {
  let style = document.getElementById(STYLE_ID);

  if (!(style instanceof HTMLStyleElement)) {
    style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      html.yt-shorts-thumbnail-hider .reel-video-in-sequence-thumbnail {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }

      html.yt-shorts-thumbnail-hider ytd-reel-non-video-content-renderer,
      html.yt-shorts-thumbnail-hider #nvc-container {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }
    `;
    document.documentElement.appendChild(style);
  }

  return style;
}

function syncShortsThumbnailHiding() {
  ensureStyleElement();
  document.documentElement.classList.toggle("yt-shorts-thumbnail-hider", isShortsPage());
  syncThumbnailCutoff();
}

function getVisibleRect(element) {
  if (!(element instanceof HTMLElement)) {
    return null;
  }

  const rect = element.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) {
    return null;
  }

  const visibleLeft = Math.max(0, rect.left);
  const visibleTop = Math.max(0, rect.top);
  const visibleRight = Math.min(window.innerWidth, rect.right);
  const visibleBottom = Math.min(window.innerHeight, rect.bottom);
  const visibleWidth = Math.max(0, visibleRight - visibleLeft);
  const visibleHeight = Math.max(0, visibleBottom - visibleTop);

  if (visibleWidth <= 0 || visibleHeight <= 0) {
    return null;
  }

  return {
    rect,
    visibleWidth,
    visibleHeight,
    visibleArea: visibleWidth * visibleHeight
  };
}

function clearThumbnailCutoff() {
  document.querySelectorAll(".reel-video-in-sequence-thumbnail").forEach((thumbnail) => {
    if (!(thumbnail instanceof HTMLElement)) {
      return;
    }

    thumbnail.style.setProperty("display", "none", "important");
    thumbnail.style.setProperty("visibility", "hidden", "important");
    thumbnail.style.setProperty("opacity", "0", "important");
    thumbnail.style.setProperty("pointer-events", "none", "important");
  });
}

function syncThumbnailCutoff() {
  if (!isShortsPage()) {
    clearThumbnailCutoff();
    return;
  }

  document.querySelectorAll(".reel-video-in-sequence-thumbnail").forEach((thumbnail) => {
    if (!(thumbnail instanceof HTMLElement)) {
      return;
    }

    thumbnail.style.setProperty("display", "none", "important");
    thumbnail.style.setProperty("visibility", "hidden", "important");
    thumbnail.style.setProperty("opacity", "0", "important");
    thumbnail.style.setProperty("pointer-events", "none", "important");
  });
}

function updateRevealStateFromLayout() {
  syncShortsThumbnailHiding();
}

function scheduleRevealStateRefresh() {
  if (rafId) {
    cancelAnimationFrame(rafId);
  }

  rafId = requestAnimationFrame(() => {
    rafId = 0;
    updateRevealStateFromLayout();
  });
}

function initialize() {
  syncShortsThumbnailHiding();

  window.addEventListener("yt-navigate-finish", scheduleRevealStateRefresh, { passive: true });
  window.addEventListener("popstate", scheduleRevealStateRefresh, { passive: true });
  window.addEventListener("wheel", scheduleRevealStateRefresh, { passive: true });
  window.addEventListener("keydown", scheduleRevealStateRefresh);
  window.addEventListener("scroll", scheduleRevealStateRefresh, { passive: true });
  window.addEventListener("resize", scheduleRevealStateRefresh, { passive: true });

  const observer = new MutationObserver(() => {
    scheduleRevealStateRefresh();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
}

initialize();
