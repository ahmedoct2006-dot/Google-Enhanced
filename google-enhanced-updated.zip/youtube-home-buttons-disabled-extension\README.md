# YouTube Background Color Changer No Home Buttons

This is a standalone Chrome extension that adds a `Colors` button next to YouTube's mic button.

When you click it, a panel opens so you can choose separate colors for:

- left side
- top side
- right side

## Install

1. Open `chrome://extensions`
2. Turn on `Developer mode`
3. Click `Load unpacked`
4. Select the `youtube-home-buttons-disabled-extension` folder

## Notes

- This folder is a duplicate of the main background color changer extension.
- YouTube's built-in top home/yoodle button area is forcibly hidden on load and after page changes.
- The custom `Colors` button is kept and continues to remount itself after YouTube navigation.
- Colors are saved with `chrome.storage.local`.
