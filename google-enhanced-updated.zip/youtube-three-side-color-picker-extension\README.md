# YouTube Three-Side Color Picker

This Chrome extension adds a small `Colors` button beside YouTube's mic button.

It lets you choose separate colors for:

- Left side
- Top side
- Middle side

The picker opens as a small frame with preset color swatches and a custom color input. Text and icons automatically switch to white on dark side colors and black on light side colors. Subscribe buttons and ad CTA buttons are left alone.

## Files

- `manifest.json` - Chrome extension manifest
- `content.js` - injects the three-area color picker and saves colors
- `styles.css` - applies your left, top, and middle colors to YouTube

## Install

1. Open `chrome://extensions`
2. Turn on Developer mode
3. Click Load unpacked
4. Select this folder

## Use

1. Open YouTube
2. Click the `Colors` button next to the mic
3. Pick `Left side`, `Top side`, or `Middle side`
4. Choose a preset swatch or use the custom color picker
5. The extension remembers each color automatically
6. Right-click the `Colors` button to reset all colors
