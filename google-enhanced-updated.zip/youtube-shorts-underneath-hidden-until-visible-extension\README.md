# YouTube Shorts - Underneath Hidden Until Visible

This Chrome extension hides the underneath (next) Shorts preview until you scroll down and it becomes visible in the viewport. The thumbnail element (`.reel-video-in-sequence-thumbnail`) is kept hidden to prevent it from peeking through under the current Short.

It targets the element you referenced (e.g. `.reel-video-in-sequence-thumbnail`) plus a few related container elements YouTube uses around it.

## Install (Chrome / Edge)

1. Open `chrome://extensions/`
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Select this folder: `youtube-shorts-underneath-hidden-until-visible-extension`

## Notes

- Works on `https://www.youtube.com/*`
- Only hides on Shorts URLs like `/shorts/<id>`
- No data collection
