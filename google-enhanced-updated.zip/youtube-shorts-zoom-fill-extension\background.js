chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "GET_TAB_ZOOM") {
    return false;
  }

  const tabId = sender.tab?.id;

  if (typeof tabId !== "number") {
    sendResponse({ zoom: 1 });
    return false;
  }

  chrome.tabs.getZoom(tabId, (zoomFactor) => {
    if (chrome.runtime.lastError) {
      sendResponse({ zoom: 1, error: chrome.runtime.lastError.message });
      return;
    }

    sendResponse({ zoom: zoomFactor });
  });

  return true;
});
