const GOOGLE_ACCOUNT_UI_STATE_KEY = "googleAccountUiState";
const GOOGLE_ACCOUNT_PROFILE_URL = "https://myaccount.google.com/";
const GOOGLE_ACCOUNT_SYNC_INTERVAL_MS = 1500;

function isVisible(element) {
  if (!element) {
    return false;
  }

  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function looksLikeAvatarUrl(value) {
  return /(?:googleusercontent|ggpht)\.com/i.test(value || "");
}

function normalizeAvatarUrl(value) {
  if (!value) {
    return "";
  }

  const decodedValue = value
    .replace(/\\u003d/gi, "=")
    .replace(/\\u0026/gi, "&")
    .replace(/\\u002f/gi, "/")
    .replace(/\\\//g, "/")
    .replace(/&amp;/gi, "&");

  if (!looksLikeAvatarUrl(decodedValue)) {
    return "";
  }

  return decodedValue;
}

function getCandidateElements() {
  return [
    ...document.querySelectorAll('a[aria-label*="Google Account" i] img, button[aria-label*="Google Account" i] img'),
    ...document.querySelectorAll('img[alt*="Google Account" i]'),
    ...document.querySelectorAll('a[href*="myaccount.google."] img, a[href*="SignOutOptions"] img'),
    ...document.querySelectorAll('header img[src*="googleusercontent.com" i], img[src*="googleusercontent.com" i][data-iml]')
  ];
}

function extractGoogleAccountStateFromDom() {
  const seen = new Set();
  const candidates = getCandidateElements();

  for (const image of candidates) {
    if (!image || seen.has(image)) {
      continue;
    }

    seen.add(image);

    const src = normalizeAvatarUrl(image.currentSrc || image.src || "");
    if (!src || !isVisible(image)) {
      continue;
    }

    const trigger = image.closest("a, button") || image;
    const label = trigger?.getAttribute("aria-label") || image.alt || "Google Account";
    const href = trigger?.tagName === "A" ? trigger.href : GOOGLE_ACCOUNT_PROFILE_URL;

    return {
      signedIn: true,
      avatarUrl: src,
      label,
      profileUrl: href || GOOGLE_ACCOUNT_PROFILE_URL,
      updatedAt: Date.now()
    };
  }

  return null;
}

async function readStoredState() {
  return new Promise((resolve) => {
    chrome.storage.local.get([GOOGLE_ACCOUNT_UI_STATE_KEY], (result) => {
      resolve(result?.[GOOGLE_ACCOUNT_UI_STATE_KEY] || null);
    });
  });
}

async function writeStateIfChanged(nextState) {
  const previousState = await readStoredState();

  if (
    previousState &&
    previousState.avatarUrl === nextState.avatarUrl &&
    previousState.label === nextState.label &&
    previousState.profileUrl === nextState.profileUrl
  ) {
    return;
  }

  chrome.storage.local.set({
    [GOOGLE_ACCOUNT_UI_STATE_KEY]: nextState
  });
}

async function synchronizeGoogleAccountState() {
  const state = extractGoogleAccountStateFromDom();

  if (!state) {
    return;
  }

  await writeStateIfChanged(state);
}

let syncTimeoutId = null;

function queueSync() {
  if (syncTimeoutId !== null) {
    window.clearTimeout(syncTimeoutId);
  }

  syncTimeoutId = window.setTimeout(() => {
    syncTimeoutId = null;
    synchronizeGoogleAccountState();
  }, GOOGLE_ACCOUNT_SYNC_INTERVAL_MS);
}

queueSync();

const observer = new MutationObserver(() => {
  queueSync();
});

observer.observe(document.documentElement, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ["src", "href", "aria-label", "alt"]
});

window.addEventListener("load", () => {
  queueSync();
});
