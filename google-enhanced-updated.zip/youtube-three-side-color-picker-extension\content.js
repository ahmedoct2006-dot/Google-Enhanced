const STORAGE_KEY = "ytThreeSideColorPickerSettings";
const REGIONS = ["left", "top", "middle"];
const PRESET_COLORS = [
  "#ffffff",
  "#f8fafc",
  "#fde68a",
  "#bfdbfe",
  "#bbf7d0",
  "#fecaca",
  "#f5d0fe",
  "#c7d2fe",
  "#0f172a",
  "#111827",
  "#1e3a8a",
  "#14532d",
  "#7f1d1d",
  "#581c87",
  "#000000"
];
const CTA_BUTTON_LABELS = [
  "watch",
  "learn more",
  "shop now",
  "install",
  "download",
  "book now",
  "sign up",
  "play now",
  "visit site",
  "visit now",
  "get offer"
];
const DEFAULT_SETTINGS = {
  activeRegion: "middle",
  colors: {
    left: "#d6e4ff",
    top: "#dfe7ff",
    middle: "#eef4ff"
  }
};

const state = {
  settings: cloneSettings(DEFAULT_SETTINGS),
  buttonSlot: null,
  button: null,
  panel: null,
  colorInput: null,
  colorValue: null,
  regionButtons: {},
  observer: null,
  rafId: 0
};

function normalizeHex(value) {
  const hex = typeof value === "string" ? value.trim() : "";
  return /^#[0-9a-fA-F]{6}$/.test(hex) ? hex.toLowerCase() : "#ffffff";
}

function cloneSettings(value) {
  const activeRegion = REGIONS.includes(value?.activeRegion)
    ? value.activeRegion
    : DEFAULT_SETTINGS.activeRegion;

  return {
    activeRegion,
    colors: {
      left: normalizeHex(value?.colors?.left ?? DEFAULT_SETTINGS.colors.left),
      top: normalizeHex(value?.colors?.top ?? DEFAULT_SETTINGS.colors.top),
      middle: normalizeHex(value?.colors?.middle ?? DEFAULT_SETTINGS.colors.middle)
    }
  };
}

function hexToRgb(hex) {
  const clean = normalizeHex(hex).slice(1);
  return {
    r: parseInt(clean.slice(0, 2), 16),
    g: parseInt(clean.slice(2, 4), 16),
    b: parseInt(clean.slice(4, 6), 16)
  };
}

function rgbToHex({ r, g, b }) {
  const channelToHex = (channel) =>
    Math.max(0, Math.min(255, Math.round(channel))).toString(16).padStart(2, "0");

  return `#${channelToHex(r)}${channelToHex(g)}${channelToHex(b)}`;
}

function mixHex(primaryHex, secondaryHex, primaryWeight) {
  const first = hexToRgb(primaryHex);
  const second = hexToRgb(secondaryHex);
  const weight = Math.max(0, Math.min(1, primaryWeight));
  const otherWeight = 1 - weight;

  return rgbToHex({
    r: first.r * weight + second.r * otherWeight,
    g: first.g * weight + second.g * otherWeight,
    b: first.b * weight + second.b * otherWeight
  });
}

function getLinearChannel(channel) {
  const normalized = channel / 255;
  return normalized <= 0.04045
    ? normalized / 12.92
    : ((normalized + 0.055) / 1.055) ** 2.4;
}

function getLuminance(hex) {
  const { r, g, b } = hexToRgb(hex);
  return (
    0.2126 * getLinearChannel(r) +
    0.7152 * getLinearChannel(g) +
    0.0722 * getLinearChannel(b)
  );
}

function getContrastRatio(firstHex, secondHex) {
  const first = getLuminance(firstHex);
  const second = getLuminance(secondHex);
  const lighter = Math.max(first, second);
  const darker = Math.min(first, second);
  return (lighter + 0.05) / (darker + 0.05);
}

function getReadableForeground(color) {
  return getLuminance(color) > 0.179 ? "#000000" : "#ffffff";
}

function getMutedForeground(color) {
  return getReadableForeground(color) === "#ffffff"
    ? "rgba(255, 255, 255, 0.78)"
    : "rgba(0, 0, 0, 0.72)";
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function getNormalizedText(value) {
  return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function isAdCtaCandidate(element) {
  if (!(element instanceof HTMLElement)) {
    return false;
  }

  const text = getNormalizedText(element.textContent);
  const ariaLabel = getNormalizedText(element.getAttribute("aria-label"));
  const title = getNormalizedText(element.getAttribute("title"));
  const hasCtaLabel = CTA_BUTTON_LABELS.includes(text) ||
    CTA_BUTTON_LABELS.includes(ariaLabel) ||
    CTA_BUTTON_LABELS.includes(title);
  const hasButtonStructure = element.matches(
    "button, [role='button'], yt-button-shape, ad-button-view-model, .ytwAdButtonGroupViewModelHostPrimaryButton, .yt-spec-button-shape-next, [class*='AdButton']"
  ) || Boolean(element.closest(
    "ad-button-view-model, .ytwAdButtonGroupViewModelHostPrimaryButton, yt-button-shape, .yt-spec-button-shape-next"
  ));

  return hasButtonStructure && hasCtaLabel;
}

function markProtectedButtons() {
  document.querySelectorAll("[data-ytcp-protected-button]").forEach((element) => {
    if (element instanceof HTMLElement) {
      element.removeAttribute("data-ytcp-protected-button");
    }
  });

  document.querySelectorAll(
    "ytd-subscribe-button-renderer, #subscribe-button, button[aria-label*='Subscribe' i], yt-button-shape:has(button[aria-label*='Subscribe' i])"
  ).forEach((element) => {
    if (element instanceof HTMLElement) {
      element.setAttribute("data-ytcp-protected-button", "subscribe");
    }
  });

  document.querySelectorAll(
    "ad-button-view-model, .ytwAdButtonGroupViewModelHostPrimaryButton, button, [role='button'], yt-button-shape, .yt-spec-button-shape-next"
  ).forEach((element) => {
    if (isAdCtaCandidate(element)) {
      element.setAttribute("data-ytcp-protected-button", "ad-cta");
    }
  });
}

function getVisibleRect(element) {
  if (!(element instanceof HTMLElement)) {
    return null;
  }

  const rect = element.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) {
    return null;
  }

  if (rect.bottom <= 0 || rect.right <= 0) {
    return null;
  }

  if (rect.top >= window.innerHeight || rect.left >= window.innerWidth) {
    return null;
  }

  return rect;
}

function updateLeftFillWidth() {
  const root = document.documentElement;
  const expandedGuideCandidates = [
    document.querySelector("ytd-guide-renderer"),
    document.querySelector("tp-yt-app-drawer[opened] #guide-content"),
    document.querySelector("tp-yt-app-drawer[opened] #guide-inner-content"),
    document.querySelector("tp-yt-app-drawer[opened] #contentContainer")
  ];

  for (const candidate of expandedGuideCandidates) {
    const rect = getVisibleRect(candidate);
    if (rect && rect.right > 120) {
      root.style.setProperty("--ytcp-left-fill-width", `${Math.round(rect.right)}px`);
      root.classList.remove("ytcp-compact-left");
      return;
    }
  }

  const miniGuide = document.querySelector("ytd-mini-guide-renderer");
  const miniGuideRect = getVisibleRect(miniGuide);
  if (miniGuideRect) {
    root.style.setProperty("--ytcp-left-fill-width", `${Math.round(miniGuideRect.right)}px`);
    root.classList.add("ytcp-compact-left");
    return;
  }

  root.style.setProperty("--ytcp-left-fill-width", "72px");
  root.classList.add("ytcp-compact-left");
}

function isHomeLikePage() {
  return window.location.pathname === "/" || window.location.pathname === "/feed/subscriptions";
}

function getRegionSurface(region) {
  const color = state.settings.colors[region];
  const mixTarget = getReadableForeground(color) === "#ffffff" ? "#020617" : "#ffffff";

  if (region === "top") {
    return mixHex(color, mixTarget, 0.96);
  }

  if (region === "left") {
    return mixHex(color, mixTarget, 0.92);
  }

  return mixHex(color, mixTarget, 0.88);
}

function getRegionCard(region) {
  const surface = getRegionSurface(region);
  const mixTarget = getReadableForeground(state.settings.colors[region]) === "#ffffff"
    ? "#020617"
    : "#ffffff";
  return mixHex(surface, mixTarget, 0.94);
}

function storageGet(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => resolve(result));
  });
}

function storageSet(value) {
  return new Promise((resolve) => {
    chrome.storage.local.set(value, () => resolve());
  });
}

async function persistSettings() {
  await storageSet({
    [STORAGE_KEY]: state.settings
  });
}

function setThemeVariables() {
  const root = document.documentElement;
  const leftColor = state.settings.colors.left;
  const topColor = state.settings.colors.top;
  const middleColor = state.settings.colors.middle;
  const activeColor = state.settings.colors[state.settings.activeRegion];
  const leftForeground = getReadableForeground(leftColor);
  const topForeground = getReadableForeground(topColor);
  const middleForeground = getReadableForeground(middleColor);

  root.style.setProperty("--ytcp-left-color", getRegionSurface("left"));
  root.style.setProperty("--ytcp-top-color", getRegionSurface("top"));
  root.style.setProperty("--ytcp-middle-color", getRegionSurface("middle"));
  root.style.setProperty("--ytcp-left-card-color", getRegionCard("left"));
  root.style.setProperty("--ytcp-top-card-color", getRegionCard("top"));
  root.style.setProperty("--ytcp-middle-card-color", getRegionCard("middle"));
  root.style.setProperty("--ytcp-left-border-color", mixHex(leftColor, leftForeground === "#ffffff" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcp-top-border-color", mixHex(topColor, topForeground === "#ffffff" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcp-middle-border-color", mixHex(middleColor, middleForeground === "#ffffff" ? "#020617" : "#ffffff", 0.72));
  root.style.setProperty("--ytcp-left-foreground", leftForeground);
  root.style.setProperty("--ytcp-top-foreground", topForeground);
  root.style.setProperty("--ytcp-middle-foreground", middleForeground);
  root.style.setProperty("--ytcp-left-muted", getMutedForeground(leftColor));
  root.style.setProperty("--ytcp-top-muted", getMutedForeground(topColor));
  root.style.setProperty("--ytcp-middle-muted", getMutedForeground(middleColor));
  root.classList.add("ytcp-enabled");
  root.classList.toggle("ytcp-home-layout", isHomeLikePage());
  root.classList.toggle("ytcp-left-dark", leftForeground === "#ffffff");
  root.classList.toggle("ytcp-top-dark", topForeground === "#ffffff");
  root.classList.toggle("ytcp-middle-dark", middleForeground === "#ffffff");
  updateLeftFillWidth();

  if (state.button) {
    state.button.style.setProperty("--ytcp-button-swatch", activeColor);
    state.button.setAttribute(
      "aria-label",
      `Pick YouTube color for ${state.settings.activeRegion} side. Current color ${activeColor.toUpperCase()}`
    );
    state.button.title = `${capitalize(state.settings.activeRegion)} side color (${activeColor.toUpperCase()})`;
  }

  if (state.colorInput) {
    state.colorInput.value = activeColor;
  }

  if (state.colorValue) {
    state.colorValue.textContent = activeColor.toUpperCase();
  }

  REGIONS.forEach((region) => {
    const button = state.regionButtons[region];
    if (!button) {
      return;
    }

    button.dataset.active = String(region === state.settings.activeRegion);
    button.style.setProperty("--ytcp-region-swatch", state.settings.colors[region]);
  });
}

async function setActiveRegion(region) {
  if (!REGIONS.includes(region)) {
    return;
  }

  state.settings.activeRegion = region;
  setThemeVariables();
  await persistSettings();
}

async function handleColorChange(value) {
  state.settings.colors[state.settings.activeRegion] = normalizeHex(value);
  setThemeVariables();
  await persistSettings();
}

async function resetColors() {
  state.settings = cloneSettings(DEFAULT_SETTINGS);
  setThemeVariables();
  await persistSettings();
}

function closePanel() {
  if (!state.panel || !state.button) {
    return;
  }

  state.panel.hidden = true;
  state.button.dataset.open = "false";
  state.button.setAttribute("aria-expanded", "false");
}

function openPanel() {
  if (!state.panel || !state.button) {
    return;
  }

  const rect = state.button.getBoundingClientRect();
  const panelWidth = Math.min(520, window.innerWidth - 24);
  const left = Math.max(12, Math.min(window.innerWidth - panelWidth - 12, rect.right - panelWidth));

  state.panel.hidden = false;
  state.panel.style.top = `${Math.max(72, rect.bottom + 10)}px`;
  state.panel.style.left = `${left}px`;
  state.button.dataset.open = "true";
  state.button.setAttribute("aria-expanded", "true");
}

function togglePanel() {
  if (!state.panel) {
    return;
  }

  if (state.panel.hidden) {
    openPanel();
  } else {
    closePanel();
  }
}

function createRegionButton(region, label) {
  return `
    <button class="ytcp-region-button" type="button" data-region="${region}" data-active="false">
      <span class="ytcp-region-swatch" aria-hidden="true"></span>
      <span>${label}</span>
    </button>
  `;
}

function createPresetButton(color) {
  const label = color.toUpperCase();
  return `
    <button class="ytcp-preset-button" type="button" data-color="${color}" aria-label="Apply preset color ${label}" title="${label}">
      <span class="ytcp-preset-swatch" style="--ytcp-preset-color: ${color};" aria-hidden="true"></span>
    </button>
  `;
}

function createPanel() {
  if (state.panel) {
    return state.panel;
  }

  const panel = document.createElement("section");
  panel.id = "ytcp-panel";
  panel.hidden = true;
  panel.innerHTML = `
    <div class="ytcp-panel-header">
      <div>
        <h2 class="ytcp-panel-title">YouTube Color Picker</h2>
        <p class="ytcp-panel-subtitle">Pick a separate color for the left side, top side, and middle side.</p>
      </div>
      <button class="ytcp-close-button" type="button" aria-label="Close color picker">x</button>
    </div>
    <div class="ytcp-regions" role="tablist" aria-label="Choose YouTube area">
      ${createRegionButton("left", "Left side")}
      ${createRegionButton("top", "Top side")}
      ${createRegionButton("middle", "Middle side")}
    </div>
    <div class="ytcp-preview" aria-hidden="true">
      <div class="ytcp-preview-top"></div>
      <div class="ytcp-preview-side"></div>
      <div class="ytcp-preview-main"></div>
      <div class="ytcp-preview-card ytcp-preview-card-a"></div>
      <div class="ytcp-preview-card ytcp-preview-card-b"></div>
      <div class="ytcp-preview-line ytcp-preview-line-vertical"></div>
      <div class="ytcp-preview-line ytcp-preview-line-horizontal"></div>
    </div>
    <div class="ytcp-presets" aria-label="Preset colors">
      ${PRESET_COLORS.map(createPresetButton).join("")}
    </div>
    <label class="ytcp-field">
      <span class="ytcp-field-copy">
        <span class="ytcp-field-title">Selected area color</span>
        <span class="ytcp-field-hint">Choose a side first, then use the color picker.</span>
      </span>
      <input id="ytcp-color-input" class="ytcp-color-input" type="color" />
      <span class="ytcp-color-value">#EEF4FF</span>
    </label>
    <div class="ytcp-actions">
      <button class="ytcp-reset-button" type="button">Reset all</button>
    </div>
  `;

  panel.querySelector(".ytcp-close-button")?.addEventListener("click", closePanel);
  panel.querySelector(".ytcp-reset-button")?.addEventListener("click", () => {
    resetColors();
  });

  panel.querySelectorAll(".ytcp-preset-button").forEach((button) => {
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }

    button.addEventListener("click", () => {
      handleColorChange(button.dataset.color);
    });
  });

  const colorInput = panel.querySelector(".ytcp-color-input");
  const colorValue = panel.querySelector(".ytcp-color-value");

  colorInput?.addEventListener("input", (event) => {
    handleColorChange(event.target.value);
  });

  panel.querySelectorAll(".ytcp-region-button").forEach((button) => {
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }

    const region = button.dataset.region;
    if (!REGIONS.includes(region)) {
      return;
    }

    state.regionButtons[region] = button;
    button.addEventListener("click", () => {
      setActiveRegion(region);
    });
  });

  document.body.appendChild(panel);
  state.panel = panel;
  state.colorInput = colorInput;
  state.colorValue = colorValue;
  setThemeVariables();
  return panel;
}

function createToolbarButton() {
  if (state.buttonSlot) {
    return state.buttonSlot;
  }

  const slot = document.createElement("div");
  slot.id = "ytcp-toolbar-slot";

  const button = document.createElement("button");
  button.id = "ytcp-toolbar-button";
  button.type = "button";
  button.setAttribute("aria-haspopup", "dialog");
  button.setAttribute("aria-expanded", "false");
  button.dataset.open = "false";
  button.innerHTML = `
    <span class="ytcp-toolbar-swatch" aria-hidden="true"></span>
    <span class="ytcp-toolbar-label">Colors</span>
  `;

  button.addEventListener("click", togglePanel);
  button.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    resetColors();
  });

  slot.appendChild(button);
  state.buttonSlot = slot;
  state.button = button;
  setThemeVariables();
  return slot;
}

function getToolbarAnchor() {
  return (
    document.querySelector("ytd-masthead #voice-search-button") ||
    document.querySelector("#voice-search-button") ||
    document.querySelector("ytd-masthead ytd-voice-search-button-renderer") ||
    document.querySelector("ytd-voice-search-button-renderer")
  );
}

function getToolbarFallbackHost() {
  return (
    document.querySelector("ytd-masthead #end") ||
    document.querySelector("#end") ||
    document.querySelector("ytd-masthead #buttons") ||
    document.querySelector("ytd-masthead #center") ||
    document.querySelector("ytd-masthead")
  );
}

function mountToolbarButton() {
  const anchor = getToolbarAnchor();
  const slot = createToolbarButton();
  createPanel();
  updateLeftFillWidth();

  if (getVisibleRect(anchor)) {
    if (anchor.nextElementSibling !== slot) {
      anchor.insertAdjacentElement("afterend", slot);
    }
    return;
  }

  const fallbackHost = getToolbarFallbackHost();
  if (fallbackHost instanceof Element && !fallbackHost.contains(slot)) {
    fallbackHost.appendChild(slot);
  }
}

function scheduleRefresh() {
  if (state.rafId) {
    cancelAnimationFrame(state.rafId);
  }

  state.rafId = requestAnimationFrame(() => {
    state.rafId = 0;
    markProtectedButtons();
    mountToolbarButton();
    if (state.panel && !state.panel.hidden) {
      openPanel();
    }
  });
}

function setupObservers() {
  document.addEventListener("click", (event) => {
    if (!state.panel || state.panel.hidden) {
      return;
    }

    const target = event.target;
    if (state.panel.contains(target) || state.button?.contains(target)) {
      return;
    }

    closePanel();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closePanel();
    }
  });

  window.addEventListener("resize", scheduleRefresh, { passive: true });
  window.addEventListener("scroll", scheduleRefresh, { passive: true });
  window.addEventListener("yt-navigate-finish", () => {
    setThemeVariables();
    scheduleRefresh();
  }, { passive: true });

  const observer = new MutationObserver(() => {
    scheduleRefresh();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  state.observer = observer;
}

async function initialize() {
  if (!document.body) {
    window.addEventListener("DOMContentLoaded", initialize, { once: true });
    return;
  }

  const stored = await storageGet(STORAGE_KEY);
  state.settings = cloneSettings(stored?.[STORAGE_KEY]);
  setThemeVariables();
  createToolbarButton();
  createPanel();
  markProtectedButtons();
  setupObservers();
  scheduleRefresh();
}

initialize();
