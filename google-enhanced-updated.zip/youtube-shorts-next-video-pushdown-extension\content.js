const ROOT_CLASS = "yt-shorts-next-video-pushdown-fix";
const STYLE_ID = "yt-shorts-next-video-pushdown-style";
const MASK_ID = "yt-shorts-next-video-pushdown-mask";
const OFFSET_ATTR = "data-yt-shorts-next-video-pushdown";
const HIDDEN_ATTR = "data-yt-shorts-next-video-hidden";
const ACTIVE_RENDERER_CLASS = "yt-shorts-next-video-pushdown--active";
const BOTTOM_BUFFER_PX = 24;
const FRAME_SELECTOR = [
  "#shorts-player",
  "#player-container",
  ".html5-video-player",
  ".html5-video-container",
  "#video-container",
  "#viewport",
  ".reel-player-wrapper",
  ".reel-player-container"
].join(", ");
const VIDEO_SELECTOR = [
  "video",
  ".html5-main-video",
  ".video-stream.html5-main-video"
].join(", ");
const UNDERLAY_SELECTOR = [
  "ytd-shorts .reel-video-in-sequence-container",
  "ytd-shorts .reel-video-in-sequence-new",
  "ytd-shorts ytd-reel-non-video-content-renderer",
  "ytd-shorts #nvc-container",
  "ytd-shorts .reel-video-in-sequence-thumbnail"
].join(", ");
const CLIP_SELECTORS = [
  "ytd-shorts",
  "#shorts-container",
  "#shorts-inner-container",
  "ytd-reel-video-renderer",
  "#shorts-player",
  "#player-container",
  "#video-container",
  "#viewport",
  ".reel-player-wrapper",
  ".reel-player-container"
];

let rafId = 0;

function isShortsPage() {
  return window.location.pathname.startsWith("/shorts/");
}

function ensureStyleElement() {
  let style = document.getElementById(STYLE_ID);

  if (!(style instanceof HTMLStyleElement)) {
    const clipRule = CLIP_SELECTORS
      .map((selector) => `html.${ROOT_CLASS} ${selector}`)
      .join(",\n      ");

    style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      ${clipRule} {
        overflow: hidden !important;
      }

      html.${ROOT_CLASS} ytd-reel-video-renderer.${ACTIVE_RENDERER_CLASS} {
        position: relative !important;
      }

      html.${ROOT_CLASS} #${MASK_ID} {
        position: fixed !important;
        display: none !important;
        pointer-events: none !important;
        background: var(--yt-spec-base-background, #ffffff) !important;
        z-index: 2147483646 !important;
      }
    `;
    document.documentElement.appendChild(style);
  }

  return style;
}

function ensureMaskElement() {
  let mask = document.getElementById(MASK_ID);

  if (!(mask instanceof HTMLDivElement)) {
    mask = document.createElement("div");
    mask.id = MASK_ID;
    document.documentElement.appendChild(mask);
  }

  return mask;
}

function hideMask() {
  const mask = document.getElementById(MASK_ID);

  if (mask instanceof HTMLElement) {
    mask.style.setProperty("display", "none", "important");
  }
}

function getMaskBackgroundColor() {
  const backgroundTarget =
    document.querySelector("ytd-app") ||
    document.body ||
    document.documentElement;
  const backgroundColor = window.getComputedStyle(backgroundTarget).backgroundColor;

  if (!backgroundColor || backgroundColor === "rgba(0, 0, 0, 0)") {
    return "";
  }

  return backgroundColor;
}

function syncMask(boundaryRect) {
  const visibleLeft = Math.max(0, Math.floor(boundaryRect.left));
  const visibleRight = Math.min(window.innerWidth, Math.ceil(boundaryRect.right));
  const width = Math.max(0, visibleRight - visibleLeft);
  const top = Math.max(0, Math.floor(boundaryRect.bottom));
  const height = Math.max(0, window.innerHeight - top + BOTTOM_BUFFER_PX);

  if (width <= 0 || height <= 0) {
    hideMask();
    return;
  }

  const mask = ensureMaskElement();
  const backgroundColor = getMaskBackgroundColor();

  mask.style.setProperty("display", "block", "important");
  mask.style.setProperty("left", `${visibleLeft}px`, "important");
  mask.style.setProperty("top", `${top}px`, "important");
  mask.style.setProperty("width", `${width}px`, "important");
  mask.style.setProperty("height", `${height}px`, "important");

  if (backgroundColor) {
    mask.style.setProperty("background", backgroundColor, "important");
  } else {
    mask.style.removeProperty("background");
  }
}

function getVisibleRect(element) {
  if (!(element instanceof HTMLElement)) {
    return null;
  }

  const rect = element.getBoundingClientRect();

  if (rect.width <= 0 || rect.height <= 0) {
    return null;
  }

  const visibleLeft = Math.max(0, rect.left);
  const visibleTop = Math.max(0, rect.top);
  const visibleRight = Math.min(window.innerWidth, rect.right);
  const visibleBottom = Math.min(window.innerHeight, rect.bottom);
  const visibleWidth = Math.max(0, visibleRight - visibleLeft);
  const visibleHeight = Math.max(0, visibleBottom - visibleTop);

  if (visibleWidth <= 0 || visibleHeight <= 0) {
    return null;
  }

  return {
    rect,
    visibleArea: visibleWidth * visibleHeight
  };
}

function getLargestVisibleElement(elements) {
  let bestElement = null;
  let bestArea = 0;

  elements.forEach((element) => {
    const visible = getVisibleRect(element);

    if (!visible || visible.visibleArea <= bestArea) {
      return;
    }

    bestArea = visible.visibleArea;
    bestElement = element;
  });

  return bestElement;
}

function getActiveRenderer() {
  return getLargestVisibleElement(Array.from(document.querySelectorAll("ytd-reel-video-renderer")));
}

function getActiveVideo(activeRenderer = getActiveRenderer()) {
  if (activeRenderer instanceof HTMLElement) {
    const rendererVideo = getLargestVisibleElement(Array.from(activeRenderer.querySelectorAll(VIDEO_SELECTOR)));

    if (rendererVideo instanceof HTMLElement) {
      return rendererVideo;
    }
  }

  return getLargestVisibleElement(Array.from(document.querySelectorAll(VIDEO_SELECTOR)));
}

function getActiveFrame(activeRenderer) {
  if (activeRenderer instanceof HTMLElement) {
    const rendererFrame = getLargestVisibleElement(Array.from(activeRenderer.querySelectorAll(FRAME_SELECTOR)));

    if (rendererFrame instanceof HTMLElement) {
      return rendererFrame;
    }

    return activeRenderer;
  }

  return getLargestVisibleElement(Array.from(document.querySelectorAll(FRAME_SELECTOR)));
}

function clearOffset(element) {
  if (!(element instanceof HTMLElement) || !element.hasAttribute(OFFSET_ATTR)) {
    return;
  }

  element.style.removeProperty("translate");
  element.style.removeProperty("will-change");
  element.removeAttribute(OFFSET_ATTR);
}

function clearHidden(element) {
  if (!(element instanceof HTMLElement) || !element.hasAttribute(HIDDEN_ATTR)) {
    return;
  }

  element.style.removeProperty("visibility");
  element.style.removeProperty("pointer-events");
  element.removeAttribute(HIDDEN_ATTR);
}

function clearAllEffects() {
  document.querySelectorAll(`[${OFFSET_ATTR}], [${HIDDEN_ATTR}]`).forEach((element) => {
    clearOffset(element);
    clearHidden(element);
  });
}

function getTopLevelTargets(candidates) {
  return candidates.filter((element) => {
    return !candidates.some((other) => other !== element && other.contains(element));
  });
}

function getUnderlayTargets(boundaryRect, activeRenderer) {
  const overlappingRenderers = Array.from(document.querySelectorAll("ytd-reel-video-renderer")).filter((element) => {
    if (!(element instanceof HTMLElement) || element === activeRenderer) {
      return false;
    }

    const visible = getVisibleRect(element);

    if (!visible) {
      return false;
    }

    return (
      visible.rect.bottom > boundaryRect.bottom - 2 &&
      visible.rect.top < boundaryRect.bottom + BOTTOM_BUFFER_PX
    );
  });

  const candidates = [
    ...overlappingRenderers,
    ...Array.from(document.querySelectorAll(UNDERLAY_SELECTOR))
  ].filter((element) => {
    if (!(element instanceof HTMLElement)) {
      return false;
    }

    const visible = getVisibleRect(element);

    if (!visible) {
      return false;
    }

    return visible.rect.bottom > boundaryRect.bottom - 2 && visible.rect.top < window.innerHeight;
  });

  const topLevelTargets = getTopLevelTargets(candidates);

  if (topLevelTargets.length > 0) {
    return topLevelTargets;
  }

  return Array.from(document.querySelectorAll("ytd-reel-video-renderer")).filter((element) => {
    if (!(element instanceof HTMLElement) || element === activeRenderer) {
      return false;
    }

    const visible = getVisibleRect(element);

    if (!visible) {
      return false;
    }

    return visible.rect.top >= boundaryRect.top && visible.rect.top < boundaryRect.bottom + 80;
  });
}

function applyOffset(element, pixels) {
  if (!(element instanceof HTMLElement) || pixels <= 0) {
    clearOffset(element);
    return;
  }

  element.style.setProperty("translate", `0 ${Math.ceil(pixels)}px`, "important");
  element.style.setProperty("will-change", "transform", "important");
  element.setAttribute(OFFSET_ATTR, "true");
}

function applyHiddenState(element, shouldHide) {
  if (!(element instanceof HTMLElement)) {
    return;
  }

  if (!shouldHide) {
    clearHidden(element);
    return;
  }

  element.style.setProperty("visibility", "hidden", "important");
  element.style.setProperty("pointer-events", "none", "important");
  element.setAttribute(HIDDEN_ATTR, "true");
}

function syncActiveRendererClass(activeRenderer) {
  document.querySelectorAll("ytd-reel-video-renderer").forEach((renderer) => {
    if (!(renderer instanceof HTMLElement)) {
      return;
    }

    renderer.classList.toggle(ACTIVE_RENDERER_CLASS, renderer === activeRenderer);
  });
}

function syncPushdownFix() {
  ensureStyleElement();

  const shortsPage = isShortsPage();
  document.documentElement.classList.toggle(ROOT_CLASS, shortsPage);

  clearAllEffects();

  if (!shortsPage) {
    hideMask();
    syncActiveRendererClass(null);
    return;
  }

  const activeRenderer = getActiveRenderer();
  const activeFrame = getActiveFrame(activeRenderer);
  const activeVideo = getActiveVideo(activeRenderer);
  const boundaryElement = activeFrame instanceof HTMLElement ? activeFrame : activeVideo;

  syncActiveRendererClass(activeRenderer);

  if (!(boundaryElement instanceof HTMLElement)) {
    hideMask();
    return;
  }

  const boundaryRect = boundaryElement.getBoundingClientRect();
  syncMask(boundaryRect);
  const targets = getUnderlayTargets(boundaryRect, activeRenderer);

  targets.forEach((target) => {
    if (!(target instanceof HTMLElement)) {
      return;
    }

    const targetRect = target.getBoundingClientRect();
    const overlap = boundaryRect.bottom + BOTTOM_BUFFER_PX - targetRect.top;
    const shouldHide = overlap > 0 && targetRect.bottom > boundaryRect.bottom - 2;

    if (shouldHide) {
      applyOffset(target, overlap);
      applyHiddenState(target, true);
      return;
    }

    applyHiddenState(target, false);
  });
}

function scheduleSync() {
  if (rafId) {
    cancelAnimationFrame(rafId);
  }

  rafId = requestAnimationFrame(() => {
    rafId = 0;
    syncPushdownFix();
  });
}

function initialize() {
  syncPushdownFix();

  window.addEventListener("yt-navigate-finish", scheduleSync, { passive: true });
  window.addEventListener("popstate", scheduleSync, { passive: true });
  window.addEventListener("resize", scheduleSync, { passive: true });
  window.addEventListener("scroll", scheduleSync, { passive: true });
  window.addEventListener("wheel", scheduleSync, { passive: true });
  window.addEventListener("focus", scheduleSync, { passive: true });
  document.addEventListener("visibilitychange", scheduleSync, { passive: true });

  const observer = new MutationObserver(() => {
    scheduleSync();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "style", "hidden"]
  });
}

initialize();
