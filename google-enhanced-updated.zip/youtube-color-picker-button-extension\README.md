# YouTube Three-Side Color Picker

This Chrome extension adds a `Color` button beside YouTube's mic button.

Click it to choose separate colors for:

- left side
- top side
- middle side

## Install

1. Open `chrome://extensions`
2. Turn on `Developer mode`
3. Click `Load unpacked`
4. Select the `youtube-color-picker-button-extension` folder

## Notes

- Colors are saved with `chrome.storage.local`.
- Right-click the `Color` button to reset all three colors.
- The extension keeps YouTube's normal logo and home button behavior intact.
