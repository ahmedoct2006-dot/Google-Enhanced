# YouTube Shorts Next Video Pushdown Fix

This is a separate Chrome extension that pushes the underneath Shorts preview lower and hides it while it overlaps the bottom of the active video.

It is designed for the black overlap/bar issue shown in your screenshot.

## Load it in Chrome

1. Open `chrome://extensions`
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Select the `youtube-shorts-next-video-pushdown-extension` folder

## What it does

- Detects the active Shorts video
- Measures the visible Shorts player frame instead of the transformed video element
- Moves the underneath layer farther down if it overlaps the active video
- Hides the underneath renderer while it is still intruding into view
- Clips the Shorts container so the shifted layer stays out of sight

## If you want it stronger

Edit `content.js` and increase `BOTTOM_BUFFER_PX` a little, for example from `24` to `40`.
