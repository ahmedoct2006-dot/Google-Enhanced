const STORAGE_KEY = "youtubeThreePanelColors";
const DEFAULT_COLORS = {
  leftColor: "#111111",
  topColor: "#1f1f1f",
  middleColor: "#202020"
};
const STYLE_ID = "yt-three-panel-color-picker-style";

function getStyleElement() {
  let style = document.getElementById(STYLE_ID);

  if (!style) {
    style = document.createElement("style");
    style.id = STYLE_ID;
    document.documentElement.appendChild(style);
  }

  return style;
}

function buildCss(colors) {
  return `
    ytd-app {
      background:
        linear-gradient(
          to right,
          ${colors.leftColor} 0%,
          ${colors.leftColor} 22%,
          ${colors.middleColor} 22%,
          ${colors.middleColor} 78%,
          transparent 78%,
          transparent 100%
        ) !important;
    }

    #masthead-container,
    tp-yt-app-header-layout #masthead {
      background: ${colors.topColor} !important;
    }

    #page-manager,
    ytd-watch-flexy,
    ytd-browse,
    ytd-search,
    ytd-shorts,
    ytd-two-column-browse-results-renderer,
    ytd-rich-grid-renderer {
      background-color: ${colors.middleColor} !important;
    }
  `;
}

function applyColors(colors) {
  const finalColors = {
    ...DEFAULT_COLORS,
    ...colors
  };

  getStyleElement().textContent = buildCss(finalColors);
}

async function loadColors() {
  const stored = await chrome.storage.sync.get(STORAGE_KEY);
  applyColors(stored[STORAGE_KEY] || DEFAULT_COLORS);
}

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "sync" || !changes[STORAGE_KEY]) {
    return;
  }

  applyColors(changes[STORAGE_KEY].newValue || DEFAULT_COLORS);
});

loadColors();
