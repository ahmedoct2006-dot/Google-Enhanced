(() => {
  const STORAGE_KEY = "ytColorPicker.v1";
  const REMOVE_YOUTUBE_HOME_LOGO = true;
  const DEFAULTS = {
    left: "#ffffff",
    top: "#ffffff",
    middle: "#ffffff"
  };

  const UI_IDS = {
    style: "ytcp-style",
    slot: "ytcp-toolbar-slot",
    button: "ytcp-button",
    panel: "ytcp-panel"
  };

  function clampHex(value, fallback) {
    if (typeof value !== "string") return fallback;
    const trimmed = value.trim();
    return /^#[0-9a-fA-F]{6}$/.test(trimmed) ? trimmed : fallback;
  }

  function getStoredColors() {
    return new Promise((resolve) => {
      chrome.storage.sync.get([STORAGE_KEY], (result) => {
        const stored = result?.[STORAGE_KEY] || {};
        resolve({
          left: clampHex(stored.left, DEFAULTS.left),
          top: clampHex(stored.top, DEFAULTS.top),
          middle: clampHex(stored.middle, DEFAULTS.middle)
        });
      });
    });
  }

  function setStoredColors(colors) {
    return new Promise((resolve) => {
      chrome.storage.sync.set({ [STORAGE_KEY]: colors }, () => resolve());
    });
  }

  function ensureStyleEl() {
    let styleEl = document.getElementById(UI_IDS.style);
    if (styleEl) return styleEl;
    styleEl = document.createElement("style");
    styleEl.id = UI_IDS.style;
    document.documentElement.appendChild(styleEl);
    return styleEl;
  }

  function applyColors(colors) {
    const styleEl = ensureStyleEl();
    styleEl.textContent = `
 :root{
   --ytcp-left: ${colors.left};
   --ytcp-top: ${colors.top};
   --ytcp-middle: ${colors.middle};
   --ytcp-start: var(--ytcp-top);
   --ytcp-guide-width: 0px;
 }
 html[data-ytcp-guide-expanded="1"]{
   --ytcp-start: var(--ytcp-left);
 }

 /* Top bar */
 ytd-masthead, ytd-masthead #container, #masthead-container, #masthead {
   background: var(--ytcp-top) !important;
 }

/* Ensure our masthead background is visible */
ytd-masthead #background,
ytd-masthead #container #background,
ytd-masthead #background.ytd-masthead,
ytd-masthead #container.ytd-masthead {
  background: transparent !important;
}

/* Left color reaches the top across the same width as the expanded guide */
ytd-masthead{
  position: relative !important;
}
html[data-ytcp-guide-expanded="1"] ytd-masthead::before{
  content: "";
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: var(--ytcp-guide-width);
  background: var(--ytcp-left) !important;
  pointer-events: none;
  z-index: 0;
}
ytd-masthead #container{
  position: relative !important;
  z-index: 1;
}

/* Never tint the right-side settings/more button (keep YouTube default) */
ytd-masthead #end ytd-topbar-menu-button-renderer,
ytd-masthead #end ytd-topbar-menu-button-renderer #button,
ytd-masthead #end ytd-topbar-menu-button-renderer button{
  background: transparent !important;
  background-color: transparent !important;
}

/* Always color the hamburger button itself */
ytd-masthead #start ytd-topbar-menu-button-renderer,
ytd-masthead #start ytd-topbar-menu-button-renderer #button,
ytd-masthead #start ytd-topbar-menu-button-renderer button,
ytd-masthead #start button#guide-button{
  background: var(--ytcp-left) !important;
  border-radius: 999px !important;
}

/* When the left panel is collapsed, keep the YouTube logo area on Top color,
   but still paint a "block" of Left color behind the hamburger zone only. */
html[data-ytcp-guide-expanded="0"] ytd-masthead #start ytd-topbar-menu-button-renderer{
  position: relative !important;
  isolation: isolate;
}
html[data-ytcp-guide-expanded="0"] ytd-masthead #start ytd-topbar-menu-button-renderer::before{
  content: "";
  position: absolute;
  inset: -10px -10px -10px -10px;
  background: var(--ytcp-left) !important;
  z-index: -1;
  pointer-events: none;
  border-radius: 14px;
}

/* Left navigation */
ytd-app #guide, ytd-guide-renderer, #guide-renderer, ytd-mini-guide-renderer {
  background: var(--ytcp-left) !important;
}

/* Middle content */
html, body, ytd-app, ytd-page-manager, #content.ytd-app, ytd-browse, ytd-search, ytd-watch-flexy {
  background: var(--ytcp-middle) !important;
}

 /* Button */
 #${UI_IDS.slot}{
  display: inline-flex;
  align-items: center;
  margin-left: 12px;
 }
 #${UI_IDS.button}{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  min-width: 40px;
  height: 40px;
  padding: 0 12px;
  border-radius: 20px;
  border: 1px solid rgba(0,0,0,.12);
  background: rgba(255,255,255,.9);
  color: #111;
  cursor: pointer;
  user-select: none;
  font: 600 13px/1 "Segoe UI", Tahoma, sans-serif;
}
 #${UI_IDS.button}:hover{ background: rgba(255,255,255,1); }
 #${UI_IDS.button} .ytcp-swatch{
  width: 14px;
  height: 14px;
  border-radius: 999px;
  background:
    linear-gradient(135deg, var(--ytcp-left) 0 33%, var(--ytcp-top) 33% 66%, var(--ytcp-middle) 66% 100%);
  box-shadow:
    inset 0 0 0 1px rgba(255,255,255,.72),
    0 0 0 1px rgba(0,0,0,.14);
 }

 /* Option: remove the top-left YouTube "home" logo entirely (keeps the hamburger). */
 ytd-masthead ytd-topbar-logo-renderer#logo,
 ytd-topbar-logo-renderer#logo,
 ytd-masthead a#logo,
 a#logo.ytd-topbar-logo-renderer,
 ytd-topbar-logo-renderer#logo #country-code{
   display: none !important;
 }

 ytd-masthead ytd-yoodle-renderer,
 ytd-masthead ytd-yoodle-renderer *,
 ytd-masthead img.style-scope.ytd-yoodle-renderer{
   display: none !important;
   width: 0 !important;
   min-width: 0 !important;
   max-width: 0 !important;
   margin: 0 !important;
   padding: 0 !important;
   overflow: hidden !important;
   visibility: hidden !important;
   opacity: 0 !important;
   pointer-events: none !important;
 }

 /* Remove the left sidebar Home entry (guide + mini-guide). */
 ytd-guide-entry-renderer:has(a#endpoint[href="/"]),
 ytd-guide-entry-renderer:has(a#endpoint[title="Home"]),
 ytd-guide-entry-renderer:has(a#endpoint[aria-label="Home"]),
 ytd-mini-guide-entry-renderer:has(a#endpoint[href="/"]),
 ytd-mini-guide-entry-renderer:has(a#endpoint[title="Home"]),
 ytd-mini-guide-entry-renderer:has(a#endpoint[aria-label="Home"]){
   display: none !important;
 }

/* Panel */
#${UI_IDS.panel}{
  position: fixed;
  top: 64px;
  right: 16px;
  z-index: 999999;
  width: 240px;
  padding: 12px;
  border-radius: 12px;
  border: 1px solid rgba(0,0,0,.12);
  background: rgba(255,255,255,.98);
  box-shadow: 0 10px 30px rgba(0,0,0,.12);
  font: 13px/1.3 system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
  color: #111;
}
#${UI_IDS.panel} header{
  display:flex;
  align-items:center;
  justify-content: space-between;
  margin-bottom: 10px;
}
#${UI_IDS.panel} header strong{ font-size: 13px; }
#${UI_IDS.panel} button{
  border: 1px solid rgba(0,0,0,.14);
  background: #fff;
  border-radius: 10px;
  padding: 6px 10px;
  cursor: pointer;
}
#${UI_IDS.panel} button:hover{ background: #f4f4f4; }
#${UI_IDS.panel} .row{
  display:flex;
  align-items:center;
  justify-content: space-between;
  padding: 6px 0;
}
#${UI_IDS.panel} .row label{
  display:flex;
  gap: 8px;
  align-items:center;
}
#${UI_IDS.panel} input[type="color"]{
  width: 46px;
  height: 30px;
  border: none;
  background: transparent;
  padding: 0;
  cursor: pointer;
}
`;
  }

  function createButton() {
    const btn = document.createElement("button");
    btn.id = UI_IDS.button;
    btn.type = "button";
    btn.title = "Pick left, top, and middle colors";
    btn.setAttribute("aria-label", "Pick left, top, and middle colors");
    btn.innerHTML = `
      <span class="ytcp-swatch" aria-hidden="true"></span>
      <span>Color</span>
    `;
    btn.addEventListener("click", () => togglePanel());
    return btn;
  }

  function closePanel() {
    const panel = document.getElementById(UI_IDS.panel);
    if (panel) panel.remove();
  }

  async function togglePanel() {
    const existing = document.getElementById(UI_IDS.panel);
    if (existing) {
      existing.remove();
      return;
    }

    const colors = await getStoredColors();

    const panel = document.createElement("div");
    panel.id = UI_IDS.panel;
    panel.innerHTML = `
      <header>
        <strong>Page colors</strong>
        <div style="display:flex; gap:8px;">
          <button id="ytcp-reset" type="button" title="Reset to white">Reset</button>
          <button id="ytcp-close" type="button" title="Close">Close</button>
        </div>
      </header>

      <div class="row">
        <label><span>Left</span></label>
        <input id="ytcp-left" type="color" value="${colors.left}" />
      </div>
      <div class="row">
        <label><span>Top</span></label>
        <input id="ytcp-top" type="color" value="${colors.top}" />
      </div>
      <div class="row">
        <label><span>Middle</span></label>
        <input id="ytcp-middle" type="color" value="${colors.middle}" />
      </div>
    `;

    const stop = (e) => e.stopPropagation();
    panel.addEventListener("click", stop);
    document.addEventListener(
      "click",
      () => {
        closePanel();
      },
      { once: true, capture: true }
    );

    document.body.appendChild(panel);

    panel.querySelector("#ytcp-close")?.addEventListener("click", () => closePanel());

    panel.querySelector("#ytcp-reset")?.addEventListener("click", async () => {
      applyColors(DEFAULTS);
      await setStoredColors(DEFAULTS);
      const left = panel.querySelector("#ytcp-left");
      const top = panel.querySelector("#ytcp-top");
      const middle = panel.querySelector("#ytcp-middle");
      if (left) left.value = DEFAULTS.left;
      if (top) top.value = DEFAULTS.top;
      if (middle) middle.value = DEFAULTS.middle;
    });

    const onPick = async () => {
      const next = {
        left: clampHex(panel.querySelector("#ytcp-left")?.value, DEFAULTS.left),
        top: clampHex(panel.querySelector("#ytcp-top")?.value, DEFAULTS.top),
        middle: clampHex(panel.querySelector("#ytcp-middle")?.value, DEFAULTS.middle)
      };
      applyColors(next);
      await setStoredColors(next);
    };

    panel.querySelector("#ytcp-left")?.addEventListener("input", onPick);
    panel.querySelector("#ytcp-top")?.addEventListener("input", onPick);
    panel.querySelector("#ytcp-middle")?.addEventListener("input", onPick);
  }

  function getVoiceSearchAnchor() {
    return (
      document.querySelector("ytd-masthead #voice-search-button") ||
      document.querySelector("#voice-search-button") ||
      document.querySelector("ytd-masthead ytd-voice-search-button-renderer") ||
      document.querySelector("ytd-voice-search-button-renderer")
    );
  }

  function getToolbarFallbackHost() {
    return (
      document.querySelector("ytd-masthead #end") ||
      document.querySelector("#end") ||
      document.querySelector("ytd-masthead #buttons") ||
      document.querySelector("ytd-masthead #center") ||
      document.querySelector("ytd-masthead")
    );
  }

  function ensureUi() {
    let slot = document.getElementById(UI_IDS.slot);
    if (!slot) {
      slot = document.createElement("div");
      slot.id = UI_IDS.slot;
      slot.appendChild(createButton());
    }

    const anchor = getVoiceSearchAnchor();
    if (anchor instanceof Element) {
      if (anchor.nextElementSibling !== slot) {
        anchor.insertAdjacentElement("afterend", slot);
      }
      return;
    }

    const fallbackHost = getToolbarFallbackHost();
    if (fallbackHost instanceof Element && !fallbackHost.contains(slot)) {
      fallbackHost.appendChild(slot);
    }
  }

  function hideMastheadLogoHard() {
    if (!REMOVE_YOUTUBE_HOME_LOGO) {
      return;
    }

    const selectors = [
      "ytd-masthead ytd-topbar-logo-renderer#logo",
      "ytd-topbar-logo-renderer#logo",
      "ytd-topbar-logo-renderer#logo a#logo",
      "ytd-masthead a#logo",
      "a#logo.ytd-topbar-logo-renderer",
      "ytd-topbar-logo-renderer#logo #country-code",
      "span#country-code"
    ].join(", ");

    const visitedRoots = new Set();
    const roots = [document];

    const addShadowRootsFrom = (node) => {
      if (!(node instanceof Element)) {
        return;
      }

      const shadow = node.shadowRoot;
      if (shadow && !visitedRoots.has(shadow)) {
        visitedRoots.add(shadow);
        roots.push(shadow);

        const queue = [];
        shadow.querySelectorAll("*").forEach((el) => {
          if (el instanceof Element && el.shadowRoot) {
            queue.push(el.shadowRoot);
          }
        });

        while (queue.length && visitedRoots.size < 60) {
          const root = queue.shift();
          if (!root || visitedRoots.has(root)) {
            continue;
          }
          visitedRoots.add(root);
          roots.push(root);
          root.querySelectorAll("*").forEach((el) => {
            if (el instanceof Element && el.shadowRoot && !visitedRoots.has(el.shadowRoot)) {
              queue.push(el.shadowRoot);
            }
          });
        }
      }
    };

    addShadowRootsFrom(document.querySelector("ytd-masthead"));
    addShadowRootsFrom(document.querySelector("#masthead"));
    addShadowRootsFrom(document.querySelector("#masthead-container"));

    for (const root of roots) {
      if (!root) continue;
      root.querySelectorAll(selectors).forEach((candidate) => {
        if (!(candidate instanceof HTMLElement)) return;
        if (candidate.closest("ytd-guide-renderer, ytd-mini-guide-renderer, ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer")) {
          return;
        }
        candidate.style.setProperty("display", "none", "important");
        candidate.setAttribute("data-ytcp-logo-hidden", "1");
      });
    }
  }

  function hideLeftHomeEntryHard() {
    const selectors = [
      "ytd-guide-entry-renderer a#endpoint[href=\"/\"]",
      "ytd-guide-entry-renderer a#endpoint[title=\"Home\"]",
      "ytd-guide-entry-renderer a#endpoint[aria-label=\"Home\"]",
      "ytd-mini-guide-entry-renderer a#endpoint[href=\"/\"]",
      "ytd-mini-guide-entry-renderer a#endpoint[title=\"Home\"]",
      "ytd-mini-guide-entry-renderer a#endpoint[aria-label=\"Home\"]"
    ].join(", ");

    document.querySelectorAll(selectors).forEach((endpoint) => {
      if (!(endpoint instanceof HTMLElement)) return;
      const entry = endpoint.closest("ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer");
      if (!(entry instanceof HTMLElement)) return;
      entry.style.setProperty("display", "none", "important");
      entry.setAttribute("data-ytcp-home-hidden", "1");
    });
  }

  function removeYoodleHard() {
    document.querySelectorAll("ytd-masthead ytd-yoodle-renderer, ytd-yoodle-renderer").forEach((node) => {
      if (node instanceof HTMLElement) {
        node.remove();
      }
    });

    document.querySelectorAll('ytd-masthead img.style-scope.ytd-yoodle-renderer, img.style-scope.ytd-yoodle-renderer').forEach((node) => {
      if (node instanceof HTMLElement) {
        node.remove();
      }
    });
  }

  async function init() {
    // Apply saved colors ASAP.
    applyColors(await getStoredColors());

    function isElementVisible(el) {
      return !!(el && (el.offsetParent || el.getClientRects().length));
    }

    function isMiniGuideVisible() {
      const mini = document.querySelector("ytd-mini-guide-renderer");
      if (!mini) return false;
      if (!isElementVisible(mini)) return false;
      const rect = mini.getBoundingClientRect();
      return rect.width > 40 && rect.height > 40;
    }

    function isGuideExpanded() {
      // If mini guide is showing, treat as collapsed.
      if (isMiniGuideVisible()) return false;

      const app = document.querySelector("ytd-app");
      if (app?.hasAttribute("guide-persistent-and-visible")) return true;

      const guide = document.querySelector("ytd-app #guide");
      if (!isElementVisible(guide)) return false;
      const width = guide.getBoundingClientRect().width;
      return width >= 180;
    }

    let lastGuideExpanded = null;
    let lastGuideWidth = null;

    function updateGuideWidth() {
      // Only extend Left color into the top when the full guide is expanded.
      if (!isGuideExpanded()) {
        if (lastGuideWidth === 0) return;
        lastGuideWidth = 0;
        document.documentElement.style.setProperty("--ytcp-guide-width", "0px");
        return;
      }

      const guide = document.querySelector("ytd-app #guide");
      if (!isElementVisible(guide)) return;

      // Cap width so it never reaches the right-side buttons (e.g., settings).
      const raw = Math.ceil(guide.getBoundingClientRect().width);
      const width = Math.min(320, Math.max(180, raw));
      if (width === lastGuideWidth) return;
      lastGuideWidth = width;
      document.documentElement.style.setProperty("--ytcp-guide-width", `${width}px`);
    }

    function updateGuideState() {
      const expanded = isGuideExpanded();
      if (expanded === lastGuideExpanded) return;
      lastGuideExpanded = expanded;
      document.documentElement.setAttribute("data-ytcp-guide-expanded", expanded ? "1" : "0");
    }

    // YouTube is a SPA; keep ensuring UI exists.
    ensureUi();
    removeYoodleHard();
    hideMastheadLogoHard();
    hideLeftHomeEntryHard();
    updateGuideState();
    updateGuideWidth();
    const observer = new MutationObserver(() => {
      ensureUi();
      removeYoodleHard();
      hideMastheadLogoHard();
      hideLeftHomeEntryHard();
      updateGuideState();
      updateGuideWidth();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    window.addEventListener(
      "resize",
      () => {
        updateGuideState();
        updateGuideWidth();
      },
      { passive: true }
    );

    // Update colors if they change from another tab.
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      if (!changes[STORAGE_KEY]) return;
      const next = changes[STORAGE_KEY].newValue || DEFAULTS;
      applyColors({
        left: clampHex(next.left, DEFAULTS.left),
        top: clampHex(next.top, DEFAULTS.top),
        middle: clampHex(next.middle, DEFAULTS.middle)
      });
    });
  }

  init().catch(() => {
    // If YouTube changes structure, the extension should fail silently rather than break the page.
  });
})();
