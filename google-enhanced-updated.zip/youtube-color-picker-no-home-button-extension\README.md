# YouTube Color Picker Button (No Home Button)

This is a separate Chrome extension folder that adds a `Color` button beside YouTube's mic button.

Click the button to open a frame where you can choose separate colors for:

- left side
- top side
- middle side

## Install

1. Open `chrome://extensions`
2. Turn on `Developer mode`
3. Click `Load unpacked`
4. Select the `youtube-color-picker-no-home-button-extension` folder

## Notes

- Colors are saved with `chrome.storage.local`.
- Right-click the `Color` button to reset all colors.
- The top-left YouTube logo (home button) is hidden.
- The left sidebar `Home` entry is hidden.
- This folder is separate from `youtube-background-color-extension`.
