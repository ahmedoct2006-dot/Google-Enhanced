const YTBC_PROXY_SELECTOR = ".ytwAdButtonGroupViewModelHostPrimaryButton, ad-button-view-model";
const YTBC_CTA_LABELS = new Set([
  "visit site",
  "sign up",
  "play now",
  "book now",
  "watch",
  "watch now",
  "learn more",
  "shop now",
  "install",
  "download",
  "get offer"
]);

function getNormalizedText(value) {
  return typeof value === "string" ? value.replace(/\s+/g, " ").trim().toLowerCase() : "";
}

function getCtaLabel(element) {
  if (!(element instanceof HTMLElement)) {
    return "";
  }

  return (
    element.getAttribute("aria-label")?.trim() ||
    element.getAttribute("title")?.trim() ||
    element.textContent?.replace(/\s+/g, " ").trim() ||
    ""
  );
}

function isTargetCta(element, host) {
  if (!(element instanceof HTMLElement)) {
    return false;
  }

  const aria = getNormalizedText(element.getAttribute("aria-label"));
  const title = getNormalizedText(element.getAttribute("title"));
  const text = getNormalizedText(element.textContent);
  if (YTBC_CTA_LABELS.has(aria) || YTBC_CTA_LABELS.has(title) || YTBC_CTA_LABELS.has(text)) {
    return true;
  }

  return Boolean(
    host?.closest("[data-ytbc-sponsored-card='true']") ||
    host?.matches(".ytwAdButtonGroupViewModelHostPrimaryButton, ad-button-view-model") ||
    host?.querySelector(".yt-spec-button-shape-next--filled, .yt-spec-button-shape-next--mono")
  );
}

function findTargetCtaElement(host) {
  if (!(host instanceof HTMLElement)) {
    return null;
  }

  const candidates = [
    host,
    ...host.querySelectorAll("a, button, [role='button'], .yt-spec-button-shape-next")
  ];

  return candidates.find((candidate) => (
    candidate instanceof HTMLElement &&
    isTargetCta(candidate, host) &&
    getCtaLabel(candidate)
  )) || null;
}

function ensureProxyButton(host) {
  if (!(host instanceof HTMLElement)) {
    return;
  }

  const target = findTargetCtaElement(host);
  if (!(target instanceof HTMLElement)) {
    return;
  }

  const anchor = target instanceof HTMLAnchorElement ? target : target.closest("a[href]");
  const label = getCtaLabel(target) || "Watch";

  host.setAttribute("data-ytbc-proxy-host", "true");
  target.setAttribute("data-ytbc-original-cta", "true");
  target.style.setProperty("display", "none", "important");
  host.querySelectorAll("ad-button-view-model").forEach((node) => {
    if (node !== host) {
      node.style.setProperty("display", "none", "important");
    }
  });

  let proxy = host.querySelector(".ytbc-cta-proxy");
  if (!(proxy instanceof HTMLAnchorElement)) {
    proxy = document.createElement("a");
    proxy.className = "ytbc-cta-proxy";
    proxy.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      target.click();
    });
    host.appendChild(proxy);
  }

  proxy.textContent = label;
  proxy.setAttribute("aria-label", label);
  proxy.setAttribute("role", "button");
  proxy.href = anchor?.href || "#";
  proxy.target = anchor?.target || "_self";
  proxy.rel = anchor?.rel || "nofollow";
}

function applyCtaProxyFix() {
  document.querySelectorAll(YTBC_PROXY_SELECTOR).forEach((host) => {
    ensureProxyButton(host);
  });
}

const observer = new MutationObserver(() => {
  applyCtaProxyFix();
});

applyCtaProxyFix();
observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});
