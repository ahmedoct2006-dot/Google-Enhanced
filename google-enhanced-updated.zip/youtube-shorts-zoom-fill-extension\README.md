# YouTube Shorts Seam Fix

This Chrome extension slightly enlarges the active YouTube Short only when the Chrome tab is at `100%` zoom, so thin seam lines are hidden.

It only runs on `/shorts/...` pages and only applies a small overscan at `100%` zoom instead of a heavy crop.

## Load it in Chrome

1. Open `chrome://extensions`
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Select the `youtube-shorts-zoom-fill-extension` folder

## Notes

- It only activates on YouTube Shorts pages.
- The `100%` zoom fix uses a small scale increase (`1.018`) and a tiny upward shift.
- If you want a stronger or weaker fix, edit `styles.css` and change `--yt-shorts-seam-fix-scale` inside the `yt-shorts-seam-fix--zoom-100` block.
