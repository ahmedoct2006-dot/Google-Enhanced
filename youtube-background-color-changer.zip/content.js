﻿(() => {
  const STORAGE_KEY = 'ytBackgroundColorChanger';
  const DEFAULTS = {
    top: '#ffffff',
    left: '#ffffff',
    middle: '#ffffff'
  };
  const SECTION_BUTTONS = [
    { key: 'left', label: 'Left side' },
    { key: 'top', label: 'Top side' },
    { key: 'middle', label: 'Middle side' }
  ];
  const COLOR_SWATCHES = [
    '#ffffff',
    '#e8dcc9',
    '#ead7cf',
    '#e9c9d1',
    '#e2c1aa',
    '#d8d1ae',
    '#ccd9b5',
    '#bddac8',
    '#b8d9d7',
    '#b7d4df',
    '#b6c8de',
    '#c1c4e1',
    '#c8b6dc',
    '#d1a9d6',
    '#df9ac0',
    '#cc8d88',
    '#d98b62',
    '#c7b06d',
    '#8ecdbd',
    '#76c6de',
    '#699fda',
    '#6489d5',
    '#6d79c7',
    '#8570b9',
    '#806091',
    '#6d4a63',
    '#576a44',
    '#4c5864',
    '#35373d',
    '#121317'
  ];

  let currentColors = { ...DEFAULTS };
  let styleTag;
  let observerStarted = false;
  let observer;
  let ensureButtonScheduled = false;
  let activeSection = 'left';

  function getMicSvgMarkup(id = '') {
    const svgId = id ? ` id="${id}"` : '';
    return `
      <svg${svgId} viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12 3C10.34 3 9 4.34 9 6V11C9 12.66 10.34 14 12 14C13.66 14 15 12.66 15 11V6C15 4.34 13.66 3 12 3Z"></path>
        <path d="M7 11H8.5C8.5 12.93 10.07 14.5 12 14.5C13.93 14.5 15.5 12.93 15.5 11H17C17 13.39 15.25 15.37 13 15.73V19H16V21H8V19H11V15.73C8.75 15.37 7 13.39 7 11Z"></path>
      </svg>
    `;
  }

  function getYoutubeOutlineSvgMarkup(color) {
    return `
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <rect x="3.5" y="6.5" width="17" height="11" rx="3.5" fill="none" stroke="${color}" stroke-width="1.8"></rect>
        <path d="M10 9.25L15 12L10 14.75V9.25Z" fill="none" stroke="${color}" stroke-width="1.8" stroke-linejoin="round"></path>
      </svg>
    `;
  }

  function hexToRgb(hex) {
    const normalized = hex.replace('#', '');
    const full = normalized.length === 3
      ? normalized.split('').map((char) => char + char).join('')
      : normalized;

    const value = parseInt(full, 16);
    return {
      r: (value >> 16) & 255,
      g: (value >> 8) & 255,
      b: value & 255
    };
  }

  function isLightColor(hex) {
    const { r, g, b } = hexToRgb(hex);
    const luminance = (0.299 * r) + (0.587 * g) + (0.114 * b);
    return luminance >= 200;
  }

  function toLinearChannel(value) {
    const normalized = value / 255;
    if (normalized <= 0.03928) {
      return normalized / 12.92;
    }

    return ((normalized + 0.055) / 1.055) ** 2.4;
  }

  function getRelativeLuminance(hex) {
    const { r, g, b } = hexToRgb(hex);
    const red = toLinearChannel(r);
    const green = toLinearChannel(g);
    const blue = toLinearChannel(b);
    return (0.2126 * red) + (0.7152 * green) + (0.0722 * blue);
  }

  function getContrastRatio(luminanceA, luminanceB) {
    const lighter = Math.max(luminanceA, luminanceB);
    const darker = Math.min(luminanceA, luminanceB);
    return (lighter + 0.05) / (darker + 0.05);
  }

  function getSectionTextColor(hex) {
    const backgroundLuminance = getRelativeLuminance(hex);
    const contrastWithBlack = getContrastRatio(backgroundLuminance, 0);
    const contrastWithWhite = getContrastRatio(backgroundLuminance, 1);
    return contrastWithBlack >= contrastWithWhite ? '#0f0f0f' : '#ffffff';
  }

  function ensureStyleTag() {
    if (styleTag && document.contains(styleTag)) {
      return styleTag;
    }

    styleTag = document.createElement('style');
    styleTag.id = 'yt-background-color-changer-style';
    document.documentElement.appendChild(styleTag);
    return styleTag;
  }

  function buildCss(colors) {
    const topTextColor = getSectionTextColor(colors.top);
    const useLightChipTheme = topTextColor === '#0f0f0f';
    const leftTextColor = getSectionTextColor(colors.left);
    const middleTextColor = getSectionTextColor(colors.middle);
    const guideSignInTextColor = leftTextColor === '#0f0f0f'
      ? '#0f0f0f'
      : '#ffffff';
    const mastheadSignInTextColor = middleTextColor === '#0f0f0f'
      ? '#0f0f0f'
      : '#ffffff';
    const chipBackground = useLightChipTheme ? '#f2f2f2' : 'rgba(255, 255, 255, 0.08)';
    const chipHoverBackground = useLightChipTheme ? '#e5e5e5' : 'rgba(255, 255, 255, 0.12)';
    const chipSelectedBackground = useLightChipTheme ? '#e0e0e0' : 'rgba(255, 255, 255, 0.08)';
    const chipTextColor = useLightChipTheme ? '#0f0f0f' : '#ffffff';
    const chipSelectedTextColor = useLightChipTheme ? '#0f0f0f' : '#ffffff';

    return `
      :root {
        --ytbcc-top: ${colors.top};
        --ytbcc-left: ${colors.left};
        --ytbcc-middle: ${colors.middle};
        --ytbcc-left-width-wide: 240px;
        --ytbcc-left-width-compact: 72px;
        --ytbcc-top-text: ${topTextColor};
        --ytbcc-left-text: ${leftTextColor};
        --ytbcc-middle-text: ${middleTextColor};
        --ytbcc-middle-card-border: ${middleTextColor};
        --ytbcc-guide-signin-text: ${guideSignInTextColor};
        --ytbcc-masthead-signin-text: ${mastheadSignInTextColor};
        --ytbcc-chip-background: ${chipBackground};
        --ytbcc-chip-background-hover: ${chipHoverBackground};
        --ytbcc-chip-background-selected: ${chipSelectedBackground};
        --ytbcc-chip-text: ${chipTextColor};
        --ytbcc-chip-text-selected: ${chipSelectedTextColor};
      }

      ytd-masthead,
      #masthead-container,
      tp-yt-app-header-layout #masthead-container,
      #container.ytd-masthead,
      ytd-feed-filter-chip-bar-renderer,
      #chips-wrapper.ytd-feed-filter-chip-bar-renderer,
      #chips.ytd-feed-filter-chip-bar-renderer,
      yt-chip-cloud-renderer {
        background: var(--ytbcc-top) !important;
        --yt-spec-chip-background: var(--ytbcc-chip-background) !important;
        --yt-spec-chip-background-hover: var(--ytbcc-chip-background-hover) !important;
        --yt-spec-chip-background-selected: var(--ytbcc-chip-background-selected) !important;
        --yt-spec-text-primary: var(--ytbcc-chip-text) !important;
        --yt-spec-text-primary-inverse: var(--ytbcc-chip-text-selected) !important;
      }

      ytd-app[guide-persistent-and-visible] ytd-masthead,
      ytd-app[guide-persistent-and-visible] #masthead-container,
      ytd-app[guide-persistent-and-visible] tp-yt-app-header-layout #masthead-container,
      ytd-app[guide-persistent-and-visible] #container.ytd-masthead {
        background: linear-gradient(to right, var(--ytbcc-left) 0 var(--ytbcc-left-width-wide), var(--ytbcc-top) var(--ytbcc-left-width-wide) 100%) !important;
      }

      ytd-app:not([guide-persistent-and-visible]) ytd-masthead,
      ytd-app:not([guide-persistent-and-visible]) #masthead-container,
      ytd-app:not([guide-persistent-and-visible]) tp-yt-app-header-layout #masthead-container,
      ytd-app:not([guide-persistent-and-visible]) #container.ytd-masthead {
        background: linear-gradient(to right, var(--ytbcc-left) 0 var(--ytbcc-left-width-compact), var(--ytbcc-top) var(--ytbcc-left-width-compact) 100%) !important;
      }

      ytd-app:not([guide-persistent-and-visible]) ytd-topbar-logo-renderer,
      ytd-app:not([guide-persistent-and-visible]) #logo.ytd-masthead {
        margin-left: 22px !important;
      }

      ytd-topbar-logo-renderer #text.ytd-topbar-logo-renderer,
      ytd-topbar-logo-renderer #country-code,
      ytd-topbar-logo-renderer #logo-icon {
        display: none !important;
      }

      ytd-topbar-logo-renderer a#logo > :not(#ytbcc-brand) {
        display: none !important;
      }

      #ytbcc-brand {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
      }

      #ytbcc-brand-logo {
        width: 28px;
        height: 20px;
        display: block;
      }

      #ytbcc-brand-text {
        display: inline-flex;
        align-items: flex-start;
        font-family: Arial, sans-serif;
        font-size: 24px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.5px;
      }

      #ytbcc-brand-country {
        font-size: 10px;
        line-height: 1;
        margin-left: 2px;
        margin-top: -1px;
      }

      #ytbcc-mic-icon {
        width: 48px;
        height: 48px;
        display: block !important;
        transform: translateY(-2px);
      }

      ytd-searchbox #voice-search-button button svg,
      ytd-searchbox #voice-search-button yt-icon,
      ytd-searchbox #voice-search-button #icon,
      #voice-search-button button svg,
      #voice-search-button yt-icon,
      #voice-search-button #icon,
      ytd-button-renderer[button-renderer-style='STYLE_DEFAULT'] button svg,
      ytd-button-renderer[button-renderer-style='STYLE_DEFAULT'] yt-icon {
        display: none !important;
      }

      ytd-searchbox #voice-search-button button,
      #voice-search-button button,
      ytd-button-renderer[button-renderer-style='STYLE_DEFAULT'] button {
        width: 78px !important;
        height: 78px !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        background: transparent !important;
        box-shadow: none !important;
        border: none !important;
        border-radius: 999px !important;
        padding: 0 !important;
        transform: translateY(-4px) !important;
      }

      ytd-searchbox #voice-search-button button[data-ytbcc-mic-button='true'] #ytbcc-mic-icon path,
      #voice-search-button button[data-ytbcc-mic-button='true'] #ytbcc-mic-icon path,
      ytd-button-renderer[button-renderer-style='STYLE_DEFAULT'] button[data-ytbcc-mic-button='true'] #ytbcc-mic-icon path {
        fill: var(--ytbcc-top-text) !important;
      }

      ytd-searchbox #voice-search-button button[data-ytbcc-mic-button='true'] #ytbcc-mic-icon,
      #voice-search-button button[data-ytbcc-mic-button='true'] #ytbcc-mic-icon,
      ytd-button-renderer[button-renderer-style='STYLE_DEFAULT'] button[data-ytbcc-mic-button='true'] #ytbcc-mic-icon {
        display: block !important;
      }

      ytd-searchbox #voice-search-button,
      #voice-search-button,
      ytd-button-renderer[button-renderer-style='STYLE_DEFAULT'] {
        background: transparent !important;
        box-shadow: none !important;
      }

      ytd-app[guide-persistent-and-visible] #ytbcc-brand-text,
      ytd-app[guide-persistent-and-visible] #ytbcc-brand-country {
        color: var(--ytbcc-left-text) !important;
      }

      ytd-app:not([guide-persistent-and-visible]) #ytbcc-brand-text,
      ytd-app:not([guide-persistent-and-visible]) #ytbcc-brand-country {
        color: var(--ytbcc-top-text) !important;
      }

      ytd-masthead,
      ytd-masthead a,
      ytd-masthead yt-formatted-string,
      ytd-masthead #text,
      ytd-masthead tp-yt-paper-icon-button,
      ytd-masthead yt-icon,
      ytd-masthead svg,
      ytd-masthead button,
      ytd-feed-filter-chip-bar-renderer,
      ytd-feed-filter-chip-bar-renderer yt-formatted-string,
      ytd-feed-filter-chip-bar-renderer #text,
      ytd-feed-filter-chip-bar-renderer yt-icon,
      yt-chip-cloud-renderer,
      yt-chip-cloud-renderer yt-icon {
        color: var(--ytbcc-top-text) !important;
        fill: var(--ytbcc-top-text) !important;
      }

      ytd-masthead a[aria-label*='sign in' i],
      ytd-masthead button[aria-label*='sign in' i],
      ytd-masthead a[aria-label*='sign in' i] *,
      ytd-masthead button[aria-label*='sign in' i] *,
      ytd-masthead a[href*='signin' i],
      ytd-masthead a[href*='signin' i] * {
        color: var(--ytbcc-masthead-signin-text) !important;
        fill: var(--ytbcc-masthead-signin-text) !important;
        border-color: var(--ytbcc-masthead-signin-text) !important;
        stroke: var(--ytbcc-masthead-signin-text) !important;
        -webkit-text-fill-color: var(--ytbcc-masthead-signin-text) !important;
        --yt-spec-call-to-action: var(--ytbcc-masthead-signin-text) !important;
        --yt-spec-text-primary: var(--ytbcc-masthead-signin-text) !important;
        --yt-spec-text-secondary: var(--ytbcc-masthead-signin-text) !important;
      }

      ytd-guide-renderer a[aria-label*='sign in' i],
      ytd-guide-renderer button[aria-label*='sign in' i],
      ytd-guide-renderer a[aria-label*='sign in' i] *,
      ytd-guide-renderer button[aria-label*='sign in' i] *,
      ytd-guide-renderer a[href*='signin' i],
      ytd-guide-renderer a[href*='signin' i] *,
      ytd-mini-guide-renderer a[aria-label*='sign in' i],
      ytd-mini-guide-renderer button[aria-label*='sign in' i],
      ytd-mini-guide-renderer a[aria-label*='sign in' i] *,
      ytd-mini-guide-renderer button[aria-label*='sign in' i] *,
      ytd-mini-guide-renderer a[href*='signin' i],
      ytd-mini-guide-renderer a[href*='signin' i] * {
        color: var(--ytbcc-guide-signin-text) !important;
        fill: var(--ytbcc-guide-signin-text) !important;
        border-color: var(--ytbcc-guide-signin-text) !important;
        stroke: var(--ytbcc-guide-signin-text) !important;
        -webkit-text-fill-color: var(--ytbcc-guide-signin-text) !important;
        --yt-spec-call-to-action: var(--ytbcc-guide-signin-text) !important;
        --yt-spec-text-primary: var(--ytbcc-guide-signin-text) !important;
        --yt-spec-text-secondary: var(--ytbcc-guide-signin-text) !important;
      }

      ytd-masthead ytd-button-renderer a[href*='signin' i],
      ytd-masthead ytd-button-renderer a[href*='signin' i] *,
      ytd-masthead ytd-button-renderer button[aria-label*='sign in' i],
      ytd-masthead ytd-button-renderer button[aria-label*='sign in' i] *,
      ytd-masthead tp-yt-paper-button[aria-label*='sign in' i],
      ytd-masthead tp-yt-paper-button[aria-label*='sign in' i] *,
      ytd-masthead .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content,
      ytd-masthead .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content *,
      ytd-masthead .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string,
      ytd-masthead a[href*='signin' i] .yt-spec-button-shape-next__button-text-content,
      ytd-masthead a[href*='signin' i] .yt-spec-button-shape-next__button-text-content *,
      ytd-masthead a[href*='signin' i] .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string,
      ytd-masthead .yt-spec-button-shape-next[aria-label*='sign in' i],
      ytd-masthead .yt-spec-button-shape-next[aria-label*='sign in' i] * {
        color: var(--ytbcc-masthead-signin-text) !important;
        fill: var(--ytbcc-masthead-signin-text) !important;
        stroke: var(--ytbcc-masthead-signin-text) !important;
        border-color: var(--ytbcc-masthead-signin-text) !important;
        -webkit-text-fill-color: var(--ytbcc-masthead-signin-text) !important;
        --yt-spec-call-to-action: var(--ytbcc-masthead-signin-text) !important;
        --yt-spec-text-primary: var(--ytbcc-masthead-signin-text) !important;
        --yt-spec-text-secondary: var(--ytbcc-masthead-signin-text) !important;
      }

      ytd-guide-renderer ytd-button-renderer a[href*='signin' i],
      ytd-guide-renderer ytd-button-renderer a[href*='signin' i] *,
      ytd-guide-renderer ytd-button-renderer button[aria-label*='sign in' i],
      ytd-guide-renderer ytd-button-renderer button[aria-label*='sign in' i] *,
      ytd-guide-renderer tp-yt-paper-button[href*='signin' i],
      ytd-guide-renderer tp-yt-paper-button[href*='signin' i] *,
      ytd-guide-renderer tp-yt-paper-button[aria-label*='sign in' i],
      ytd-guide-renderer tp-yt-paper-button[aria-label*='sign in' i] *,
      ytd-guide-renderer .yt-spec-button-shape-next[href*='signin' i],
      ytd-guide-renderer .yt-spec-button-shape-next[href*='signin' i] *,
      ytd-guide-renderer .yt-spec-button-shape-next[href*='signin' i] .yt-spec-button-shape-next__button-text-content,
      ytd-guide-renderer .yt-spec-button-shape-next[href*='signin' i] .yt-spec-button-shape-next__button-text-content *,
      ytd-guide-renderer .yt-spec-button-shape-next[href*='signin' i] .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string,
      ytd-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i],
      ytd-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i] *,
      ytd-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content,
      ytd-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content *,
      ytd-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string,
      ytd-mini-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i],
      ytd-mini-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i] *,
      ytd-mini-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content,
      ytd-mini-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content *,
      ytd-mini-guide-renderer .yt-spec-button-shape-next[aria-label*='sign in' i] .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string,
      ytd-mini-guide-renderer a[href*='signin' i] .yt-spec-button-shape-next__button-text-content,
      ytd-mini-guide-renderer a[href*='signin' i] .yt-spec-button-shape-next__button-text-content *,
      ytd-mini-guide-renderer a[href*='signin' i] .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string {
        color: var(--ytbcc-guide-signin-text) !important;
        fill: var(--ytbcc-guide-signin-text) !important;
        stroke: var(--ytbcc-guide-signin-text) !important;
        border-color: var(--ytbcc-guide-signin-text) !important;
        -webkit-text-fill-color: var(--ytbcc-guide-signin-text) !important;
        --yt-spec-call-to-action: var(--ytbcc-guide-signin-text) !important;
        --yt-spec-text-primary: var(--ytbcc-guide-signin-text) !important;
        --yt-spec-text-secondary: var(--ytbcc-guide-signin-text) !important;
      }

      ytd-masthead a[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__fill,
      ytd-masthead button[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__fill,
      ytd-masthead a[href*='signin' i] .yt-spec-touch-feedback-shape__fill,
      ytd-guide-renderer a[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__fill,
      ytd-guide-renderer button[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__fill,
      ytd-guide-renderer a[href*='signin' i] .yt-spec-touch-feedback-shape__fill,
      ytd-mini-guide-renderer a[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__fill,
      ytd-mini-guide-renderer button[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__fill,
      ytd-mini-guide-renderer a[href*='signin' i] .yt-spec-touch-feedback-shape__fill {
        background-color: color-mix(in srgb, var(--ytbcc-guide-signin-text) 14%, transparent) !important;
      }

      ytd-masthead a[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__fill,
      ytd-masthead button[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__fill,
      ytd-masthead a[href*='signin' i] .yt-spec-touch-feedback-shape__fill {
        background-color: color-mix(in srgb, var(--ytbcc-masthead-signin-text) 14%, transparent) !important;
      }

      ytd-masthead a[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-masthead button[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-masthead a[href*='signin' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-guide-renderer a[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-guide-renderer button[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-guide-renderer a[href*='signin' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-mini-guide-renderer a[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-mini-guide-renderer button[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-mini-guide-renderer a[href*='signin' i] .yt-spec-touch-feedback-shape__stroke {
        border-color: color-mix(in srgb, var(--ytbcc-guide-signin-text) 22%, transparent) !important;
      }

      ytd-masthead a[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-masthead button[aria-label*='sign in' i] .yt-spec-touch-feedback-shape__stroke,
      ytd-masthead a[href*='signin' i] .yt-spec-touch-feedback-shape__stroke {
        border-color: color-mix(in srgb, var(--ytbcc-masthead-signin-text) 22%, transparent) !important;
      }

      ytd-guide-renderer,
      ytd-guide-renderer a,
      ytd-guide-renderer yt-formatted-string,
      ytd-guide-renderer #text,
      ytd-guide-renderer yt-icon,
      ytd-guide-renderer tp-yt-paper-item,
      ytd-mini-guide-renderer,
      ytd-mini-guide-renderer a,
      ytd-mini-guide-renderer yt-formatted-string,
      ytd-mini-guide-renderer #text,
      ytd-mini-guide-renderer yt-icon,
      ytd-guide-section-renderer,
      ytd-guide-entry-renderer,
      ytd-guide-entry-renderer a,
      ytd-guide-entry-renderer yt-formatted-string,
      ytd-guide-entry-renderer #text,
      ytd-guide-entry-renderer yt-icon,
      ytd-guide-collapsible-section-entry-renderer,
      ytd-guide-collapsible-section-entry-renderer yt-formatted-string,
      ytd-guide-collapsible-section-entry-renderer #text,
      #guide-button,
      #guide-button yt-icon,
      #guide-button svg {
        color: var(--ytbcc-left-text) !important;
        fill: var(--ytbcc-left-text) !important;
      }

      ytd-browse,
      ytd-browse yt-formatted-string,
      ytd-browse #video-title,
      ytd-browse #text,
      ytd-browse #metadata-line,
      ytd-browse #byline,
      ytd-browse #channel-name,
      ytd-browse .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard,
      ytd-browse .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard span,
      ytd-browse .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard div,
      ytd-browse .ytwAdDetailsLineViewModelHostTextStyleStandardBrowse,
      ytd-browse .yt-badge-shape__text,
      ytd-browse .yt-content-metadata-view-model__metadata-row,
      ytd-browse .yt-content-metadata-view-model__metadata-text,
      ytd-browse .yt-content-metadata-view-model__delimiter,
      ytd-browse .yt-core-attributed-string,
      ytd-browse a,
      ytd-browse yt-icon,
      ytd-browse svg,
      ytd-rich-grid-renderer,
      ytd-rich-grid-renderer yt-formatted-string,
      ytd-rich-item-renderer,
      ytd-rich-item-renderer yt-formatted-string,
      ytd-video-renderer,
      ytd-video-renderer yt-formatted-string,
      ytd-grid-video-renderer,
      ytd-grid-video-renderer yt-formatted-string,
      ytd-rich-item-renderer #video-title,
      ytd-video-renderer #video-title,
      ytd-grid-video-renderer #video-title,
      ytd-reel-shelf-renderer,
      ytd-reel-shelf-renderer yt-formatted-string,
      ytd-watch-flexy,
      ytd-watch-flexy yt-formatted-string,
      ytd-watch-flexy #text,
      ytd-watch-flexy #title,
      ytd-watch-flexy #description,
      ytd-watch-flexy .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard,
      ytd-watch-flexy .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard span,
      ytd-watch-flexy .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard div,
      ytd-watch-flexy .ytwAdDetailsLineViewModelHostTextStyleStandardBrowse,
      ytd-watch-flexy .yt-badge-shape__text,
      ytd-watch-flexy .yt-content-metadata-view-model__metadata-row,
      ytd-watch-flexy .yt-content-metadata-view-model__metadata-text,
      ytd-watch-flexy .yt-content-metadata-view-model__delimiter,
      ytd-watch-flexy .yt-core-attributed-string,
      ytd-watch-flexy a,
      ytd-watch-flexy yt-icon,
      ytd-watch-flexy svg,
      #primary,
      #primary yt-formatted-string,
      #primary #text,
      #primary .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard,
      #primary .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard span,
      #primary .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard div,
      #primary .ytwAdDetailsLineViewModelHostTextStyleStandardBrowse,
      #primary .yt-badge-shape__text,
      #primary .yt-content-metadata-view-model__metadata-row,
      #primary .yt-content-metadata-view-model__metadata-text,
      #primary .yt-content-metadata-view-model__delimiter,
      #primary .yt-core-attributed-string,
      #primary a,
      #primary yt-icon,
      #primary svg,
      #secondary,
      #secondary yt-formatted-string,
      #secondary #text,
      #secondary .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard,
      #secondary .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard span,
      #secondary .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard div,
      #secondary .ytwAdDetailsLineViewModelHostTextStyleStandardBrowse,
      #secondary .yt-badge-shape__text,
      #secondary .yt-content-metadata-view-model__metadata-row,
      #secondary .yt-content-metadata-view-model__metadata-text,
      #secondary .yt-content-metadata-view-model__delimiter,
      #secondary .yt-core-attributed-string,
      #secondary a,
      #secondary yt-icon,
      #secondary svg,
      #below,
      #below yt-formatted-string,
      #below #text,
      #below .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard,
      #below .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard span,
      #below .ytwFeedAdMetadataViewModelHostMetadataAdBadgeDetailsLineContainerStyleStandard div,
      #below .ytwAdDetailsLineViewModelHostTextStyleStandardBrowse,
      #below .yt-badge-shape__text,
      #below .yt-content-metadata-view-model__metadata-row,
      #below .yt-content-metadata-view-model__metadata-text,
      #below .yt-content-metadata-view-model__delimiter,
      #below .yt-core-attributed-string,
      #below a,
      #below yt-icon,
      #below svg {
        color: var(--ytbcc-middle-text) !important;
        fill: var(--ytbcc-middle-text) !important;
      }

      .ytwAdButtonGroupViewModelHostPrimaryButton a,
      .ytwAdButtonGroupViewModelHostPrimaryButton a *,
      .ytwAdButtonViewModelHost a,
      .ytwAdButtonViewModelHost a *,
      ad-button-view-model a,
      ad-button-view-model a *,
      .ytwAdButtonGroupViewModelHostPrimaryButton .yt-spec-button-shape-next,
      .ytwAdButtonGroupViewModelHostPrimaryButton .yt-spec-button-shape-next *,
      .ytwAdButtonGroupViewModelHostPrimaryButton .yt-spec-button-shape-next__button-text-content,
      .ytwAdButtonGroupViewModelHostPrimaryButton .yt-spec-button-shape-next__button-text-content *,
      .ytwAdButtonViewModelHost .yt-spec-button-shape-next,
      .ytwAdButtonViewModelHost .yt-spec-button-shape-next *,
      .ytwAdButtonViewModelHost .yt-spec-button-shape-next__button-text-content,
      .ytwAdButtonViewModelHost .yt-spec-button-shape-next__button-text-content *,
      ad-button-view-model .yt-spec-button-shape-next,
      ad-button-view-model .yt-spec-button-shape-next *,
      ad-button-view-model .yt-spec-button-shape-next__button-text-content,
      ad-button-view-model .yt-spec-button-shape-next__button-text-content *,
      ad-button-view-model .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string {
        color: #ffffff !important;
        fill: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
        text-fill-color: #ffffff !important;
      }

      .ytwAdButtonGroupViewModelHostPrimaryButton a,
      .ytwAdButtonViewModelHost a,
      ad-button-view-model a {
        color: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
      }

      .ytwAdButtonGroupViewModelHostPrimaryButton .yt-spec-button-shape-next__button-text-content,
      .ytwAdButtonGroupViewModelHostPrimaryButton .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string,
      .ytwAdButtonViewModelHost .yt-spec-button-shape-next__button-text-content,
      .ytwAdButtonViewModelHost .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string,
      ad-button-view-model .yt-spec-button-shape-next__button-text-content,
      ad-button-view-model .yt-spec-button-shape-next__button-text-content .yt-core-attributed-string {
        color: #ffffff !important;
        fill: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
        text-shadow: none !important;
      }

      ytd-promoted-sparkles-web-renderer ad-button-view-model a,
      ytd-promoted-sparkles-web-renderer ad-button-view-model a *,
      ytd-display-ad-renderer ad-button-view-model a,
      ytd-display-ad-renderer ad-button-view-model a *,
      ytd-ad-slot-renderer ad-button-view-model a,
      ytd-ad-slot-renderer ad-button-view-model a *,
      ytd-promoted-sparkles-web-renderer .yt-spec-button-shape-next,
      ytd-promoted-sparkles-web-renderer .yt-spec-button-shape-next *,
      ytd-display-ad-renderer .yt-spec-button-shape-next,
      ytd-display-ad-renderer .yt-spec-button-shape-next *,
      ytd-ad-slot-renderer .yt-spec-button-shape-next,
      ytd-ad-slot-renderer .yt-spec-button-shape-next *,
      ytd-promoted-sparkles-web-renderer .yt-spec-button-shape-next__button-text-content,
      ytd-promoted-sparkles-web-renderer .yt-spec-button-shape-next__button-text-content *,
      ytd-display-ad-renderer .yt-spec-button-shape-next__button-text-content,
      ytd-display-ad-renderer .yt-spec-button-shape-next__button-text-content *,
      ytd-ad-slot-renderer .yt-spec-button-shape-next__button-text-content,
      ytd-ad-slot-renderer .yt-spec-button-shape-next__button-text-content * {
        color: #ffffff !important;
        fill: #ffffff !important;
        stroke: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
      }

      yt-chip-cloud-chip-renderer,
      yt-chip-cloud-chip-renderer #chip-container,
      yt-chip-cloud-chip-renderer #chip-shape,
      yt-chip-cloud-chip-renderer .ytChipShapeChip,
      yt-chip-cloud-chip-renderer .yt-chip-cloud-chip-renderer,
      yt-chip-cloud-chip-renderer[selected],
      yt-chip-cloud-chip-renderer[selected] #chip-container,
      yt-chip-cloud-chip-renderer[selected] #chip-shape,
      yt-chip-cloud-chip-renderer[selected] .ytChipShapeChip,
      yt-chip-cloud-chip-renderer[aria-selected='true'] #chip-container,
      yt-chip-cloud-chip-renderer[aria-selected='true'] #chip-shape,
      yt-chip-cloud-chip-renderer[aria-selected='true'] .ytChipShapeChip {
        background: var(--ytbcc-chip-background) !important;
        border-radius: 10px !important;
        box-shadow: none !important;
        color: var(--ytbcc-chip-text) !important;
      }

      yt-chip-cloud-chip-renderer[selected],
      yt-chip-cloud-chip-renderer[aria-selected='true'] {
        background: transparent !important;
      }

      yt-chip-cloud-chip-renderer[selected] #chip-container,
      yt-chip-cloud-chip-renderer[selected] #chip-shape,
      yt-chip-cloud-chip-renderer[selected] .ytChipShapeChip,
      yt-chip-cloud-chip-renderer[aria-selected='true'] #chip-container,
      yt-chip-cloud-chip-renderer[aria-selected='true'] #chip-shape,
      yt-chip-cloud-chip-renderer[aria-selected='true'] .ytChipShapeChip {
        background: var(--ytbcc-chip-background-selected) !important;
        color: var(--ytbcc-chip-text-selected) !important;
      }

      yt-chip-cloud-chip-renderer[selected] #chip-container,
      yt-chip-cloud-chip-renderer[selected] #chip-shape,
      yt-chip-cloud-chip-renderer[aria-selected='true'] #chip-container,
      yt-chip-cloud-chip-renderer[aria-selected='true'] #chip-shape {
        border: none !important;
      }

      yt-chip-cloud-chip-renderer yt-formatted-string,
      yt-chip-cloud-chip-renderer[selected] yt-formatted-string,
      yt-chip-cloud-chip-renderer[aria-selected='true'] yt-formatted-string,
      yt-chip-cloud-chip-renderer #text,
      yt-chip-cloud-chip-renderer .ytChipShapeChip,
      yt-chip-cloud-chip-renderer .ytChipShapeChip__text {
        color: var(--ytbcc-chip-text) !important;
        opacity: 1 !important;
      }

      yt-chip-cloud-chip-renderer[selected] .ytChipShapeChip__text,
      yt-chip-cloud-chip-renderer[selected] yt-formatted-string,
      yt-chip-cloud-chip-renderer[aria-selected='true'] .ytChipShapeChip__text,
      yt-chip-cloud-chip-renderer[aria-selected='true'] yt-formatted-string {
        color: var(--ytbcc-chip-text-selected) !important;
      }

      ytd-guide-renderer,
      ytd-mini-guide-renderer,
      tp-yt-app-drawer #contentContainer,
      tp-yt-app-drawer #guide-content,
      #guide-content.ytd-app,
      #guide-button.ytd-masthead,
      yt-icon-button#guide-button,
      tp-yt-app-toolbar #guide-button,
      ytd-guide-section-renderer,
      ytd-guide-entry-renderer,
      ytd-guide-collapsible-section-entry-renderer,
      #items.ytd-guide-renderer {
        background: var(--ytbcc-left) !important;
      }

      ytd-app,
      ytd-browse,
      ytd-two-column-browse-results-renderer,
      ytd-rich-grid-renderer,
      #primary,
      #contents.ytd-rich-grid-renderer,
      #page-manager,
      #content.ytd-page-manager,
      ytd-watch-flexy,
      #columns.ytd-watch-flexy,
      #secondary.ytd-watch-flexy,
      #below.ytd-watch-flexy,
      #chat.ytd-live-chat-frame,
      .ytd-page-manager {
        background: var(--ytbcc-middle) !important;
      }

      ytd-message-renderer,
      ytd-message-renderer[is-card],
      ytd-message-renderer #content,
      ytd-message-renderer #container,
      ytd-message-renderer #dismissible,
      ytd-message-renderer #body,
      ytd-message-renderer .message,
      ytd-feed-nudge-renderer,
      ytd-feed-nudge-renderer #content,
      ytd-feed-nudge-renderer #container,
      ytd-feed-nudge-renderer #dismissible,
      ytd-feed-nudge-renderer #message-container,
      ytd-feed-nudge-renderer #body,
      ytd-feed-nudge-renderer #contents,
      ytd-feed-nudge-renderer .ytd-feed-nudge-renderer,
      ytd-guide-signin-promo-renderer,
      ytd-guide-signin-promo-renderer #content,
      ytd-guide-signin-promo-renderer #section-notifications,
      ytd-guide-signin-promo-renderer #subtitle,
      ytd-guide-signin-promo-renderer #title {
        background: var(--ytbcc-middle) !important;
        color: var(--ytbcc-middle-text) !important;
        border-color: var(--ytbcc-middle-card-border) !important;
      }

      ytd-message-renderer,
      ytd-message-renderer[is-card],
      ytd-feed-nudge-renderer,
      ytd-guide-signin-promo-renderer {
        border-radius: 42px !important;
        overflow: hidden !important;
        max-width: 60% !important;
        margin-left: auto !important;
        margin-right: auto !important;
      }

      ytd-message-renderer,
      ytd-message-renderer[is-card],
      ytd-feed-nudge-renderer,
      ytd-guide-signin-promo-renderer {
        border: 8px solid var(--ytbcc-middle-card-border) !important;
        box-sizing: border-box !important;
        box-shadow: none !important;
      }

      ytd-message-renderer #container,
      ytd-message-renderer #content,
      ytd-message-renderer #dismissible,
      ytd-feed-nudge-renderer #container,
      ytd-feed-nudge-renderer #content,
      ytd-feed-nudge-renderer #dismissible,
      ytd-feed-nudge-renderer #message-container,
      ytd-feed-nudge-renderer #contents,
      ytd-guide-signin-promo-renderer #content {
        border: none !important;
        border-radius: 34px !important;
        box-shadow: none !important;
      }

      ytd-message-renderer yt-formatted-string,
      ytd-message-renderer #title,
      ytd-message-renderer #subtitle,
      ytd-message-renderer #text,
      ytd-message-renderer .message,
      ytd-message-renderer a,
      ytd-feed-nudge-renderer yt-formatted-string,
      ytd-feed-nudge-renderer #title,
      ytd-feed-nudge-renderer #subtitle,
      ytd-feed-nudge-renderer #text,
      ytd-feed-nudge-renderer a,
      ytd-feed-nudge-renderer button,
      ytd-feed-nudge-renderer .yt-spec-button-shape-next__button-text-content,
      ytd-guide-signin-promo-renderer yt-formatted-string,
      ytd-guide-signin-promo-renderer #title,
      ytd-guide-signin-promo-renderer #subtitle,
      ytd-guide-signin-promo-renderer #text,
      ytd-guide-signin-promo-renderer a,
      ytd-guide-signin-promo-renderer button {
        color: var(--ytbcc-middle-text) !important;
        fill: var(--ytbcc-middle-text) !important;
        stroke: var(--ytbcc-middle-text) !important;
        -webkit-text-fill-color: var(--ytbcc-middle-text) !important;
      }

      ytd-feed-nudge-renderer button,
      ytd-feed-nudge-renderer .yt-spec-button-shape-next,
      ytd-feed-nudge-renderer .yt-spec-button-shape-next__button-text-content,
      ytd-guide-signin-promo-renderer button,
      ytd-guide-signin-promo-renderer .yt-spec-button-shape-next,
      ytd-guide-signin-promo-renderer .yt-spec-button-shape-next__button-text-content {
        background: transparent !important;
        border-color: var(--ytbcc-middle-card-border) !important;
        box-shadow: none !important;
      }

      #ytbcc-button {
        width: 92px;
        height: 68px;
        border: none;
        border-radius: 0;
        background: transparent;
        color: inherit;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-left: -12px;
        position: static;
        vertical-align: middle;
        flex: 0 0 auto;
        align-self: center;
        transform: translateY(-4px);
        padding: 0;
      }

      #ytbcc-button:hover {
        background: transparent;
      }

      #ytbcc-button-icon {
        width: 76px;
        height: 56px;
        display: block;
        object-fit: contain;
        pointer-events: none;
      }

      #voice-search-button + #ytbcc-button,
      ytd-button-renderer + #ytbcc-button {
        display: inline-flex !important;
      }

      #ytbcc-panel {
        position: fixed;
        top: 114px;
        right: 24px;
        z-index: 99999;
        width: 406px;
        padding: 0 0 12px;
        box-sizing: border-box;
        border-radius: 0;
        background: #ffffff;
        color: #0f0f0f;
        border: 1px solid rgba(15, 15, 15, 0.12);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
        font-family: Arial, sans-serif;
        overflow: visible !important;
        max-height: none !important;
      }

      #ytbcc-panel[hidden] {
        display: none !important;
      }

      #ytbcc-panel h3 {
        margin: 0;
        font-size: 16px;
        font-weight: 700;
      }

      .ytbcc-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 18px 14px 18px 14px;
      }

      .ytbcc-header-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 0;
      }

      .ytbcc-header-icon {
        width: 40px;
        height: 40px;
        flex: 0 0 auto;
        border-radius: 50%;
        display: block;
      }

      .ytbcc-close {
        border: none;
        background: transparent;
        color: #111111;
        font-size: 24px;
        cursor: pointer;
        line-height: 1;
        padding: 2px 4px;
      }

      .ytbcc-toolbar {
        margin: 0 11px 12px;
      }

      .ytbcc-toolbar-card,
      .ytbcc-collection-card {
        border-radius: 10px;
        background: #e4e5ed;
        min-height: 48px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 12px;
      }

      .ytbcc-section-buttons {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 6px;
        flex: 1 1 auto;
        margin-right: 6px;
      }

      .ytbcc-section-button {
        border: none;
        background: transparent;
        color: #222222;
        border-radius: 8px;
        min-height: 34px;
        padding: 7px 6px;
        cursor: pointer;
        font-size: 11px;
        font-weight: 400;
      }

      .ytbcc-section-button[data-active='true'] {
        background: rgba(255, 255, 255, 0.36);
        color: #111111;
      }

      .ytbcc-chevron {
        font-size: 20px;
        line-height: 1;
        color: #1f1f1f;
      }

      .ytbcc-divider {
        height: 1px;
        margin: 0 28px 12px;
        background: #dddddd;
      }

      .ytbcc-frame {
        --ytbcc-swatch-size: 76px;
        --ytbcc-swatch-gap: 10px;
        --ytbcc-visible-swatch-columns: 4;
        --ytbcc-visible-swatch-rows: 4;
        width: calc(100% - 20px);
        height: calc((var(--ytbcc-swatch-size) * var(--ytbcc-visible-swatch-rows)) + (var(--ytbcc-swatch-gap) * (var(--ytbcc-visible-swatch-rows) - 1)) + 12px);
        margin: 0 10px 10px;
        padding: 5px;
        border-radius: 4px;
        border: 1px solid #78a1ff;
        background: #ffffff;
        box-sizing: border-box;
      }

      .ytbcc-frame-scroll {
        width: 100%;
        height: calc((var(--ytbcc-swatch-size) * var(--ytbcc-visible-swatch-rows)) + (var(--ytbcc-swatch-gap) * (var(--ytbcc-visible-swatch-rows) - 1)));
        max-height: calc((var(--ytbcc-swatch-size) * var(--ytbcc-visible-swatch-rows)) + (var(--ytbcc-swatch-gap) * (var(--ytbcc-visible-swatch-rows) - 1)));
        overflow-y: auto;
        overflow-x: hidden;
        padding: 0 6px 0 0;
        scrollbar-width: auto;
        scrollbar-color: #d8d8d8 transparent;
        box-sizing: border-box;
      }

      .ytbcc-frame-scroll::-webkit-scrollbar {
        width: 8px;
      }

      .ytbcc-frame-scroll::-webkit-scrollbar-track {
        background: transparent;
      }

      .ytbcc-frame-scroll::-webkit-scrollbar-thumb {
        border-radius: 999px;
        background: #d8d8d8;
        border: 1px solid transparent;
        background-clip: content-box;
      }

      .ytbcc-swatch-grid {
        display: grid;
        grid-template-columns: repeat(var(--ytbcc-visible-swatch-columns), var(--ytbcc-swatch-size));
        grid-auto-rows: var(--ytbcc-swatch-size);
        gap: var(--ytbcc-swatch-gap);
        justify-content: space-between;
        justify-items: stretch;
        align-items: start;
        align-content: start;
      }

      .ytbcc-swatch {
        position: relative;
        width: var(--ytbcc-swatch-size);
        height: var(--ytbcc-swatch-size);
        border: 2px solid transparent;
        border-radius: 12px;
        padding: 0;
        cursor: pointer;
        overflow: hidden;
        background: transparent;
      }

      .ytbcc-swatch[data-color='#ffffff'] {
        border-color: #111111;
        border-radius: 12px;
        box-shadow: inset 0 0 0 2px #ffffff;
      }

      .ytbcc-swatch[data-selected='true'] {
        border-color: #5a84d8;
      }

      .ytbcc-swatch[data-color='#ffffff'][data-selected='true'] {
        border-color: #5a84d8;
        border-radius: 12px;
        box-shadow: inset 0 0 0 2px #ffffff;
      }

      .ytbcc-swatch-surface,
      .ytbcc-swatch-rainbow {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .ytbcc-swatch-surface::before,
      .ytbcc-swatch-rainbow::before {
        content: '';
        position: absolute;
        inset: 0;
        background: var(--ytbcc-swatch-color, #5d85ff);
      }

      .ytbcc-swatch-surface::after,
      .ytbcc-swatch-rainbow::after {
        content: none;
      }

      .ytbcc-swatch-rainbow::before {
        background: conic-gradient(from 180deg, #ff5f6d, #ffc371, #f9ff66, #66e5b0, #70caff, #6b75ff, #c95eff, #ff5f6d);
      }

      .ytbcc-swatch-surface svg,
      .ytbcc-swatch-rainbow svg {
        position: relative;
        z-index: 1;
        width: 26px;
        height: 26px;
        pointer-events: none;
      }

      .ytbcc-custom-picker {
        position: absolute;
        width: 1px;
        height: 1px;
        opacity: 0;
        pointer-events: none;
        overflow: hidden;
      }

      .ytbcc-custom-picker input[type="color"] {
        width: 1px;
        height: 1px;
        border: 0;
        padding: 0;
        background: transparent;
        cursor: pointer;
      }

      .ytbcc-rainbow-input {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
        border: 0;
        padding: 0;
      }

      .ytbcc-reset-wrap {
        margin: 0 10px;
      }

      .ytbcc-reset-button {
        width: 100%;
        min-height: 48px;
        border: none;
        border-radius: 10px;
        background: #e4e5ed;
        color: #111111;
        cursor: pointer;
        font-size: 11px;
        font-weight: 400;
        font-family: Arial, sans-serif;
        text-align: center;
        padding: 12px 14px;
      }

      .ytbcc-reset-button:hover {
        background: #d8dae5;
      }
    `;
  }

  function applyColors(colors) {
    currentColors = { ...DEFAULTS, ...colors };
    ensureStyleTag().textContent = buildCss(currentColors);
  }

  function saveColors() {
    chrome.storage.sync.set({ [STORAGE_KEY]: currentColors });
  }

  function updateColor(section, value) {
    currentColors = { ...currentColors, [section]: value };
    applyColors(currentColors);
    saveColors();
  }

  function resetAllColors(panel) {
    currentColors = { ...DEFAULTS };
    applyColors(currentColors);
    saveColors();
    applyPanelSelection(panel);
  }

  function setActiveSection(nextSection, panel) {
    activeSection = nextSection;

    panel.querySelectorAll('.ytbcc-section-button').forEach((button) => {
      button.dataset.active = String(button.dataset.section === nextSection);
    });

    panel.querySelectorAll('.ytbcc-swatch').forEach((swatch) => {
      const value = swatch.dataset.color;
      swatch.dataset.selected = String(Boolean(value) && currentColors[nextSection].toLowerCase() === value.toLowerCase());
    });

    const customPicker = panel.querySelector('#ytbcc-custom-color');
    if (customPicker) {
      customPicker.value = currentColors[nextSection];
    }

    const rainbowInput = panel.querySelector('.ytbcc-rainbow-input');
    if (rainbowInput) {
      rainbowInput.value = currentColors[nextSection];
    }
  }

  function applyPanelSelection(panel) {
    if (!panel) {
      return;
    }

    setActiveSection(activeSection, panel);
  }

  function createSwatch(color) {
    const swatch = document.createElement('button');
    swatch.type = 'button';
    swatch.className = 'ytbcc-swatch';
    swatch.dataset.color = color;

    const surface = document.createElement('span');
    surface.className = 'ytbcc-swatch-surface';
    surface.style.setProperty('--ytbcc-swatch-color', color);

    const iconColor = isLightColor(color) ? '#111111' : '#ffffff';
    surface.innerHTML = getYoutubeOutlineSvgMarkup(iconColor);

    swatch.appendChild(surface);
    swatch.addEventListener('click', () => {
      updateColor(activeSection, color);
      applyPanelSelection(document.getElementById('ytbcc-panel'));
    });

    return swatch;
  }

  function createRainbowSwatch(panel) {
    const swatch = document.createElement('label');
    swatch.className = 'ytbcc-swatch';
    swatch.dataset.rainbow = 'true';
    swatch.setAttribute('aria-label', 'Choose a custom color');

    const surface = document.createElement('span');
    surface.className = 'ytbcc-swatch-rainbow';
    surface.innerHTML = getYoutubeOutlineSvgMarkup('#ffffff');
    swatch.appendChild(surface);

    const rainbowInput = document.createElement('input');
    rainbowInput.type = 'color';
    rainbowInput.className = 'ytbcc-rainbow-input';
    rainbowInput.value = currentColors[activeSection];
    rainbowInput.setAttribute('aria-label', 'Choose a custom color');
    rainbowInput.addEventListener('input', () => {
      updateColor(activeSection, rainbowInput.value);
      applyPanelSelection(panel);
    });
    rainbowInput.addEventListener('click', () => {
      rainbowInput.value = currentColors[activeSection];
    });

    swatch.appendChild(rainbowInput);

    return swatch;
  }

  function ensureBrandText() {
    const logoLink = document.querySelector('ytd-topbar-logo-renderer a#logo');
    if (!logoLink) {
      return;
    }

    Array.from(logoLink.children).forEach((child) => {
      if (child.id !== 'ytbcc-brand') {
        child.remove();
      }
    });

    let brand = document.getElementById('ytbcc-brand');
    if (brand) {
      if (brand.parentElement !== logoLink) {
        logoLink.appendChild(brand);
      }
      return;
    }

    brand = document.createElement('span');
    brand.id = 'ytbcc-brand';
    brand.setAttribute('aria-hidden', 'true');
    brand.innerHTML = `
      <svg id="ytbcc-brand-logo" viewBox="0 0 90 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <rect x="0" y="0" width="90" height="64" rx="18" fill="#FF0000"></rect>
        <path d="M36 18L60 32L36 46V18Z" fill="#FFFFFF"></path>
      </svg>
      <span id="ytbcc-brand-text">YouTube<span id="ytbcc-brand-country">GB</span></span>
    `;

    logoLink.appendChild(brand);
  }

  function ensureMicIcon() {
    const micButton = document.querySelector('ytd-searchbox #voice-search-button button')
      || document.querySelector('#voice-search-button button')
      || document.querySelector('ytd-button-renderer[button-renderer-style="STYLE_DEFAULT"] button[aria-label*="voice" i]')
      || document.querySelector('button[title*="voice" i]');
    if (!micButton) {
      return;
    }
    if (micButton.getAttribute('data-ytbcc-mic-button') === 'true') {
      return;
    }

    micButton.setAttribute('data-ytbcc-mic-button', 'true');
    micButton.innerHTML = getMicSvgMarkup('ytbcc-mic-icon');
  }

  function closePanelOnOutsideClick(panel, button) {
    document.addEventListener('click', (event) => {
      if (panel.hidden) {
        return;
      }

      const target = event.target;
      if (panel.contains(target) || button.contains(target)) {
        return;
      }

      panel.hidden = true;
    });
  }

  function getSearchRoots() {
    const roots = [document];
    const queue = [document.documentElement];

    while (queue.length) {
      const node = queue.shift();
      if (!node) {
        continue;
      }

      if (node.nodeType === Node.ELEMENT_NODE && node.shadowRoot && !roots.includes(node.shadowRoot)) {
        roots.push(node.shadowRoot);
        queue.push(node.shadowRoot);
      }

      if (node.children?.length) {
        queue.push(...node.children);
      }
    }

    return roots;
  }

  function removeAppearanceMenuItem() {
    const menuItemSelector = [
      'ytd-compact-link-renderer',
      'ytd-menu-service-item-renderer',
      'ytd-toggle-theme-compact-link-renderer',
      'yt-list-item-view-model',
      'tp-yt-paper-item',
      '[role="menuitem"]'
    ].join(', ');

    getSearchRoots().forEach((root) => {
      root.querySelectorAll(menuItemSelector).forEach((item) => {
        const label = (
          item.getAttribute?.('aria-label')
          || item.getAttribute?.('title')
          || item.textContent
          || ''
        )
          .replace(/\s+/g, ' ')
          .trim();

        if (!/^appearance(?:\s*:)?\b/i.test(label)) {
          return;
        }

        const menuItemHost = item.closest(
          'ytd-toggle-theme-compact-link-renderer, ytd-compact-link-renderer, ytd-menu-service-item-renderer, yt-list-item-view-model, tp-yt-paper-item, [role="menuitem"]'
        );

        (menuItemHost || item).remove();
      });
    });
  }

  function ensurePanel() {
    let panel = document.getElementById('ytbcc-panel');
    if (panel) {
      return panel;
    }

    panel = document.createElement('div');
    panel.id = 'ytbcc-panel';
    panel.hidden = true;

    const header = document.createElement('div');
    header.className = 'ytbcc-header';

    const headerBrand = document.createElement('div');
    headerBrand.className = 'ytbcc-header-brand';

    const headerIcon = document.createElement('svg');
    headerIcon.className = 'ytbcc-header-icon';
    headerIcon.setAttribute('viewBox', '0 0 90 90');
    headerIcon.setAttribute('aria-hidden', 'true');
    headerIcon.innerHTML = `
      <circle cx="45" cy="45" r="42" fill="#6f7bd9"></circle>
      <circle cx="45" cy="45" r="33" fill="#ffffff"></circle>
      <path d="M21 45C21 31.75 31.75 21 45 21V30C36.72 30 30 36.72 30 45H21Z" fill="#66d28f"></path>
      <path d="M69 45C69 58.25 58.25 69 45 69V60C53.28 60 60 53.28 60 45H69Z" fill="#ff6b59"></path>
      <path d="M45 21C58.25 21 69 31.75 69 45H60C60 36.72 53.28 30 45 30V21Z" fill="#ffd657"></path>
      <path d="M45 69C31.75 69 21 58.25 21 45H30C30 53.28 36.72 60 45 60V69Z" fill="#4ca3ff"></path>
      <rect x="33" y="28" width="26" height="34" rx="8" fill="#f3d25b" stroke="#55b56a" stroke-width="2"></rect>
      <path d="M41 37L53 45L41 53V37Z" fill="#ffffff"></path>
    `;

    const title = document.createElement('h3');
    title.textContent = 'Color Changer for YouTube';

    const closeIconButton = document.createElement('button');
    closeIconButton.type = 'button';
    closeIconButton.className = 'ytbcc-close';
    closeIconButton.setAttribute('aria-label', 'Close');
    closeIconButton.textContent = '×';
    closeIconButton.addEventListener('click', () => {
      panel.hidden = true;
    });

    headerBrand.append(headerIcon, title);
    header.append(headerBrand, closeIconButton);

    const toolbar = document.createElement('div');
    toolbar.className = 'ytbcc-toolbar';

    const toolbarCard = document.createElement('div');
    toolbarCard.className = 'ytbcc-toolbar-card';

    const sectionButtons = document.createElement('div');
    sectionButtons.className = 'ytbcc-section-buttons';
    SECTION_BUTTONS.forEach((section) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'ytbcc-section-button';
      button.dataset.section = section.key;
      button.textContent = section.label;
      button.addEventListener('click', () => {
        setActiveSection(section.key, panel);
      });
      sectionButtons.appendChild(button);
    });

    const toolbarChevron = document.createElement('span');
    toolbarChevron.className = 'ytbcc-chevron';
    toolbarChevron.setAttribute('aria-hidden', 'true');
    toolbarChevron.textContent = '⌄';

    toolbarCard.append(sectionButtons, toolbarChevron);
    toolbar.appendChild(toolbarCard);

    const divider = document.createElement('div');
    divider.className = 'ytbcc-divider';

    const frame = document.createElement('div');
    frame.className = 'ytbcc-frame';

    const frameScroll = document.createElement('div');
    frameScroll.className = 'ytbcc-frame-scroll';

    const swatchGrid = document.createElement('div');
    swatchGrid.className = 'ytbcc-swatch-grid';
    COLOR_SWATCHES.forEach((color) => {
      swatchGrid.appendChild(createSwatch(color));
    });
    swatchGrid.appendChild(createRainbowSwatch(panel));

    const customPickerWrap = document.createElement('div');
    customPickerWrap.className = 'ytbcc-custom-picker';

    const customPicker = document.createElement('input');
    customPicker.type = 'color';
    customPicker.id = 'ytbcc-custom-color';
    customPicker.value = currentColors[activeSection];
    customPicker.addEventListener('input', () => {
      updateColor(activeSection, customPicker.value);
      applyPanelSelection(panel);
    });

    customPickerWrap.append(customPicker);
    frameScroll.append(swatchGrid, customPickerWrap);
    frame.append(frameScroll);

    const resetWrap = document.createElement('div');
    resetWrap.className = 'ytbcc-reset-wrap';

    const resetButton = document.createElement('button');
    resetButton.type = 'button';
    resetButton.className = 'ytbcc-reset-button';
    resetButton.textContent = 'Reset';
    resetButton.addEventListener('click', () => {
      resetAllColors(panel);
    });

    resetWrap.appendChild(resetButton);

    panel.append(
      header,
      toolbar,
      divider,
      frame,
      resetWrap
    );

    document.body.appendChild(panel);
    applyPanelSelection(panel);
    return panel;
  }

  function ensureButton() {
    const target = document.querySelector('#end');
    const micButton = document.querySelector('ytd-searchbox #voice-search-button button')
      || document.querySelector('#voice-search-button button')
      || document.querySelector('ytd-button-renderer[button-renderer-style="STYLE_DEFAULT"] button[aria-label*="voice" i]')
      || document.querySelector('button[title*="voice" i]');
    const searchControls = document.querySelector('ytd-searchbox')
      || document.querySelector('#center')
      || document.querySelector('#center.ytd-masthead');

    if (!target && !micButton) {
      ensureBrandText();
      ensureMicIcon();
      return;
    }

    let button = document.getElementById('ytbcc-button');
    if (!button) {
      button = document.createElement('button');
      button.id = 'ytbcc-button';
      button.type = 'button';
      button.title = 'Change YouTube colors';
      button.setAttribute('aria-label', 'Change YouTube colors');

      const buttonIcon = document.createElement('img');
      buttonIcon.id = 'ytbcc-button-icon';
      buttonIcon.src = chrome.runtime.getURL('download.png');
      buttonIcon.alt = '';
      buttonIcon.setAttribute('aria-hidden', 'true');
      button.appendChild(buttonIcon);

      const panel = ensurePanel();
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        panel.hidden = !panel.hidden;
      });

      closePanelOnOutsideClick(panel, button);
    }

    const micHost = micButton?.closest('#voice-search-button')
      || micButton?.closest('ytd-button-renderer')
      || document.querySelector('#voice-search-button')
      || document.querySelector('ytd-button-renderer[button-renderer-style="STYLE_DEFAULT"]');

    if (micHost) {
      const insertionAnchor = micHost.id === 'voice-search-button'
        ? micHost
        : micHost.closest('#voice-search-button') || micHost;
      const preferredParent = insertionAnchor.parentElement || searchControls;
      const needsMove = button.parentElement !== preferredParent || button.previousElementSibling !== insertionAnchor;

      if (preferredParent && needsMove) {
        insertionAnchor.insertAdjacentElement('afterend', button);
      }
      ensureBrandText();
      ensureMicIcon();
      return;
    }

    if (target) {
      const signInHost = Array.from(target.children).find((element) => {
        const label = element.getAttribute?.('aria-label') || element.textContent || '';
        return /sign in/i.test(label);
      });

      if (signInHost) {
        if (button.nextElementSibling !== signInHost || button.parentElement !== signInHost.parentElement) {
          signInHost.insertAdjacentElement('beforebegin', button);
        }
      } else if (target.firstElementChild !== button || button.parentElement !== target) {
        target.prepend(button);
      }
    }

    ensureBrandText();
    ensureMicIcon();
  }

  function scheduleEnsureButton() {
    if (ensureButtonScheduled) {
      return;
    }

    ensureButtonScheduled = true;
    requestAnimationFrame(() => {
      ensureButtonScheduled = false;
      ensureButton();
      removeAppearanceMenuItem();
    });
  }

  function startObserver() {
    if (observerStarted) {
      return;
    }

    observerStarted = true;
    observer = new MutationObserver((mutations) => {
      const hasRelevantChange = mutations.some((mutation) => {
        if (mutation.type !== 'childList') {
          return false;
        }

        return Array.from(mutation.addedNodes).some((node) => (
          node.nodeType === Node.ELEMENT_NODE
        )) || Array.from(mutation.removedNodes).some((node) => (
          node.nodeType === Node.ELEMENT_NODE
        ));
      });

      if (hasRelevantChange) {
        scheduleEnsureButton();
      }
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  chrome.storage.sync.get(STORAGE_KEY, (result) => {
    applyColors(result[STORAGE_KEY] || DEFAULTS);
    ensurePanel();
    ensureButton();
    removeAppearanceMenuItem();
    startObserver();
  });
})();
